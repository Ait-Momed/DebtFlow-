const fs = require('fs');
let content = fs.readFileSync('c:/Users/DELL720/Desktop/tahiri/tahiri_lilatate/Web/js/app.js', 'utf8');

// Find the customer_details bridge handler and update to call Debts.loadCustomerDebts
const oldViewSection = "document.getElementById('viewCustomerModalOverlay').classList.add('active');\n      }";
const newViewSection = "document.getElementById('viewCustomerModalOverlay').classList.add('active');\n        // Load debts for this customer\n        if (typeof Debts !== 'undefined') {\n          Debts.loadCustomerDebts(c.Id, c.FullName);\n        }\n        // Wire the Add Debt button\n        var btnAddFromCustomer = document.getElementById('btnAddDebtFromCustomer');\n        if (btnAddFromCustomer) {\n          btnAddFromCustomer.onclick = function() {\n            if (typeof Debts !== 'undefined') Debts.openAddDebt(c.Id, c.FullName);\n          };\n        }\n      }";
content = content.replace(oldViewSection, newViewSection);

fs.writeFileSync('c:/Users/DELL720/Desktop/tahiri/tahiri_lilatate/Web/js/app.js', content);
console.log('app.js: customer view now wires Debts.loadCustomerDebts');
