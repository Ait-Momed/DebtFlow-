const fs = require('fs');
const http = require('http');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = 'C:/Users/DELL720/AppData/Local/tahiri_lilatate/tahiri_lilatate.db';
const WEB_DIR = 'C:/Program Files/Tahiri Lilatate/Web';
const db = new DatabaseSync(DB_PATH);

function getSetting(key, defVal = '') {
  const row = db.prepare('SELECT Value FROM DatabaseMeta WHERE Key = ?').get(key);
  return row ? row.Value : defVal;
}

function getCustomers(query) {
  let sql = `
    SELECT 
        c.Id, c.FullName, c.Phone, c.CIN, c.Address, c.Notes, c.RegistrationDate, c.IsArchived, c.ArchivedAt,
        IFNULL((
            SELECT SUM(d.Amount) - IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId = d.Id), 0)
            FROM Debts d
            WHERE d.CustomerId = c.Id
        ), 0) AS TotalRemaining
    FROM Customers c
    WHERE c.IsArchived = 0
  `;
  const params = [];
  if (query && query.trim()) {
    sql += ` AND (c.FullName LIKE ? OR c.Phone LIKE ? OR c.CIN LIKE ?) `;
    const term = `%${query.trim()}%`;
    params.push(term, term, term);
  }
  sql += ` ORDER BY c.Id DESC;`;
  return db.prepare(sql).all(...params);
}

function getDebts(query) {
  let sql = `
    SELECT 
        d.*,
        IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
        (SELECT MAX(PaymentDate) FROM Payments WHERE DebtId = d.Id) AS LastPaymentDate,
        c.FullName, c.Phone, c.CIN
    FROM Debts d
    JOIN Customers c ON d.CustomerId = c.Id
    WHERE c.IsArchived = 0
  `;
  const params = [];
  if (query && query.trim()) {
    sql += ` AND (c.FullName LIKE ? OR c.Phone LIKE ? OR c.CIN LIKE ?) `;
    const term = `%${query.trim()}%`;
    params.push(term, term, term);
  }
  sql += ` ORDER BY d.DebtDate DESC, d.Id DESC;`;
  const rows = db.prepare(sql).all(...params);
  return rows.map(r => {
    const totalPaid = Number(r.TotalPaid) || 0;
    const amount = Number(r.Amount) || 0;
    const remaining = amount - totalPaid;
    let status = 'Non payé';
    if (remaining <= 0) status = 'Payé';
    else if (totalPaid > 0) status = 'Partiellement payé';
    return {
      ...r,
      TotalPaid: totalPaid,
      Remaining: remaining,
      Status: status,
      CustomerName: r.FullName,
      CustomerPhone: r.Phone,
      CustomerCIN: r.CIN
    };
  });
}

function getPayments(query) {
  let sql = `
    SELECT 
        p.*,
        d.Amount AS DebtAmount,
        c.FullName AS CustomerFullName,
        c.Phone AS CustomerPhone,
        c.CIN AS CustomerCIN
    FROM Payments p
    JOIN Debts d ON p.DebtId = d.Id
    JOIN Customers c ON d.CustomerId = c.Id
    WHERE c.IsArchived = 0
  `;
  const params = [];
  if (query && query.trim()) {
    sql += ` AND (c.FullName LIKE ? OR c.Phone LIKE ? OR c.CIN LIKE ?) `;
    const term = `%${query.trim()}%`;
    params.push(term, term, term);
  }
  sql += ` ORDER BY p.PaymentDate DESC, p.Id DESC;`;
  return db.prepare(sql).all(...params).map(p => ({
    ...p,
    CustomerName: p.CustomerFullName
  }));
}

function getArchive() {
  const sql = `
    SELECT 
        c.Id, c.FullName, c.Phone, c.CIN, c.Address, c.Notes, c.RegistrationDate, c.IsArchived, c.ArchivedAt,
        IFNULL((
            SELECT SUM(d.Amount) - IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId = d.Id), 0)
            FROM Debts d
            WHERE d.CustomerId = c.Id
        ), 0) AS TotalRemaining
    FROM Customers c
    WHERE c.IsArchived = 1
    ORDER BY c.ArchivedAt DESC, c.Id DESC;
  `;
  return db.prepare(sql).all();
}

function handleRpc(action, payload) {
  if (action === 'check_auth') {
    return {
      action: 'auth_state',
      payload: {
        isAuthenticated: true,
        username: 'Admin',
        role: 'Administrator',
        app_title: getSetting('app_title', 'Tahiri Lilatate'),
        app_logo: getSetting('app_logo', ''),
        app_theme: getSetting('app_theme', 'light'),
        app_language: getSetting('app_language', 'fr')
      }
    };
  }
  if (action === 'login') {
    return {
      action: 'login_response',
      payload: { success: true }
    };
  }
  if (action === 'get_customers') {
    const list = getCustomers(payload && payload.query);
    return {
      action: 'customers_list',
      payload: { success: true, customers: list, totalCount: list.length }
    };
  }
  if (action === 'get_debts' || action === 'get_debts_filter') {
    let list = getDebts(payload && payload.query);
    if (payload && payload.status && payload.status !== 'all') {
      list = list.filter(d => d.Status === payload.status);
    }
    return {
      action: 'debts_list',
      payload: { success: true, debts: list, totalCount: list.length }
    };
  }
  if (action === 'get_payments') {
    const list = getPayments(payload && payload.query);
    return {
      action: 'payments_list',
      payload: { success: true, payments: list, totalCount: list.length }
    };
  }
  if (action === 'get_archive') {
    const list = getArchive();
    return {
      action: 'archive_list',
      payload: { success: true, customers: list, totalCount: list.length }
    };
  }
  if (action === 'get_app_settings') {
    return {
      action: 'app_settings',
      payload: {
        success: true,
        app_title: getSetting('app_title', 'Tahiri Lilatate'),
        app_logo: getSetting('app_logo', ''),
        app_theme: getSetting('app_theme', 'light'),
        app_language: getSetting('app_language', 'fr'),
        backup_dir: 'C:\\Users\\DELL720\\AppData\\Local\\tahiri_lilatate'
      }
    };
  }
  return { action: action + '_response', payload: { success: true } };
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/rpc') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { action, payload } = JSON.parse(body);
        const resp = handleRpc(action, payload);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(resp));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  let filePath = path.join(WEB_DIR, req.url.split('?')[0]);
  if (req.url === '/' || req.url === '') {
    filePath = path.join(WEB_DIR, 'index.html');
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const mimeMap = {
      '.html': 'text/html',
      '.css': 'text/css',
      '.js': 'application/javascript',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.ico': 'image/x-icon',
      '.svg': 'image/svg+xml'
    };

    let contentType = mimeMap[ext] || 'application/octet-stream';

    if (ext === '.html') {
      let html = data.toString('utf8');
      const mockBridge = `
        <script>
          window.chrome = {
            webview: {
              postMessage: function(msgStr) {
                try {
                  const msg = typeof msgStr === 'string' ? JSON.parse(msgStr) : msgStr;
                  fetch('/rpc', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(msg)
                  })
                  .then(r => r.json())
                  .then(reply => {
                    const event = new MessageEvent('message', { data: JSON.stringify(reply) });
                    window.dispatchEvent(event);
                    if (window.chrome && window.chrome.webview && window.chrome.webview._handler) {
                      window.chrome.webview._handler(event);
                    }
                  })
                  .catch(console.error);
                } catch(e) { console.error('Bridge error:', e); }
              },
              addEventListener: function(type, listener) {
                if (type === 'message') {
                  window.chrome.webview._handler = listener;
                }
              }
            }
          };
        </script>
      `;
      html = html.replace('<head>', '<head>' + mockBridge);
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
      return;
    }

    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

const PORT = 3456;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
