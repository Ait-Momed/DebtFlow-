using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Collections.Generic;
using Microsoft.Web.WebView2.Core;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using tahiri_lilatate.Models;
using tahiri_lilatate.Services;

namespace tahiri_lilatate
{
    /// <summary>
    /// Code-behind for the main application window.
    /// Hosts the WebView2 control and manages the C# <-> JavaScript authentication bridge.
    /// 100% C# 5.0 compatible.
    /// </summary>
    public partial class MainWindow : Window
    {
        // ──────────────────────────────────────────────────────────────────────
        // Constructor
        // ──────────────────────────────────────────────────────────────────────

        public MainWindow()
        {
            InitializeComponent();
            InitializeWebViewAsync();
        }

        // ──────────────────────────────────────────────────────────────────────
        // WebView2 initialization
        // ──────────────────────────────────────────────────────────────────────

        private async void InitializeWebViewAsync()
        {
            try
            {
                string userDataFolder = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "tahiri_lilatate",
                    "WebView2Cache");
                var env = await CoreWebView2Environment.CreateAsync(null, userDataFolder);
                await WebView.EnsureCoreWebView2Async(env);
                WebView.DefaultBackgroundColor = System.Drawing.Color.Transparent;

#if DEBUG
                WebView.CoreWebView2.Settings.AreDevToolsEnabled = true;
#else
                WebView.CoreWebView2.Settings.AreDevToolsEnabled = false;
#endif
                WebView.CoreWebView2.Settings.IsWebMessageEnabled = true;
                WebView.CoreWebView2.Settings.AreDefaultScriptDialogsEnabled = true;

                WebView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;
                WebView.CoreWebView2.NavigationCompleted += OnNavigationCompleted;

                NavigateToAppropriatePage();
                LogService.Info("WebView2 initialisé avec succès.");
            }
            catch (Exception ex)
            {
                LogService.Error("Échec de l'initialisation de WebView2.", ex);
                MessageBox.Show(
                    "Impossible de charger l'interface graphique.\n\n" +
                    "Vérifiez que Microsoft Edge WebView2 Runtime est installé.\n\n" +
                    "Veuillez redémarrer l'application.",
                    "Erreur WebView2",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Navigation helpers
        // ──────────────────────────────────────────────────────────────────────

        private void NavigateToAppropriatePage()
        {
            if (AuthenticationService.IsAuthenticated)
            {
                string indexPath = GetWebFilePath("index.html");
                WebView.Source = new Uri(indexPath);
            }
            else
            {
                string loginPath = GetWebFilePath("login.html");
                WebView.Source = new Uri(loginPath);
            }
        }

        private string GetWebFilePath(string filename)
        {
            string exeDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            return "file:///" + Path.Combine(exeDir, "Web", filename).Replace("\\", "/");
        }

        // ──────────────────────────────────────────────────────────────────────
        // Navigation guard
        // ──────────────────────────────────────────────────────────────────────

        private void OnNavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            string uri = WebView.Source != null ? WebView.Source.ToString() : string.Empty;
            bool isLoginPage = uri.EndsWith("login.html", StringComparison.OrdinalIgnoreCase);

            if (!isLoginPage && !AuthenticationService.IsAuthenticated)
            {
                NavigateToAppropriatePage();
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // WebView2 ↔ C# bridge entry point
        // ──────────────────────────────────────────────────────────────────────

        private void OnWebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string rawMessage = e.TryGetWebMessageAsString();
                if (string.IsNullOrWhiteSpace(rawMessage)) return;

                JObject msg = JObject.Parse(rawMessage);
                string action = (string)msg["action"];
                JObject payload = msg["payload"] as JObject;

                if (string.Equals(action, "login", StringComparison.OrdinalIgnoreCase))
                {
                    HandleLogin(payload);
                }
                else if (string.Equals(action, "logout", StringComparison.OrdinalIgnoreCase))
                {
                    HandleLogout();
                }
                else if (string.Equals(action, "reset_password", StringComparison.OrdinalIgnoreCase))
                {
                    HandleResetPassword(payload);
                }
                else if (string.Equals(action, "check_auth", StringComparison.OrdinalIgnoreCase))
                {
                    HandleCheckAuth();
                }
                else if (string.Equals(action, "get_customers", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetCustomers(payload);
                }
                else if (string.Equals(action, "get_customer_by_id", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetCustomerById(payload);
                }
                else if (string.Equals(action, "add_customer", StringComparison.OrdinalIgnoreCase))
                {
                    HandleAddCustomer(payload);
                }
                else if (string.Equals(action, "update_customer", StringComparison.OrdinalIgnoreCase))
                {
                    HandleUpdateCustomer(payload);
                }
                else if (string.Equals(action, "archive_customer", StringComparison.OrdinalIgnoreCase))
                {
                    HandleArchiveCustomer(payload);
                }
                else if (string.Equals(action, "get_debts", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetDebts(payload);
                }
                else if (string.Equals(action, "get_customer_debts", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetCustomerDebts(payload);
                }
                else if (string.Equals(action, "get_debt_by_id", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetDebtById(payload);
                }
                else if (string.Equals(action, "add_debt", StringComparison.OrdinalIgnoreCase))
                {
                    HandleAddDebt(payload);
                }
                else if (string.Equals(action, "update_debt", StringComparison.OrdinalIgnoreCase))
                {
                    HandleUpdateDebt(payload);
                }
                else if (string.Equals(action, "delete_debt", StringComparison.OrdinalIgnoreCase))
                {
                    HandleDeleteDebt(payload);
                }
                else if (string.Equals(action, "get_debts_filter", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetDebtsFilter(payload);
                }
                else if (string.Equals(action, "add_payment", StringComparison.OrdinalIgnoreCase))
                {
                    HandleAddPayment(payload);
                }
                else if (string.Equals(action, "get_debt_payments", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetDebtPayments(payload);
                }
                else if (string.Equals(action, "get_payments", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetPayments(payload);
                }
                else if (string.Equals(action, "get_archive", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetArchive(payload);
                }
                else if (string.Equals(action, "restore_customer", StringComparison.OrdinalIgnoreCase))
                {
                    HandleRestoreCustomer(payload);
                }
                else if (string.Equals(action, "delete_customer_permanent", StringComparison.OrdinalIgnoreCase))
                {
                    HandleDeleteCustomerPermanent(payload);
                }
                else if (string.Equals(action, "get_app_settings", StringComparison.OrdinalIgnoreCase))
                {
                    HandleGetAppSettings(payload);
                }
                else if (string.Equals(action, "update_app_settings", StringComparison.OrdinalIgnoreCase))
                {
                    HandleUpdateAppSettings(payload);
                }
                else if (string.Equals(action, "update_admin_credentials", StringComparison.OrdinalIgnoreCase))
                {
                    HandleUpdateAdminCredentials(payload);
                }
                else if (string.Equals(action, "update_theme", StringComparison.OrdinalIgnoreCase))
                {
                    HandleUpdateTheme(payload);
                }
                else if (string.Equals(action, "window_minimize", StringComparison.OrdinalIgnoreCase))
                {
                    Dispatcher.Invoke(new Action(() => WindowState = WindowState.Minimized));
                }
                else if (string.Equals(action, "window_maximize", StringComparison.OrdinalIgnoreCase))
                {
                    Dispatcher.Invoke(new Action(() =>
                    {
                        WindowState = WindowState == WindowState.Maximized
                            ? WindowState.Normal
                            : WindowState.Maximized;
                    }));
                }
                else if (string.Equals(action, "window_close", StringComparison.OrdinalIgnoreCase))
                {
                    Dispatcher.Invoke(new Action(() => BtnClose_Click(null, null)));
                }
                else
                {
                    LogService.Info("Action WebView2 non gérée : " + action);
                }
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur lors de la réception du message WebView2.", ex);
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Auth handlers
        // ──────────────────────────────────────────────────────────────────────

        private void HandleLogin(JObject payload)
        {
            try
            {
                string username = payload != null ? (string)payload["username"] : string.Empty;
                string password = payload != null ? (string)payload["password"] : string.Empty;

                var result = AuthenticationService.Login(username, password);

                JObject response = new JObject();
                response["action"] = "login_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                if (result.RemainingLockoutSeconds > 0)
                    respPayload["remainingSeconds"] = result.RemainingLockoutSeconds;
                response["payload"] = respPayload;

                PostMessageToJs(response.ToString(Formatting.None));

                if (result.Success)
                {
                    Dispatcher.Invoke(new Action(() =>
                    {
                        string indexPath = GetWebFilePath("index.html");
                        WebView.Source = new Uri(indexPath);
                    }));
                }
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur lors du login.", ex);
                JObject response = new JObject();
                response["action"] = "login_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de la connexion.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleLogout()
        {
            try
            {
                AuthenticationService.Logout();
                Dispatcher.Invoke(new Action(() =>
                {
                    string loginPath = GetWebFilePath("login.html");
                    WebView.Source = new Uri(loginPath);
                }));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur lors du logout.", ex);
            }
        }

        private void HandleResetPassword(JObject payload)
        {
            try
            {
                string newPassword = payload != null ? (string)payload["newPassword"] : string.Empty;
                string confirmPassword = payload != null && payload["confirmPassword"] != null
                    ? (string)payload["confirmPassword"]
                    : newPassword;

                var result = AuthenticationService.ResetAdminPassword(newPassword, confirmPassword);

                JObject response = new JObject();
                response["action"] = "reset_password_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur lors du reset password.", ex);
                JObject response = new JObject();
                response["action"] = "reset_password_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleCheckAuth()
        {
            JObject response = new JObject();
            response["action"] = "auth_state";
            JObject respPayload = new JObject();
            respPayload["isAuthenticated"] = AuthenticationService.IsAuthenticated;
            respPayload["app_title"] = DatabaseService.GetAppSetting("app_title", "Tahiri Lilatate");
            respPayload["app_logo"] = DatabaseService.GetAppSetting("app_logo", "");
            respPayload["app_theme"] = DatabaseService.GetAppSetting("app_theme", "light");
            respPayload["app_language"] = DatabaseService.GetAppSetting("app_language", "fr");
            if (AuthenticationService.IsAuthenticated && AuthenticationService.CurrentUser != null)
            {
                respPayload["username"] = AuthenticationService.CurrentUser.Username;
                respPayload["role"] = AuthenticationService.CurrentUser.Role;
            }
            response["payload"] = respPayload;
            PostMessageToJs(response.ToString(Formatting.None));
        }

        // ──────────────────────────────────────────────────────────────────────
        // Customer handlers
        // ──────────────────────────────────────────────────────────────────────

        private async void HandleGetCustomers(JObject payload)
        {
            try
            {
                string search = payload != null ? (string)payload["query"] : null;
                List<Customer> customers = await CustomerService.GetCustomersAsync(search);
                int totalCount = await CustomerService.GetActiveCustomerCountAsync();

                JObject response = new JObject();
                response["action"] = "customers_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;
                respPayload["customers"] = JArray.FromObject(customers);
                respPayload["totalCount"] = totalCount;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetCustomers.", ex);
                JObject response = new JObject();
                response["action"] = "customers_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des clients.";
                respPayload["customers"] = new JArray();
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleGetCustomerById(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                string actionRequested = payload != null && payload["Action"] != null ? (string)payload["Action"] : "view";
                Customer customer = await CustomerService.GetCustomerByIdAsync(id);

                JObject response = new JObject();
                response["action"] = "customer_details";
                JObject respPayload = new JObject();
                respPayload["actionRequested"] = actionRequested;
                respPayload["success"] = customer != null;
                if (customer != null)
                {
                    respPayload["customer"] = JObject.FromObject(customer);
                }
                else
                {
                    respPayload["message"] = "Client introuvable.";
                }
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetCustomerById.", ex);
                JObject response = new JObject();
                response["action"] = "customer_details";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleAddCustomer(JObject payload)
        {
            try
            {
                decimal initialDebt = 0;
                if (payload != null && payload["InitialDebt"] != null && payload["InitialDebt"].Type != JTokenType.Null)
                    decimal.TryParse(payload["InitialDebt"].ToString(), out initialDebt);

                var customer = new Customer
                {
                    FullName = payload != null ? (string)payload["FullName"] : string.Empty,
                    Phone = payload != null ? (string)payload["Phone"] : null,
                    CIN = payload != null ? (string)payload["CIN"] : null,
                    Address = payload != null ? (string)payload["Address"] : null,
                    Notes = payload != null ? (string)payload["Notes"] : null,
                    InitialDebt = initialDebt
                };

                var result = await CustomerService.AddCustomerAsync(customer);

                JObject response = new JObject();
                response["action"] = "add_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleAddCustomer.", ex);
                JObject response = new JObject();
                response["action"] = "add_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de l'ajout.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleUpdateCustomer(JObject payload)
        {
            try
            {
                var customer = new Customer
                {
                    Id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0,
                    FullName = payload != null ? (string)payload["FullName"] : string.Empty,
                    Phone = payload != null ? (string)payload["Phone"] : null,
                    CIN = payload != null ? (string)payload["CIN"] : null,
                    Address = payload != null ? (string)payload["Address"] : null,
                    Notes = payload != null ? (string)payload["Notes"] : null
                };

                var result = await CustomerService.UpdateCustomerAsync(customer);

                JObject response = new JObject();
                response["action"] = "update_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleUpdateCustomer.", ex);
                JObject response = new JObject();
                response["action"] = "update_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de la modification.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleArchiveCustomer(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                var result = await CustomerService.ArchiveCustomerAsync(id);

                JObject response = new JObject();
                response["action"] = "archive_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleArchiveCustomer.", ex);
                JObject response = new JObject();
                response["action"] = "archive_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de l'archivage.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Debt handlers (Phase 5)
        // ──────────────────────────────────────────────────────────────────────

        private void HandleGetDebts(JObject payload)
        {
            try
            {
                string query = payload != null && payload["query"] != null ? (string)payload["query"] : string.Empty;
                string status = payload != null && payload["status"] != null ? (string)payload["status"] : null;
                string period = payload != null && payload["period"] != null ? (string)payload["period"] : null;
                string dateFrom = payload != null && payload["dateFrom"] != null ? (string)payload["dateFrom"] : null;
                string dateTo = payload != null && payload["dateTo"] != null ? (string)payload["dateTo"] : null;

                List<Debt> debts;
                if (!string.IsNullOrWhiteSpace(status) || !string.IsNullOrWhiteSpace(period) || !string.IsNullOrWhiteSpace(dateFrom) || !string.IsNullOrWhiteSpace(dateTo))
                {
                    debts = DebtService.GetDebtsByFilter(query, status, period, dateFrom, dateTo);
                }
                else
                {
                    debts = DebtService.GetAllActiveDebts(query);
                }

                JObject response = new JObject();
                response["action"] = "debts_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;

                JArray arr = new JArray();
                foreach (var d in debts)
                {
                    JObject o = new JObject();
                    o["Id"] = d.Id;
                    o["CustomerId"] = d.CustomerId;
                    o["CustomerName"] = d.CustomerFullName;
                    o["CustomerPhone"] = d.CustomerPhone;
                    o["CustomerCIN"] = d.CustomerCIN;
                    o["Amount"] = d.Amount;
                    o["PaidAmount"] = d.TotalPaid;
                    o["RemainingAmount"] = d.Remaining;
                    o["Status"] = d.Status;
                    o["DebtDate"] = d.DebtDate;
                    o["Notes"] = d.Notes;
                    o["LastPaymentDate"] = d.LastPaymentDate;
                    arr.Add(o);
                }
                respPayload["debts"] = arr;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetDebts.", ex);
                JObject response = new JObject();
                response["action"] = "debts_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des dettes.";
                respPayload["debts"] = new JArray();
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleGetCustomerDebts(JObject payload)
        {
            try
            {
                int customerId = payload != null && payload["CustomerId"] != null ? (int)payload["CustomerId"] : 0;
                var debts = DebtService.GetDebtsByCustomerId(customerId);

                JObject response = new JObject();
                response["action"] = "customer_debts_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;
                respPayload["CustomerId"] = customerId;

                JArray arr = new JArray();
                foreach (var d in debts)
                {
                    JObject o = new JObject();
                    o["Id"] = d.Id;
                    o["CustomerId"] = d.CustomerId;
                    o["Amount"] = d.Amount;
                    o["PaidAmount"] = d.TotalPaid;
                    o["RemainingAmount"] = d.Remaining;
                    o["Status"] = d.Status;
                    o["DebtDate"] = d.DebtDate;
                    o["Notes"] = d.Notes;
                    o["LastPaymentDate"] = d.LastPaymentDate;
                    arr.Add(o);
                }
                respPayload["debts"] = arr;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetCustomerDebts.", ex);
                JObject response = new JObject();
                response["action"] = "customer_debts_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des dettes du client.";
                respPayload["debts"] = new JArray();
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleGetDebtById(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                string actionRequested = payload != null && payload["Action"] != null ? (string)payload["Action"] : "view";
                var debt = DebtService.GetDebtById(id);

                JObject response = new JObject();
                response["action"] = "debt_details";
                JObject respPayload = new JObject();
                respPayload["actionRequested"] = actionRequested;

                if (debt != null)
                {
                    respPayload["success"] = true;
                    JObject o = new JObject();
                    o["Id"] = debt.Id;
                    o["CustomerId"] = debt.CustomerId;
                    o["CustomerName"] = debt.CustomerFullName;
                    o["CustomerPhone"] = debt.CustomerPhone;
                    o["CustomerCIN"] = debt.CustomerCIN;
                    o["Amount"] = debt.Amount;
                    o["PaidAmount"] = debt.TotalPaid;
                    o["RemainingAmount"] = debt.Remaining;
                    o["Status"] = debt.Status;
                    o["DebtDate"] = debt.DebtDate;
                    o["Notes"] = debt.Notes;

                    var payments = PaymentService.GetPaymentsByDebtId(debt.Id);
                    JArray payArr = new JArray();
                    foreach (var p in payments)
                    {
                        JObject po = new JObject();
                        po["Id"] = p.Id;
                        po["Amount"] = p.Amount;
                        po["PaymentDate"] = p.PaymentDate;
                        po["Notes"] = p.Notes;
                        payArr.Add(po);
                    }
                    o["Payments"] = payArr;
                    respPayload["debt"] = o;
                }
                else
                {
                    respPayload["success"] = false;
                    respPayload["message"] = "Dette introuvable.";
                }
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetDebtById.", ex);
                JObject response = new JObject();
                response["action"] = "debt_details";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleAddDebt(JObject payload)
        {
            try
            {
                decimal amount = 0;
                if (payload != null && payload["Amount"] != null && payload["Amount"].Type != JTokenType.Null)
                    amount = (decimal)payload["Amount"];

                var debt = new Debt
                {
                    CustomerId = payload != null && payload["CustomerId"] != null ? (int)payload["CustomerId"] : 0,
                    Amount = amount,
                    DebtDate = payload != null ? (string)payload["DebtDate"] : string.Empty,
                    Notes = payload != null ? (string)payload["Notes"] : null
                };

                var result = DebtService.AddDebt(debt);

                JObject response = new JObject();
                response["action"] = "add_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleAddDebt.", ex);
                JObject response = new JObject();
                response["action"] = "add_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de l'ajout de la dette.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleUpdateDebt(JObject payload)
        {
            try
            {
                decimal amount = 0;
                if (payload != null && payload["Amount"] != null && payload["Amount"].Type != JTokenType.Null)
                    amount = (decimal)payload["Amount"];

                var debt = new Debt
                {
                    Id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0,
                    Amount = amount,
                    DebtDate = payload != null ? (string)payload["DebtDate"] : string.Empty,
                    Notes = payload != null ? (string)payload["Notes"] : null
                };

                var result = DebtService.UpdateDebt(debt);

                JObject response = new JObject();
                response["action"] = "update_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleUpdateDebt.", ex);
                JObject response = new JObject();
                response["action"] = "update_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de la modification de la dette.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleGetDebtsFilter(JObject payload)
        {
            HandleGetDebts(payload);
        }

        private void HandleDeleteDebt(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                var result = DebtService.DeleteDebt(id);

                JObject response = new JObject();
                response["action"] = "delete_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                respPayload["Id"] = id;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleDeleteDebt.", ex);
                JObject response = new JObject();
                response["action"] = "delete_debt_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de la suppression de la dette.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Payment handlers (Phase 6)
        // ──────────────────────────────────────────────────────────────────────

        private void HandleAddPayment(JObject payload)
        {
            try
            {
                var payment = new Payment
                {
                    DebtId = payload != null && payload["DebtId"] != null ? (int)payload["DebtId"] : 0,
                    Amount = payload != null && payload["Amount"] != null ? (decimal)payload["Amount"] : 0,
                    PaymentDate = payload != null && payload["PaymentDate"] != null ? (string)payload["PaymentDate"] : string.Empty,
                    Notes = payload != null && payload["Notes"] != null ? (string)payload["Notes"] : null
                };

                var result = PaymentService.AddPayment(payment);

                JObject response = new JObject();
                response["action"] = "add_payment_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                if (result.Debt != null)
                {
                    JObject debtObj = new JObject();
                    debtObj["Id"] = result.Debt.Id;
                    debtObj["CustomerId"] = result.Debt.CustomerId;
                    debtObj["CustomerName"] = result.Debt.CustomerFullName;
                    debtObj["CustomerPhone"] = result.Debt.CustomerPhone;
                    debtObj["CustomerCIN"] = result.Debt.CustomerCIN;
                    debtObj["Amount"] = result.Debt.Amount;
                    debtObj["PaidAmount"] = result.Debt.TotalPaid;
                    debtObj["RemainingAmount"] = result.Debt.Remaining;
                    debtObj["Status"] = result.Debt.Status;
                    debtObj["DebtDate"] = result.Debt.DebtDate;
                    respPayload["debt"] = debtObj;
                }
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleAddPayment.", ex);
                JObject response = new JObject();
                response["action"] = "add_payment_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur système lors de l'enregistrement du versement.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleGetDebtPayments(JObject payload)
        {
            try
            {
                int debtId = payload != null && payload["DebtId"] != null ? (int)payload["DebtId"] : 0;
                var payments = PaymentService.GetPaymentsByDebtId(debtId);

                JObject response = new JObject();
                response["action"] = "debt_payments_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;
                respPayload["debtId"] = debtId;

                JArray arr = new JArray();
                foreach (var p in payments)
                {
                    JObject o = new JObject();
                    o["Id"] = p.Id;
                    o["DebtId"] = p.DebtId;
                    o["Amount"] = p.Amount;
                    o["PaymentDate"] = p.PaymentDate;
                    o["Notes"] = p.Notes;
                    o["CustomerName"] = p.CustomerFullName;
                    o["CustomerPhone"] = p.CustomerPhone;
                    o["CustomerCIN"] = p.CustomerCIN;
                    o["DebtAmount"] = p.DebtAmount;
                    arr.Add(o);
                }
                respPayload["payments"] = arr;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetDebtPayments.", ex);
                JObject response = new JObject();
                response["action"] = "debt_payments_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des versements.";
                respPayload["payments"] = new JArray();
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleGetPayments(JObject payload)
        {
            try
            {
                string query = payload != null && payload["query"] != null ? (string)payload["query"] : string.Empty;
                var payments = PaymentService.GetAllPayments(query);

                JObject response = new JObject();
                response["action"] = "payments_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;

                JArray arr = new JArray();
                foreach (var p in payments)
                {
                    JObject o = new JObject();
                    o["Id"] = p.Id;
                    o["DebtId"] = p.DebtId;
                    o["Amount"] = p.Amount;
                    o["PaymentDate"] = p.PaymentDate;
                    o["Notes"] = p.Notes;
                    o["CustomerName"] = p.CustomerFullName;
                    o["CustomerPhone"] = p.CustomerPhone;
                    o["CustomerCIN"] = p.CustomerCIN;
                    o["DebtAmount"] = p.DebtAmount;
                    arr.Add(o);
                }
                respPayload["payments"] = arr;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetPayments.", ex);
                JObject response = new JObject();
                response["action"] = "payments_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des paiements.";
                respPayload["payments"] = new JArray();
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Archive handlers (Phase 7)
        // ──────────────────────────────────────────────────────────────────────

        private async void HandleGetArchive(JObject payload)
        {
            try
            {
                var customers = await CustomerService.GetArchivedCustomersAsync();
                var debts = await CustomerService.GetArchivedDebtsAsync();
                var payments = await CustomerService.GetArchivedPaymentsAsync();

                JObject response = new JObject();
                response["action"] = "archive_list";
                JObject respPayload = new JObject();
                respPayload["success"] = true;

                // Customers
                JArray custArr = new JArray();
                foreach (var c in customers)
                {
                    JObject co = new JObject();
                    co["Id"] = c.Id;
                    co["FullName"] = c.FullName;
                    co["Phone"] = c.Phone;
                    co["CIN"] = c.CIN;
                    co["Address"] = c.Address;
                    co["Notes"] = c.Notes;
                    co["RegistrationDate"] = c.RegistrationDate;
                    co["ArchivedAt"] = c.ArchivedAt;
                    co["TotalRemaining"] = c.TotalRemaining;
                    custArr.Add(co);
                }
                respPayload["customers"] = custArr;

                // Debts
                JArray debtArr = new JArray();
                foreach (var d in debts)
                {
                    JObject dto = new JObject();
                    dto["Id"] = d.Id;
                    dto["CustomerId"] = d.CustomerId;
                    dto["CustomerName"] = d.CustomerFullName;
                    dto["CustomerPhone"] = d.CustomerPhone;
                    dto["CustomerCIN"] = d.CustomerCIN;
                    dto["Amount"] = d.Amount;
                    dto["PaidAmount"] = d.TotalPaid;
                    dto["RemainingAmount"] = d.Remaining;
                    dto["Status"] = d.Status;
                    dto["DebtDate"] = d.DebtDate;
                    dto["Notes"] = d.Notes;
                    dto["ArchivedAt"] = d.ArchivedAt;
                    debtArr.Add(dto);
                }
                respPayload["debts"] = debtArr;

                // Payments
                JArray payArr = new JArray();
                foreach (var p in payments)
                {
                    JObject po = new JObject();
                    po["Id"] = p.Id;
                    po["DebtId"] = p.DebtId;
                    po["Amount"] = p.Amount;
                    po["PaymentDate"] = p.PaymentDate;
                    po["Notes"] = p.Notes;
                    po["CustomerName"] = p.CustomerFullName;
                    po["CustomerPhone"] = p.CustomerPhone;
                    po["CustomerCIN"] = p.CustomerCIN;
                    po["DebtAmount"] = p.DebtAmount;
                    payArr.Add(po);
                }
                respPayload["payments"] = payArr;

                // Stats
                JObject statsObj = new JObject();
                statsObj["total"] = customers.Count + debts.Count + payments.Count;
                statsObj["customers"] = customers.Count;
                statsObj["debts"] = debts.Count;
                statsObj["payments"] = payments.Count;
                respPayload["stats"] = statsObj;

                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetArchive.", ex);
                JObject response = new JObject();
                response["action"] = "archive_list";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors du chargement des archives.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleRestoreCustomer(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                var result = await CustomerService.RestoreCustomerAsync(id);

                JObject response = new JObject();
                response["action"] = "restore_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                respPayload["Id"] = id;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleRestoreCustomer.", ex);
                JObject response = new JObject();
                response["action"] = "restore_customer_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors de la restauration.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private async void HandleDeleteCustomerPermanent(JObject payload)
        {
            try
            {
                int id = payload != null && payload["Id"] != null ? (int)payload["Id"] : 0;
                var result = await CustomerService.DeleteCustomerPermanentlyAsync(id);

                JObject response = new JObject();
                response["action"] = "delete_permanent_response";
                JObject respPayload = new JObject();
                respPayload["success"] = result.Success;
                respPayload["message"] = result.Message;
                respPayload["Id"] = id;
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleDeleteCustomerPermanent.", ex);
                JObject response = new JObject();
                response["action"] = "delete_permanent_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors de la suppression définitive.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Application settings & admin credentials handlers
        // ──────────────────────────────────────────────────────────────────────

        private void HandleGetAppSettings(JObject payload)
        {
            try
            {
                JObject response = new JObject();
                response["action"] = "app_settings";
                JObject respPayload = new JObject();
                respPayload["success"] = true;
                respPayload["app_title"] = DatabaseService.GetAppSetting("app_title", "Tahiri Lilatate");
                respPayload["app_logo"] = DatabaseService.GetAppSetting("app_logo", "");
                respPayload["app_theme"] = DatabaseService.GetAppSetting("app_theme", "light");
                respPayload["app_language"] = DatabaseService.GetAppSetting("app_language", "fr");
                var admin = DatabaseService.GetFirstAdminUser();
                respPayload["username"] = admin != null ? admin.Username : "Admin";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleGetAppSettings.", ex);
            }
        }

        private void HandleUpdateAppSettings(JObject payload)
        {
            try
            {
                JObject response = new JObject();
                response["action"] = "update_app_settings_response";
                JObject respPayload = new JObject();
                respPayload["success"] = true;
                respPayload["message"] = "Paramètres enregistrés avec succès.";

                if (payload != null)
                {
                    if (payload["app_title"] != null)
                    {
                        string title = (string)payload["app_title"];
                        if (string.IsNullOrWhiteSpace(title)) title = "Tahiri Lilatate";
                        DatabaseService.SetAppSetting("app_title", title.Trim());
                        respPayload["app_title"] = title.Trim();
                    }
                    if (payload["app_logo"] != null)
                    {
                        string logo = (string)payload["app_logo"];
                        DatabaseService.SetAppSetting("app_logo", logo ?? "");
                        respPayload["app_logo"] = logo ?? "";
                    }
                    if (payload["app_theme"] != null)
                    {
                        string theme = (string)payload["app_theme"];
                        DatabaseService.SetAppSetting("app_theme", theme ?? "light");
                        respPayload["app_theme"] = theme ?? "light";
                    }
                    if (payload["app_language"] != null)
                    {
                        string lang = (string)payload["app_language"];
                        DatabaseService.SetAppSetting("app_language", lang ?? "fr");
                        respPayload["app_language"] = lang ?? "fr";
                    }
                }

                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleUpdateAppSettings.", ex);
                JObject response = new JObject();
                response["action"] = "update_app_settings_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors de l'enregistrement des paramètres.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        private void HandleUpdateAdminCredentials(JObject payload)
        {
            try
            {
                string currentPassword = payload != null && payload["currentPassword"] != null ? (string)payload["currentPassword"] : "";
                string newUsername = payload != null && payload["newUsername"] != null ? (string)payload["newUsername"] : "";
                string newPassword = payload != null && payload["newPassword"] != null ? (string)payload["newPassword"] : "";

                string error;
                bool ok = DatabaseService.UpdateAdminCredentials(currentPassword, newUsername, newPassword, out error);

                JObject response = new JObject();
                response["action"] = "update_admin_credentials_response";
                JObject respPayload = new JObject();
                respPayload["success"] = ok;
                respPayload["message"] = ok ? "Les informations du compte administrateur ont été mises à jour avec succès." : error;
                if (ok)
                {
                    // Refresh from DB to get the latest saved username
                    var admin = DatabaseService.GetFirstAdminUser();
                    string updatedUsername = admin != null ? admin.Username : newUsername;
                    respPayload["username"] = updatedUsername;

                    // Sync in-memory session so the header stays correct without re-login
                    if (AuthenticationService.CurrentUser != null && !string.IsNullOrWhiteSpace(updatedUsername))
                    {
                        AuthenticationService.CurrentUser.Username = updatedUsername;
                    }
                }
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur HandleUpdateAdminCredentials.", ex);
                JObject response = new JObject();
                response["action"] = "update_admin_credentials_response";
                JObject respPayload = new JObject();
                respPayload["success"] = false;
                respPayload["message"] = "Erreur lors de la mise à jour des identifiants.";
                response["payload"] = respPayload;
                PostMessageToJs(response.ToString(Formatting.None));
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        // Bridge utility
        // ──────────────────────────────────────────────────────────────────────

        public void PostMessageToJs(string jsonMessage)
        {
            if (WebView == null || WebView.CoreWebView2 == null) return;
            Dispatcher.Invoke(new Action(() =>
            {
                try
                {
                    WebView.CoreWebView2.PostWebMessageAsString(jsonMessage);
                }
                catch (Exception ex)
                {
                    LogService.Error("Erreur lors de l'envoi du message vers JS.", ex);
                }
            }));
        }

        // ──────────────────────────────────────────────────────────────────────
        // Window controls (Native Windows Title Bar)
        // ──────────────────────────────────────────────────────────────────────

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Voulez-vous vraiment fermer l'application ?",
                "Fermer — Tahiri Lilatate",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question,
                MessageBoxResult.No);

            if (result == MessageBoxResult.Yes)
                Application.Current.Shutdown();
        }

        private void HandleUpdateTheme(JObject payload)
        {
            // Theme update handled natively by HTML
        }
    }
}