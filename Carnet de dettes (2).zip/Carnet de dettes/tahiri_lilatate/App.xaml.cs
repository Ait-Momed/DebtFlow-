using System;
using System.IO;
using System.Windows;
using tahiri_lilatate.Services;

namespace tahiri_lilatate
{
    /// <summary>
    /// Entry point for the tahiri_lilatate application.
    /// Handles global startup, database initialization, and unhandled exception logging.
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Initialize the log service first so errors during startup can be captured
            LogService.Initialize();
            LogService.Info("=== tahiri_lilatate démarrage ===");

            try
            {
                // Initialize database (create file + tables if they don't exist)
                DatabaseService.Initialize();
                LogService.Info("Base de données initialisée avec succès.");
            }
            catch (Exception ex)
            {
                LogService.Error("Échec de l'initialisation de la base de données.", ex);

                MessageBox.Show(
                    "Impossible d'ouvrir la base de données.\n\n" +
                    "Veuillez redémarrer l'application.\n\n" +
                    "Si le problème persiste, consultez le fichier de log dans :\n" +
                    LogService.LogFilePath,
                    "Erreur de base de données",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                // Shut down cleanly instead of showing a broken window
                Shutdown(1);
                return;
            }

            // Register global unhandled exception handlers
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
            Current.DispatcherUnhandledException += OnDispatcherUnhandledException;
        }

        protected override void OnExit(ExitEventArgs e)
        {
            LogService.Info("=== tahiri_lilatate arrêt ===");
            base.OnExit(e);
        }

        // ──────────────────────────────────────────────
        // Unhandled exception handlers
        // ──────────────────────────────────────────────

        private void OnDispatcherUnhandledException(object sender,
            System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            LogService.Error("Exception non gérée (Dispatcher).", e.Exception);
            e.Handled = true;

            MessageBox.Show(
                "Une erreur inattendue s'est produite.\n\nVeuillez redémarrer l'application.",
                "Erreur",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }

        private void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            if (ex != null)
                LogService.Error("Exception non gérée (AppDomain).", ex);
            else
                LogService.Error("Exception non gérée inconnue (AppDomain).");
        }
    }
}
