using System;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.Sqlite;
using tahiri_lilatate.Models;

namespace tahiri_lilatate.Services
{
    /// <summary>
    /// Manages the SQLite database lifecycle for tahiri_lilatate.
    ///
    /// Database location: %LocalAppData%\tahiri_lilatate\tahiri_lilatate.db
    ///
    /// Responsibilities:
    ///   1. Create the database directory if missing.
    ///   2. Create the database file if it does not exist.
    ///   3. Create all tables (Users, Customers, Debts, Payments, DatabaseMeta).
    ///   4. Create indexes for fast searching.
    ///   5. Enable foreign-key enforcement on every connection.
    ///   6. Manage schema version / migrations.
    ///   7. Seed the initial admin user if the Users table is empty.
    ///
    /// Design rules:
    ///   - Every public method opens its own connection and disposes it afterward.
    ///   - All SQL uses parameterized queries — never string concatenation.
    ///   - Money (DH) stored as NUMERIC, mapped to decimal in C#.
    ///   - PaidAmount / RemainingAmount / Status are NOT stored — calculated at query time.
    /// </summary>
    public static class DatabaseService
    {
        // ──────────────────────────────────────────────
        // Database location
        // ──────────────────────────────────────────────

        /// <summary>Current schema version. Increment when adding/altering tables.</summary>
        private const int CurrentSchemaVersion = 1;

        private static string _databasePath;

        /// <summary>Full path to the SQLite database file.</summary>
        public static string DatabasePath
        {
            get
            {
                if (_databasePath == null)
                {
                    string dir = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "tahiri_lilatate");
                    _databasePath = Path.Combine(dir, "tahiri_lilatate.db");
                }
                return _databasePath;
            }
        }

        /// <summary>Builds a SQLite connection string for the application database.</summary>
        private static string ConnectionString
        {
            get
            {
                var builder = new SqliteConnectionStringBuilder();
                builder.DataSource = DatabasePath;
                return builder.ToString();
            }
        }

        // ──────────────────────────────────────────────
        // Public initialization entry point
        // ──────────────────────────────────────────────

        /// <summary>
        /// Called once at application startup (from App.xaml.cs).
        /// Creates the DB directory, file, tables, indexes, and seeds admin user.
        /// Throws on critical failure — caller shows error dialog.
        /// </summary>
        public static void Initialize()
        {
            // Initialize SQLitePCL batteries provider
            SQLitePCL.Batteries_V2.Init();

            // 1. Ensure directory exists
            string dir = Path.GetDirectoryName(DatabasePath);
            Directory.CreateDirectory(dir);

            LogService.Info(string.Format("DatabaseService: chemin de la base = {0}", DatabasePath));

            // 2. Open connection (creates file if not exists) and bootstrap
            using (var conn = OpenConnection())
            {
                ApplyPragmas(conn);
                CreateTables(conn);
                CreateIndexes(conn);
                ApplyMigrations(conn);
                SeedAdminUser(conn);
            }

            LogService.Info("DatabaseService: initialisation complète.");
        }

        // ──────────────────────────────────────────────
        // Connection management
        // ──────────────────────────────────────────────

        /// <summary>
        /// Opens and returns a new SQLite connection.
        /// The caller is responsible for disposing it (use 'using').
        /// Foreign keys and WAL mode are enabled automatically via ApplyPragmas.
        /// </summary>
        public static SqliteConnection OpenConnection()
        {
            var conn = new SqliteConnection(ConnectionString);
            conn.Open();
            ApplyPragmas(conn);
            return conn;
        }

        /// <summary>
        /// Applies required SQLite PRAGMAs to an open connection.
        /// Must be called on every new connection.
        /// </summary>
        private static void ApplyPragmas(SqliteConnection conn)
        {
            ExecuteNonQuery(conn,
                "PRAGMA foreign_keys = ON;");           // enforce FK constraints
            ExecuteNonQuery(conn,
                "PRAGMA journal_mode = WAL;");          // Write-Ahead Logging
            ExecuteNonQuery(conn,
                "PRAGMA synchronous = NORMAL;");        // balanced safety/speed
            ExecuteNonQuery(conn,
                "PRAGMA temp_store = MEMORY;");         // temp tables in RAM
        }

        // ──────────────────────────────────────────────
        // Table creation
        // ──────────────────────────────────────────────

        private static void CreateTables(SqliteConnection conn)
        {
            // ── DatabaseMeta (schema version tracking) ──────────────────────
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS DatabaseMeta (
                    Key   TEXT PRIMARY KEY NOT NULL,
                    Value TEXT NOT NULL
                );");

            // ── Users (Phase 3 authentication) ──────────────────────────────
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username     TEXT    NOT NULL UNIQUE COLLATE NOCASE,
                    PasswordHash TEXT    NOT NULL,
                    Role         TEXT    NOT NULL DEFAULT 'admin',
                    CreatedAt    TEXT    NOT NULL
                );");

            // ── Customers ────────────────────────────────────────────────────
            // NOTE: No City column (intentional — see requirements).
            // CIN has no UNIQUE constraint to allow empty/null values for
            // customers without a CIN card.
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS Customers (
                    Id               INTEGER PRIMARY KEY AUTOINCREMENT,
                    FullName         TEXT    NOT NULL,
                    Phone            TEXT,
                    CIN              TEXT,
                    Address          TEXT,
                    Notes            TEXT,
                    RegistrationDate TEXT    NOT NULL,
                    IsArchived       INTEGER NOT NULL DEFAULT 0,
                    ArchivedAt       TEXT
                );");

            // ── Debts ────────────────────────────────────────────────────────
            // Amount stored as NUMERIC → maps to decimal in C#.
            // PaidAmount / RemainingAmount / Status are NOT stored here.
            // They are always computed from the Payments table.
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS Debts (
                    Id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    CustomerId INTEGER NOT NULL,
                    Amount     NUMERIC NOT NULL CHECK(Amount > 0),
                    DebtDate   TEXT    NOT NULL,
                    Notes      TEXT,
                    FOREIGN KEY (CustomerId) REFERENCES Customers(Id)
                        ON DELETE RESTRICT
                        ON UPDATE CASCADE
                );");

            // ── Payments ─────────────────────────────────────────────────────
            // One debt → many payments.
            // Amount stored as NUMERIC → decimal in C#.
            ExecuteNonQuery(conn, @"
                CREATE TABLE IF NOT EXISTS Payments (
                    Id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    DebtId      INTEGER NOT NULL,
                    Amount      NUMERIC NOT NULL CHECK(Amount > 0),
                    PaymentDate TEXT    NOT NULL,
                    Notes       TEXT,
                    FOREIGN KEY (DebtId) REFERENCES Debts(Id)
                        ON DELETE RESTRICT
                        ON UPDATE CASCADE
                );");

            LogService.Info("DatabaseService: tables créées ou déjà existantes.");
        }

        // ──────────────────────────────────────────────
        // Index creation
        // ──────────────────────────────────────────────

        private static void CreateIndexes(SqliteConnection conn)
        {
            // Customers — searchable fields
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_customers_fullname   ON Customers(FullName COLLATE NOCASE);");
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_customers_phone       ON Customers(Phone);");
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_customers_cin         ON Customers(CIN);");
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_customers_isarchived  ON Customers(IsArchived);");

            // Debts
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_debts_customerid      ON Debts(CustomerId);");

            // Payments
            ExecuteNonQuery(conn,
                "CREATE INDEX IF NOT EXISTS idx_payments_debtid       ON Payments(DebtId);");

            LogService.Info("DatabaseService: index créés ou déjà existants.");
        }

        // ──────────────────────────────────────────────
        // Schema versioning / migrations
        // ──────────────────────────────────────────────

        private static void ApplyMigrations(SqliteConnection conn)
        {
            int currentVersion = GetSchemaVersion(conn);

            if (currentVersion < CurrentSchemaVersion)
            {
                LogService.Info(string.Format("DatabaseService: migration de la version {0} → {1}.", currentVersion, CurrentSchemaVersion));
                // Future migrations go here as:
                //   if (currentVersion < 2) { ApplyMigration_V2(conn); }
                //   if (currentVersion < 3) { ApplyMigration_V3(conn); }
                SetSchemaVersion(conn, CurrentSchemaVersion);
            }
        }

        private static int GetSchemaVersion(SqliteConnection conn)
        {
            try
            {
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT Value FROM DatabaseMeta WHERE Key = 'schema_version';";
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                        return Convert.ToInt32(result);
                }
            }
            catch { }
            return 0;
        }

        private static void SetSchemaVersion(SqliteConnection conn, int version)
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO DatabaseMeta (Key, Value)
                    VALUES ('schema_version', @version)
                    ON CONFLICT(Key) DO UPDATE SET Value = excluded.Value;";
                cmd.Parameters.AddWithValue("@version", version.ToString());
                cmd.ExecuteNonQuery();
            }
        }

        // ──────────────────────────────────────────────
        // Seed admin user
        // ──────────────────────────────────────────────

        /// <summary>
        /// Inserts a default admin user if no users exist.
        /// Development credentials: admin / Admin@12345 (securely PBKDF2 hashed).
        /// </summary>
        private static void SeedAdminUser(SqliteConnection conn)
        {
            long count = 0;
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT COUNT(*) FROM Users;";
                count = (long)cmd.ExecuteScalar();
            }

            if (count == 0)
            {
                // Default administrator credentials:
                // Username : admin
                // Password : Admin@12345 (changeable via 'Mot de passe oublié ?')
                string tempPassword = "Admin@12345";
                string hash = PasswordService.HashPassword(tempPassword);

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT INTO Users (Username, PasswordHash, Role, CreatedAt)
                        VALUES (@username, @hash, @role, @createdAt);";
                    cmd.Parameters.AddWithValue("@username", "admin");
                    cmd.Parameters.AddWithValue("@hash", hash);
                    cmd.Parameters.AddWithValue("@role", "admin");
                    cmd.Parameters.AddWithValue("@createdAt", DateTime.UtcNow.ToString("o"));
                    cmd.ExecuteNonQuery();
                }

                LogService.Info("DatabaseService: compte administrateur initial créé avec hachage sécurisé PBKDF2.");
            }
        }

        // ──────────────────────────────────────────────
        // User queries and password management
        // ──────────────────────────────────────────────

        /// <summary>
        /// Retrieves a user by exact username (case-insensitive).
        /// </summary>
        public static User GetUserByUsername(string username)
        {
            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT Id, Username, PasswordHash, Role, CreatedAt FROM Users WHERE Username = @username COLLATE NOCASE LIMIT 1;";
                cmd.Parameters.AddWithValue("@username", username);
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var user = new User();
                        user.Id = Convert.ToInt32(reader["Id"]);
                        user.Username = Convert.ToString(reader["Username"]);
                        user.PasswordHash = Convert.ToString(reader["PasswordHash"]);
                        user.Role = Convert.ToString(reader["Role"]);
                        user.CreatedAt = Convert.ToString(reader["CreatedAt"]);
                        return user;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Retrieves the first user with an admin role.
        /// </summary>
        public static User GetFirstAdminUser()
        {
            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT Id, Username, PasswordHash, Role, CreatedAt FROM Users WHERE Role = 'admin' COLLATE NOCASE LIMIT 1;";
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var user = new User();
                        user.Id = Convert.ToInt32(reader["Id"]);
                        user.Username = Convert.ToString(reader["Username"]);
                        user.PasswordHash = Convert.ToString(reader["PasswordHash"]);
                        user.Role = Convert.ToString(reader["Role"]);
                        user.CreatedAt = Convert.ToString(reader["CreatedAt"]);
                        return user;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Updates the password hash for a specific user ID.
        /// </summary>
        public static void UpdateUserPassword(int userId, string newHash)
        {
            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "UPDATE Users SET PasswordHash = @hash WHERE Id = @id;";
                cmd.Parameters.AddWithValue("@hash", newHash);
                cmd.Parameters.AddWithValue("@id", userId);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Hashes a password using the secure PasswordService (PBKDF2).
        /// </summary>
        public static string HashPassword(string password)
        {
            return PasswordService.HashPassword(password);
        }

        /// <summary>
        /// Verifies a plain-text password against a stored hash.
        /// </summary>
        public static bool VerifyPassword(string password, string storedHash)
        {
            return PasswordService.VerifyPassword(password, storedHash);
        }

        /// <summary>
        /// Gets an application setting from DatabaseMeta table.
        /// </summary>
        public static string GetAppSetting(string key, string defaultValue = "")
        {
            try
            {
                using (var conn = OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT Value FROM DatabaseMeta WHERE Key = @key LIMIT 1;";
                    cmd.Parameters.AddWithValue("@key", key);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToString(result);
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.Error(string.Format("GetAppSetting: erreur pour clé {0}", key), ex);
            }
            return defaultValue;
        }

        /// <summary>
        /// Sets an application setting in DatabaseMeta table.
        /// </summary>
        public static void SetAppSetting(string key, string value)
        {
            try
            {
                using (var conn = OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT INTO DatabaseMeta (Key, Value)
                        VALUES (@key, @val)
                        ON CONFLICT(Key) DO UPDATE SET Value = excluded.Value;";
                    cmd.Parameters.AddWithValue("@key", key);
                    cmd.Parameters.AddWithValue("@val", value ?? string.Empty);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                LogService.Error(string.Format("SetAppSetting: erreur pour clé {0}", key), ex);
            }
        }

        /// <summary>
        /// Updates the admin username and/or password.
        /// </summary>
        public static bool UpdateAdminCredentials(string currentPassword, string newUsername, string newPassword, out string errorMessage)
        {
            errorMessage = string.Empty;
            var admin = GetFirstAdminUser();
            if (admin == null)
            {
                errorMessage = "Compte administrateur introuvable.";
                return false;
            }

            // Verify current password
            if (!VerifyPassword(currentPassword, admin.PasswordHash))
            {
                errorMessage = "Le mot de passe actuel est incorrect.";
                return false;
            }

            string updatedUsername = admin.Username;
            if (!string.IsNullOrWhiteSpace(newUsername))
            {
                string trimmedUser = newUsername.Trim();
                if (trimmedUser.Length < 3)
                {
                    errorMessage = "Le nom d'utilisateur doit comporter au moins 3 caractères.";
                    return false;
                }
                if (!trimmedUser.Equals(admin.Username, StringComparison.OrdinalIgnoreCase))
                {
                    var existing = GetUserByUsername(trimmedUser);
                    if (existing != null && existing.Id != admin.Id)
                    {
                        errorMessage = "Ce nom d'utilisateur est déjà utilisé.";
                        return false;
                    }
                }
                updatedUsername = trimmedUser;
            }

            string updatedHash = admin.PasswordHash;
            if (!string.IsNullOrWhiteSpace(newPassword))
            {
                if (newPassword.Length < 6)
                {
                    errorMessage = "Le nouveau mot de passe doit comporter au moins 6 caractères.";
                    return false;
                }
                updatedHash = HashPassword(newPassword);
            }

            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "UPDATE Users SET Username = @username, PasswordHash = @hash WHERE Id = @id;";
                cmd.Parameters.AddWithValue("@username", updatedUsername);
                cmd.Parameters.AddWithValue("@hash", updatedHash);
                cmd.Parameters.AddWithValue("@id", admin.Id);
                cmd.ExecuteNonQuery();
            }

            LogService.Info(string.Format("Identifiants admin mis à jour. Nouveau nom : {0}", updatedUsername));
            return true;
        }

        // ──────────────────────────────────────────────
        // Reusable query helpers
        // ──────────────────────────────────────────────

        /// <summary>
        /// Executes a non-query SQL statement on an existing open connection.
        /// Uses parameterized queries — never concatenate user input.
        /// </summary>
        public static int ExecuteNonQuery(SqliteConnection conn, string sql,
            Action<SqliteCommand> parameterize = null)
        {
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = sql;
                if (parameterize != null)
                {
                    parameterize(cmd);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Executes a non-query SQL statement on a new connection (auto-opened/closed).
        /// </summary>
        public static int ExecuteNonQuery(string sql,
            Action<SqliteCommand> parameterize = null)
        {
            using (var conn = OpenConnection())
            {
                return ExecuteNonQuery(conn, sql, parameterize);
            }
        }

        /// <summary>
        /// Executes a scalar query and returns the result, or null.
        /// </summary>
        public static object ExecuteScalar(string sql,
            Action<SqliteCommand> parameterize = null)
        {
            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = sql;
                if (parameterize != null)
                {
                    parameterize(cmd);
                }
                var result = cmd.ExecuteScalar();
                return result == DBNull.Value ? null : result;
            }
        }

        /// <summary>
        /// Executes a query and passes the reader to a callback.
        /// </summary>
        public static void ExecuteReader(string sql,
            Action<SqliteDataReader> readAction,
            Action<SqliteCommand> parameterize = null)
        {
            using (var conn = OpenConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = sql;
                if (parameterize != null)
                {
                    parameterize(cmd);
                }
                using (var reader = cmd.ExecuteReader())
                {
                    readAction(reader);
                }
            }
        }

        // ──────────────────────────────────────────────
        // Transaction support
        // ──────────────────────────────────────────────

        /// <summary>
        /// Executes a set of operations inside a single transaction.
        /// Commits on success, rolls back on any exception.
        /// Use this for multi-step operations (add debt, add payment, etc.).
        /// </summary>
        public static void ExecuteTransaction(Action<SqliteConnection, SqliteTransaction> work)
        {
            using (var conn = OpenConnection())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    work(conn, tx);
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    LogService.Error("Transaction SQLite annulée.", ex);
                    throw;
                }
            }
        }

        // ──────────────────────────────────────────────
        // Database info / diagnostics
        // ──────────────────────────────────────────────

        /// <summary>
        /// Returns the current schema version stored in DatabaseMeta.
        /// Returns 0 if the table is empty or does not exist.
        /// </summary>
        public static int GetCurrentSchemaVersion()
        {
            try
            {
                using (var conn = OpenConnection())
                    return GetSchemaVersion(conn);
            }
            catch { return -1; }
        }

        /// <summary>
        /// Returns true if the database file exists and can be opened.
        /// </summary>
        public static bool IsDatabaseAvailable()
        {
            try
            {
                if (!File.Exists(DatabasePath)) return false;
                using (var conn = OpenConnection())
                    return conn.State == ConnectionState.Open;
            }
            catch { return false; }
        }

        /// <summary>
        /// Returns the database file size in bytes, or -1 if unavailable.
        /// </summary>
        public static long GetDatabaseSizeBytes()
        {
            try
            {
                return new FileInfo(DatabasePath).Length;
            }
            catch { return -1; }
        }
    }
}
