using System;
using System.Security.Cryptography;
using System.Text;

namespace tahiri_lilatate.Services
{
    /// <summary>
    /// Cryptographic service providing PBKDF2 password hashing and verification.
    /// Never stores plain-text passwords.
    /// Format: PBKDF2:{iterations}:{saltBase64}:{hashBase64}
    /// 100% C# 5.0 compatible.
    /// </summary>
    public static class PasswordService
    {
        private const int SaltByteSize = 16;
        private const int HashByteSize = 32;
        private const int Pbkdf2Iterations = 10000;

        /// <summary>
        /// Hashes a plain-text password using PBKDF2 with a cryptographically secure random salt.
        /// </summary>
        public static string HashPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                throw new ArgumentException("Le mot de passe ne peut pas être vide.", "password");
            }

            byte[] salt = new byte[SaltByteSize];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }

            byte[] hash = GeneratePbkdf2Hash(password, salt, Pbkdf2Iterations, HashByteSize);

            string saltBase64 = Convert.ToBase64String(salt);
            string hashBase64 = Convert.ToBase64String(hash);

            return string.Format("PBKDF2:{0}:{1}:{2}", Pbkdf2Iterations, saltBase64, hashBase64);
        }

        /// <summary>
        /// Verifies a plain-text password against a stored PBKDF2 hash.
        /// Also supports legacy SHA-256 hashes from Phase 2 for backward compatibility.
        /// </summary>
        public static bool VerifyPassword(string password, string storedHash)
        {
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(storedHash))
            {
                return false;
            }

            // Check if stored hash is PBKDF2 format
            if (storedHash.StartsWith("PBKDF2:"))
            {
                string[] parts = storedHash.Split(':');
                if (parts.Length != 4)
                {
                    return false;
                }

                int iterations;
                if (!int.TryParse(parts[1], out iterations))
                {
                    return false;
                }

                byte[] salt;
                byte[] expectedHash;
                try
                {
                    salt = Convert.FromBase64String(parts[2]);
                    expectedHash = Convert.FromBase64String(parts[3]);
                }
                catch
                {
                    return false;
                }

                byte[] actualHash = GeneratePbkdf2Hash(password, salt, iterations, expectedHash.Length);
                return SlowEquals(actualHash, expectedHash);
            }

            // Fallback for Phase 2 SHA-256 legacy format (with migration support)
            return VerifyLegacySha256(password, storedHash);
        }

        /// <summary>
        /// Computes PBKDF2 hash using Rfc2898DeriveBytes.
        /// </summary>
        private static byte[] GeneratePbkdf2Hash(string password, byte[] salt, int iterations, int outputBytes)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
            {
                return pbkdf2.GetBytes(outputBytes);
            }
        }

        /// <summary>
        /// Constant-time byte comparison to mitigate timing attacks.
        /// </summary>
        private static bool SlowEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length)
            {
                return false;
            }

            int diff = 0;
            for (int i = 0; i < a.Length; i++)
            {
                diff |= a[i] ^ b[i];
            }
            return diff == 0;
        }

        /// <summary>
        /// Verifies legacy SHA-256 hash from Phase 2.
        /// </summary>
        private static bool VerifyLegacySha256(string password, string storedHash)
        {
            const string appSalt = "tahiri_lilatate_salt_2024";
            string salted = appSalt + password;
            using (var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(salted));
                string computed = Convert.ToBase64String(bytes);
                return string.Equals(computed, storedHash, StringComparison.Ordinal);
            }
        }
    }
}
