using System;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using tahiri_lilatate.Models;

namespace tahiri_lilatate.Services
{
    /// <summary>
    /// Result object for authentication attempts.
    /// </summary>
    public class AuthResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string ErrorCode { get; set; }
        public int RemainingLockoutSeconds { get; set; }

        public static AuthResult Ok()
        {
            var r = new AuthResult();
            r.Success = true;
            r.Message = "Connexion réussie.";
            return r;
        }

        public static AuthResult Fail(string message, string errorCode)
        {
            var r = new AuthResult();
            r.Success = false;
            r.Message = message;
            r.ErrorCode = errorCode;
            return r;
        }

        public static AuthResult Lockout(int seconds)
        {
            var r = new AuthResult();
            r.Success = false;
            r.Message = "Trop de tentatives. Veuillez patienter quelques instants.";
            r.ErrorCode = "locked_out";
            r.RemainingLockoutSeconds = seconds;
            return r;
        }
    }

    /// <summary>
    /// Service managing user authentication, sessions, login attempts rate limiting, and password reset.
    /// 100% C# 5.0 compatible.
    /// </summary>
    public static class AuthenticationService
    {
        private static User _currentUser;
        private static int _failedAttempts = 0;
        private static DateTime _lockoutUntil = DateTime.MinValue;
        private const int MaxFailedAttempts = 5;
        private const int LockoutDurationSeconds = 30;
        private static readonly object _lock = new object();

        /// <summary>
        /// Gets whether an active authenticated session exists.
        /// </summary>
        public static bool IsAuthenticated
        {
            get
            {
                lock (_lock)
                {
                    return _currentUser != null;
                }
            }
        }

        /// <summary>
        /// Gets the currently authenticated user (null if not logged in).
        /// </summary>
        public static User CurrentUser
        {
            get
            {
                lock (_lock)
                {
                    return _currentUser;
                }
            }
        }

        /// <summary>
        /// Authenticates the user with username and password.
        /// </summary>
        public static AuthResult Login(string username, string password)
        {
            lock (_lock)
            {
                // 1. Check lockout
                if (DateTime.UtcNow < _lockoutUntil)
                {
                    int remaining = (int)Math.Ceiling((_lockoutUntil - DateTime.UtcNow).TotalSeconds);
                    LogService.Warning(string.Format("Tentative de connexion pendant le verrouillage. Secondes restantes: {0}", remaining));
                    return AuthResult.Lockout(remaining);
                }

                // 2. Validate inputs
                if (string.IsNullOrWhiteSpace(username))
                {
                    return AuthResult.Fail("Veuillez saisir votre nom d'utilisateur.", "empty_username");
                }

                if (string.IsNullOrEmpty(password))
                {
                    return AuthResult.Fail("Veuillez saisir votre mot de passe.", "empty_password");
                }

                try
                {
                    // 3. Query user by username from SQLite
                    User user = DatabaseService.GetUserByUsername(username.Trim());

                    if (user == null)
                    {
                        RegisterFailedAttempt();
                        LogService.Warning(string.Format("Échec de connexion : utilisateur '{0}' non trouvé.", username.Trim()));
                        return AuthResult.Fail("Nom d'utilisateur ou mot de passe incorrect.", "invalid_credentials");
                    }

                    // 4. Verify Role is Admin
                    if (!string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
                    {
                        RegisterFailedAttempt();
                        LogService.Warning(string.Format("Échec de connexion : rôle '{0}' non autorisé.", user.Role));
                        return AuthResult.Fail("Nom d'utilisateur ou mot de passe incorrect.", "invalid_credentials");
                    }

                    // 5. Verify Password
                    bool isValid = PasswordService.VerifyPassword(password, user.PasswordHash);
                    if (!isValid)
                    {
                        RegisterFailedAttempt();
                        LogService.Warning(string.Format("Échec de connexion : mot de passe incorrect pour '{0}'.", username.Trim()));
                        return AuthResult.Fail("Nom d'utilisateur ou mot de passe incorrect.", "invalid_credentials");
                    }

                    // If password was stored in legacy SHA-256 format, upgrade to PBKDF2 automatically
                    if (!user.PasswordHash.StartsWith("PBKDF2:"))
                    {
                        try
                        {
                            string newHash = PasswordService.HashPassword(password);
                            DatabaseService.UpdateUserPassword(user.Id, newHash);
                            LogService.Info("Mot de passe mis à niveau vers PBKDF2 pour l'utilisateur.");
                        }
                        catch (Exception ex)
                        {
                            LogService.Error("Erreur lors de la mise à niveau du hash PBKDF2.", ex);
                        }
                    }

                    // 6. Login successful: create session and reset attempt counters
                    _failedAttempts = 0;
                    _lockoutUntil = DateTime.MinValue;
                    _currentUser = new User();
                    _currentUser.Id = user.Id;
                    _currentUser.Username = user.Username;
                    _currentUser.Role = user.Role;
                    _currentUser.CreatedAt = user.CreatedAt;
                    // Never store PasswordHash in session

                    LogService.Info(string.Format("Connexion réussie pour l'administrateur '{0}' (ID: {1}).", user.Username, user.Id));
                    return AuthResult.Ok();
                }
                catch (Exception ex)
                {
                    LogService.Error("Erreur technique lors de la connexion.", ex);
                    return AuthResult.Fail("Une erreur est survenue. Veuillez réessayer.", "technical_error");
                }
            }
        }

        /// <summary>
        /// Logs out the current user and clears session state.
        /// </summary>
        public static void Logout()
        {
            lock (_lock)
            {
                if (_currentUser != null)
                {
                    LogService.Info(string.Format("Déconnexion de l'utilisateur '{0}'.", _currentUser.Username));
                }
                _currentUser = null;
            }
        }

        /// <summary>
        /// Resets the Admin password locally.
        /// Validates policies: minimum 8 characters, letters and digits, confirmation matches.
        /// </summary>
        public static AuthResult ResetAdminPassword(string newPassword, string confirmPassword)
        {
            lock (_lock)
            {
                if (string.IsNullOrEmpty(newPassword))
                {
                    return AuthResult.Fail("Veuillez saisir le nouveau mot de passe.", "empty_password");
                }

                if (newPassword.Length < 8)
                {
                    return AuthResult.Fail("Le mot de passe doit comporter au moins 8 caractères.", "password_too_short");
                }

                bool hasLetter = Regex.IsMatch(newPassword, @"[a-zA-Z]");
                bool hasDigit = Regex.IsMatch(newPassword, @"[0-9]");
                if (!hasLetter || !hasDigit)
                {
                    return AuthResult.Fail("Le mot de passe doit contenir à la fois des lettres et des chiffres.", "password_too_simple");
                }

                if (!string.Equals(newPassword, confirmPassword, StringComparison.Ordinal))
                {
                    return AuthResult.Fail("Les mots de passe ne correspondent pas.", "passwords_do_not_match");
                }

                try
                {
                    // Find the admin user
                    User adminUser = DatabaseService.GetFirstAdminUser();
                    if (adminUser == null)
                    {
                        return AuthResult.Fail("Aucun compte administrateur trouvé.", "admin_not_found");
                    }

                    string newHash = PasswordService.HashPassword(newPassword);
                    DatabaseService.UpdateUserPassword(adminUser.Id, newHash);

                    LogService.Info(string.Format("Mot de passe de l'administrateur '{0}' réinitialisé avec succès.", adminUser.Username));
                    return AuthResult.Ok();
                }
                catch (Exception ex)
                {
                    LogService.Error("Erreur technique lors de la réinitialisation du mot de passe.", ex);
                    return AuthResult.Fail("Une erreur est survenue lors de la réinitialisation. Veuillez réessayer.", "technical_error");
                }
            }
        }

        private static void RegisterFailedAttempt()
        {
            _failedAttempts++;
            LogService.Warning(string.Format("Échec de connexion #{0} / {1}.", _failedAttempts, MaxFailedAttempts));

            if (_failedAttempts >= MaxFailedAttempts)
            {
                _lockoutUntil = DateTime.UtcNow.AddSeconds(LockoutDurationSeconds);
                LogService.Warning(string.Format("Verrouillage temporaire activé pendant {0} secondes.", LockoutDurationSeconds));
            }
        }
    }
}
