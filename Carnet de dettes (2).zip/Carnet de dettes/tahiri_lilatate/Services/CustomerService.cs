using System;
using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using tahiri_lilatate.Models;

namespace tahiri_lilatate.Services
{
    /// <summary>
    /// Result wrapper for customer service operations.
    /// </summary>
    public class CustomerResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public Customer Customer { get; set; }

        public static CustomerResult Ok(Customer customer, string message = null)
        {
            var res = new CustomerResult();
            res.Success = true;
            res.Customer = customer;
            res.Message = message;
            return res;
        }

        public static CustomerResult Fail(string message)
        {
            var res = new CustomerResult();
            res.Success = false;
            res.Message = message;
            return res;
        }
    }

    /// <summary>
    /// Handles all customer business logic and database persistence for Phase 4.
    /// 100% C# 5.0 compatible.
    /// All queries use parameterized SQL via Microsoft.Data.Sqlite.
    /// </summary>
    public static class CustomerService
    {
        // ──────────────────────────────────────────────
        // Validation helpers
        // ──────────────────────────────────────────────

        /// <summary>
        /// Validates phone number format if provided.
        /// Allows digits, spaces, hyphens, and leading plus.
        /// </summary>
        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return true;
            string trimmed = phone.Trim();
            // Basic international or Moroccan standard: 6 to 20 chars of digits, spaces, -, +
            return Regex.IsMatch(trimmed, @"^[+]?[0-9\s\-]{6,20}$");
        }

        /// <summary>
        /// Cleans and formats CIN string (trims and normalizes spaces).
        /// </summary>
        public static string NormalizeCIN(string cin)
        {
            if (string.IsNullOrWhiteSpace(cin)) return null;
            return cin.Trim().ToUpperInvariant();
        }

        // ──────────────────────────────────────────────
        // Read operations
        // ──────────────────────────────────────────────

        /// <summary>
        /// Retrieves all active customers (IsArchived = 0), optionally filtered by a search query.
        /// Search matches against FullName, Phone, or CIN.
        /// </summary>
        public static async Task<List<Customer>> GetCustomersAsync(string searchQuery = null)
        {
            return await Task.Run(new Func<List<Customer>>(() =>
            {
                var list = new List<Customer>();

                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    bool hasSearch = !string.IsNullOrWhiteSpace(searchQuery);

                    if (hasSearch)
                    {
                        string term = "%" + searchQuery.Trim() + "%";
                        cmd.CommandText = @"
                            SELECT 
                                c.Id, c.FullName, c.Phone, c.CIN, c.Address, c.Notes, c.RegistrationDate, c.IsArchived, c.ArchivedAt,
                                IFNULL((
                                    SELECT SUM(d.Amount) - IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId = d.Id), 0)
                                    FROM Debts d
                                    WHERE d.CustomerId = c.Id
                                ), 0) AS TotalRemaining
                            FROM Customers c
                            WHERE c.IsArchived = 0
                              AND (
                                  c.FullName LIKE @term
                                  OR c.Phone LIKE @term
                                  OR c.CIN LIKE @term
                              )
                            ORDER BY c.Id DESC;";
                        cmd.Parameters.AddWithValue("@term", term);
                    }
                    else
                    {
                        cmd.CommandText = @"
                            SELECT 
                                c.Id, c.FullName, c.Phone, c.CIN, c.Address, c.Notes, c.RegistrationDate, c.IsArchived, c.ArchivedAt,
                                IFNULL((
                                    SELECT SUM(d.Amount) - IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId = d.Id), 0)
                                    FROM Debts d
                                    WHERE d.CustomerId = c.Id
                                ), 0) AS TotalRemaining
                            FROM Customers c
                            WHERE c.IsArchived = 0
                            ORDER BY c.Id DESC;";
                    }

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(ReadCustomerFromReader(reader));
                        }
                    }
                }

                return list;
            }));
        }

        /// <summary>
        /// Retrieves a single customer by Id.
        /// </summary>
        public static async Task<Customer> GetCustomerByIdAsync(int id)
        {
            return await Task.Run(new Func<Customer>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT Id, FullName, Phone, CIN, Address, Notes, RegistrationDate, IsArchived, ArchivedAt
                        FROM Customers
                        WHERE Id = @id;";
                    cmd.Parameters.AddWithValue("@id", id);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return ReadCustomerFromReader(reader);
                        }
                    }
                }

                return null;
            }));
        }

        /// <summary>
        /// Gets the total count of active customers.
        /// </summary>
        public static async Task<int> GetActiveCustomerCountAsync()
        {
            return await Task.Run(new Func<int>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT COUNT(*) FROM Customers WHERE IsArchived = 0;";
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }));
        }

        // ──────────────────────────────────────────────
        // Create operation
        // ──────────────────────────────────────────────

        /// <summary>
        /// Adds a new customer to the database.
        /// FullName is required. RegistrationDate is set automatically.
        /// </summary>
        public static async Task<CustomerResult> AddCustomerAsync(Customer customer)
        {
            if (customer == null)
            {
                return CustomerResult.Fail("Données client invalides.");
            }

            string fullName = customer.FullName != null ? customer.FullName.Trim() : "";
            if (string.IsNullOrEmpty(fullName))
            {
                return CustomerResult.Fail("Le nom complet est obligatoire.");
            }

            string phone = customer.Phone != null ? customer.Phone.Trim() : null;
            if (!string.IsNullOrEmpty(phone) && !IsValidPhone(phone))
            {
                return CustomerResult.Fail("Le format du numéro de téléphone n'est pas valide.");
            }

            string cin = NormalizeCIN(customer.CIN);

            return await Task.Run(new Func<CustomerResult>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                {
                    // Check duplicate active CIN if provided
                    if (!string.IsNullOrEmpty(cin))
                    {
                        using (var checkCmd = conn.CreateCommand())
                        {
                            checkCmd.CommandText = @"
                                SELECT COUNT(*) FROM Customers 
                                WHERE IsArchived = 0 AND UPPER(TRIM(CIN)) = @cin;";
                            checkCmd.Parameters.AddWithValue("@cin", cin);

                            long count = Convert.ToInt64(checkCmd.ExecuteScalar());
                            if (count > 0)
                            {
                                return CustomerResult.Fail("Un client actif avec ce numéro de CIN existe déjà.");
                            }
                        }
                    }

                    // Insert customer
                    string regDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"
                            INSERT INTO Customers (
                                FullName, Phone, CIN, Address, Notes, RegistrationDate, IsArchived, ArchivedAt
                            ) VALUES (
                                @fullName, @phone, @cin, @address, @notes, @regDate, 0, NULL
                            );
                            SELECT last_insert_rowid();";

                        cmd.Parameters.AddWithValue("@fullName", fullName);
                        cmd.Parameters.AddWithValue("@phone", (object)phone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@cin", (object)cin ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@address", string.IsNullOrWhiteSpace(customer.Address) ? (object)DBNull.Value : customer.Address.Trim());
                        cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(customer.Notes) ? (object)DBNull.Value : customer.Notes.Trim());
                        cmd.Parameters.AddWithValue("@regDate", regDate);

                        long newId = Convert.ToInt64(cmd.ExecuteScalar());
                        customer.Id = (int)newId;
                        customer.FullName = fullName;
                        customer.Phone = phone;
                        customer.CIN = cin;
                        customer.RegistrationDate = regDate;
                        customer.IsArchived = false;
                        customer.ArchivedAt = null;

                        if (customer.InitialDebt > 0)
                        {
                            using (var debtCmd = conn.CreateCommand())
                            {
                                debtCmd.CommandText = @"
                                    INSERT INTO Debts (CustomerId, Amount, DebtDate, Notes)
                                    VALUES (@customerId, @amount, @debtDate, @debtNotes);";
                                debtCmd.Parameters.AddWithValue("@customerId", customer.Id);
                                debtCmd.Parameters.AddWithValue("@amount", customer.InitialDebt);
                                debtCmd.Parameters.AddWithValue("@debtDate", DateTime.Now.ToString("yyyy-MM-dd"));
                                debtCmd.Parameters.AddWithValue("@debtNotes", "Dette initiale");
                                debtCmd.ExecuteNonQuery();
                            }
                            customer.TotalRemaining = customer.InitialDebt;
                        }

                        LogService.Info(string.Format("Nouveau client créé : #{0} {1}", customer.Id, customer.FullName));
                        return CustomerResult.Ok(customer, "Client ajouté avec succès.");
                    }
                }
            }));
        }

        // ──────────────────────────────────────────────
        // Update operation
        // ──────────────────────────────────────────────

        /// <summary>
        /// Updates an existing customer's editable fields (FullName, Phone, CIN, Address, Notes).
        /// Id, RegistrationDate, IsArchived, and ArchivedAt are strictly preserved.
        /// </summary>
        public static async Task<CustomerResult> UpdateCustomerAsync(Customer customer)
        {
            if (customer == null || customer.Id <= 0)
            {
                return CustomerResult.Fail("Client introuvable.");
            }

            string fullName = customer.FullName != null ? customer.FullName.Trim() : "";
            if (string.IsNullOrEmpty(fullName))
            {
                return CustomerResult.Fail("Le nom complet est obligatoire.");
            }

            string phone = customer.Phone != null ? customer.Phone.Trim() : null;
            if (!string.IsNullOrEmpty(phone) && !IsValidPhone(phone))
            {
                return CustomerResult.Fail("Le format du numéro de téléphone n'est pas valide.");
            }

            string cin = NormalizeCIN(customer.CIN);

            return await Task.Run(new Func<CustomerResult>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                {
                    // Check duplicate active CIN on other customers
                    if (!string.IsNullOrEmpty(cin))
                    {
                        using (var checkCmd = conn.CreateCommand())
                        {
                            checkCmd.CommandText = @"
                                SELECT COUNT(*) FROM Customers 
                                WHERE Id != @id AND IsArchived = 0 AND UPPER(TRIM(CIN)) = @cin;";
                            checkCmd.Parameters.AddWithValue("@id", customer.Id);
                            checkCmd.Parameters.AddWithValue("@cin", cin);

                            long count = Convert.ToInt64(checkCmd.ExecuteScalar());
                            if (count > 0)
                            {
                                return CustomerResult.Fail("Un autre client actif avec ce numéro de CIN existe déjà.");
                            }
                        }
                    }

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"
                            UPDATE Customers
                            SET FullName = @fullName,
                                Phone = @phone,
                                CIN = @cin,
                                Address = @address,
                                Notes = @notes
                            WHERE Id = @id;";

                        cmd.Parameters.AddWithValue("@id", customer.Id);
                        cmd.Parameters.AddWithValue("@fullName", fullName);
                        cmd.Parameters.AddWithValue("@phone", (object)phone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@cin", (object)cin ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@address", string.IsNullOrWhiteSpace(customer.Address) ? (object)DBNull.Value : customer.Address.Trim());
                        cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(customer.Notes) ? (object)DBNull.Value : customer.Notes.Trim());

                        int affected = cmd.ExecuteNonQuery();
                        if (affected == 0)
                        {
                            return CustomerResult.Fail("Client introuvable ou non modifié.");
                        }

                        LogService.Info(string.Format("Client mis à jour : #{0} {1}", customer.Id, fullName));
                        return CustomerResult.Ok(customer, "Client modifié avec succès.");
                    }
                }
            }));
        }

        // ──────────────────────────────────────────────
        // Archive operations (Phase 7)
        // ──────────────────────────────────────────────

        /// <summary>
        /// Marks a customer as archived (IsArchived = 1, ArchivedAt = current timestamp).
        /// Data is preserved in SQLite; customer is never permanently deleted.
        /// </summary>
        public static async Task<CustomerResult> ArchiveCustomerAsync(int id)
        {
            if (id <= 0)
            {
                return CustomerResult.Fail("Identifiant de client invalide.");
            }

            return await Task.Run(new Func<CustomerResult>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    string archivedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    cmd.CommandText = @"
                        UPDATE Customers
                        SET IsArchived = 1,
                            ArchivedAt = @archivedAt
                        WHERE Id = @id;";

                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@archivedAt", archivedAt);

                    int affected = cmd.ExecuteNonQuery();
                    if (affected == 0)
                    {
                        return CustomerResult.Fail("Client introuvable.");
                    }

                    LogService.Info(string.Format("Client archivé : #{0} à {1}", id, archivedAt));
                    return CustomerResult.Ok(null, "Client archivé avec succès.");
                }
            }));
        }

        /// <summary>
        /// Restores an archived customer to active status (IsArchived = 0, ArchivedAt = NULL).
        /// </summary>
        public static async Task<CustomerResult> RestoreCustomerAsync(int id)
        {
            if (id <= 0)
            {
                return CustomerResult.Fail("Identifiant de client invalide.");
            }

            return await Task.Run(new Func<CustomerResult>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        UPDATE Customers
                        SET IsArchived = 0,
                            ArchivedAt = NULL
                        WHERE Id = @id;";

                    cmd.Parameters.AddWithValue("@id", id);

                    int affected = cmd.ExecuteNonQuery();
                    if (affected == 0)
                    {
                        return CustomerResult.Fail("Client introuvable.");
                    }

                    LogService.Info(string.Format("Client restauré : #{0}", id));
                    return CustomerResult.Ok(null, "Client restauré avec succès.");
                }
            }));
        }

        /// <summary>
        /// Permanently deletes an archived customer and all associated debts and payments.
        /// Strict transaction with cascaded deletes.
        /// </summary>
        public static async Task<CustomerResult> DeleteCustomerPermanentlyAsync(int id)
        {
            if (id <= 0)
            {
                return CustomerResult.Fail("Identifiant de client invalide.");
            }

            return await Task.Run(new Func<CustomerResult>(() =>
            {
                using (var conn = DatabaseService.OpenConnection())
                using (var tx = conn.BeginTransaction())
                {
                    try
                    {
                        // 1. Delete payments belonging to debts of this customer
                        using (var cmdPay = conn.CreateCommand())
                        {
                            cmdPay.Transaction = tx;
                            cmdPay.CommandText = @"
                                DELETE FROM Payments 
                                WHERE DebtId IN (SELECT Id FROM Debts WHERE CustomerId = @id);";
                            cmdPay.Parameters.AddWithValue("@id", id);
                            cmdPay.ExecuteNonQuery();
                        }

                        // 2. Delete debts of this customer
                        using (var cmdDebt = conn.CreateCommand())
                        {
                            cmdDebt.Transaction = tx;
                            cmdDebt.CommandText = "DELETE FROM Debts WHERE CustomerId = @id;";
                            cmdDebt.Parameters.AddWithValue("@id", id);
                            cmdDebt.ExecuteNonQuery();
                        }

                        // 3. Delete customer
                        using (var cmdCust = conn.CreateCommand())
                        {
                            cmdCust.Transaction = tx;
                            cmdCust.CommandText = "DELETE FROM Customers WHERE Id = @id;";
                            cmdCust.Parameters.AddWithValue("@id", id);
                            int affected = cmdCust.ExecuteNonQuery();
                            if (affected == 0)
                            {
                                tx.Rollback();
                                return CustomerResult.Fail("Client introuvable.");
                            }
                        }

                        tx.Commit();
                        LogService.Info(string.Format("Client définitivement supprimé : #{0}", id));
                        return CustomerResult.Ok(null, "Client et données associées définitivement supprimés.");
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        LogService.Error(string.Format("Erreur suppression définitive client #{0}", id), ex);
                        return CustomerResult.Fail("Erreur lors de la suppression définitive.");
                    }
                }
            }));
        }

        /// <summary>
        /// Retrieves all archived customers.
        /// </summary>
        public static async Task<List<Customer>> GetArchivedCustomersAsync()
        {
            return await Task.Run(new Func<List<Customer>>(() =>
            {
                var list = new List<Customer>();
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT 
                            c.Id, c.FullName, c.Phone, c.CIN, c.Address, c.Notes, c.RegistrationDate, c.IsArchived, c.ArchivedAt,
                            IFNULL((
                                SELECT SUM(d.Amount) - IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId = d.Id), 0)
                                FROM Debts d
                                WHERE d.CustomerId = c.Id
                            ), 0) AS TotalRemaining
                        FROM Customers c
                        WHERE c.IsArchived = 1
                        ORDER BY c.ArchivedAt DESC, c.Id DESC;";

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var cust = ReadCustomerFromReader(reader);
                            if (reader["TotalRemaining"] != DBNull.Value)
                            {
                                cust.TotalRemaining = Convert.ToDecimal(reader["TotalRemaining"]);
                            }
                            list.Add(cust);
                        }
                    }
                }
                return list;
            }));
        }

        /// <summary>
        /// Retrieves all archived debts (debts belonging to archived customers).
        /// </summary>
        public static async Task<List<Debt>> GetArchivedDebtsAsync()
        {
            return await Task.Run(new Func<List<Debt>>(() =>
            {
                var list = new List<Debt>();
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT 
                            d.*,
                            IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
                            c.FullName, c.Phone, c.CIN, c.Address, c.ArchivedAt
                        FROM Debts d
                        JOIN Customers c ON d.CustomerId = c.Id
                        WHERE c.IsArchived = 1
                        ORDER BY c.ArchivedAt DESC, d.Id DESC;";

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var debt = new Debt
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                CustomerId = Convert.ToInt32(reader["CustomerId"]),
                                Amount = Convert.ToDecimal(reader["Amount"]),
                                DebtDate = Convert.ToString(reader["DebtDate"]),
                                Notes = reader["Notes"] != DBNull.Value ? Convert.ToString(reader["Notes"]) : null,
                                TotalPaid = Convert.ToDecimal(reader["TotalPaid"])
                            };

                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                string colName = reader.GetName(i);
                                if (colName.Equals("FullName", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    debt.CustomerFullName = Convert.ToString(reader[i]);
                                else if (colName.Equals("Phone", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    debt.CustomerPhone = Convert.ToString(reader[i]);
                                else if (colName.Equals("CIN", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    debt.CustomerCIN = Convert.ToString(reader[i]);
                            }
                            list.Add(debt);
                        }
                    }
                }
                return list;
            }));
        }

        /// <summary>
        /// Retrieves all archived payments (payments belonging to archived customers).
        /// </summary>
        public static async Task<List<Payment>> GetArchivedPaymentsAsync()
        {
            return await Task.Run(new Func<List<Payment>>(() =>
            {
                var list = new List<Payment>();
                using (var conn = DatabaseService.OpenConnection())
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT 
                            p.*,
                            d.Amount AS DebtAmount,
                            c.FullName AS CustomerFullName,
                            c.Phone AS CustomerPhone,
                            c.CIN AS CustomerCIN
                        FROM Payments p
                        JOIN Debts d ON p.DebtId = d.Id
                        JOIN Customers c ON d.CustomerId = c.Id
                        WHERE c.IsArchived = 1
                        ORDER BY p.PaymentDate DESC, p.Id DESC;";

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var p = new Payment
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                DebtId = Convert.ToInt32(reader["DebtId"]),
                                Amount = Convert.ToDecimal(reader["Amount"]),
                                PaymentDate = Convert.ToString(reader["PaymentDate"]),
                                Notes = reader["Notes"] != DBNull.Value ? Convert.ToString(reader["Notes"]) : null
                            };

                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                string name = reader.GetName(i);
                                if (name.Equals("CustomerFullName", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    p.CustomerFullName = Convert.ToString(reader[i]);
                                else if (name.Equals("CustomerPhone", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    p.CustomerPhone = Convert.ToString(reader[i]);
                                else if (name.Equals("CustomerCIN", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    p.CustomerCIN = Convert.ToString(reader[i]);
                                else if (name.Equals("DebtAmount", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                                    p.DebtAmount = Convert.ToDecimal(reader[i]);
                            }
                            list.Add(p);
                        }
                    }
                }
                return list;
            }));
        }

        // ──────────────────────────────────────────────
        // Private mapping helper
        // ──────────────────────────────────────────────

        private static Customer ReadCustomerFromReader(SqliteDataReader reader)
        {
            var customer = new Customer();
            customer.Id = Convert.ToInt32(reader["Id"]);
            customer.FullName = reader["FullName"].ToString();
            customer.Phone = reader["Phone"] != DBNull.Value ? reader["Phone"].ToString() : null;
            customer.CIN = reader["CIN"] != DBNull.Value ? reader["CIN"].ToString() : null;
            customer.Address = reader["Address"] != DBNull.Value ? reader["Address"].ToString() : null;
            customer.Notes = reader["Notes"] != DBNull.Value ? reader["Notes"].ToString() : null;
            customer.RegistrationDate = reader["RegistrationDate"].ToString();
            customer.IsArchived = Convert.ToInt32(reader["IsArchived"]) == 1;
            customer.ArchivedAt = reader["ArchivedAt"] != DBNull.Value ? reader["ArchivedAt"].ToString() : null;

            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Equals("TotalRemaining", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                {
                    customer.TotalRemaining = Convert.ToDecimal(reader[i]);
                    break;
                }
            }

            return customer;
        }
    }
}
