using System;
using System.IO;

namespace tahiri_lilatate.Services
{
    /// <summary>
    /// Simple file-based logger.
    /// Writes timestamped entries to %LocalAppData%\tahiri_lilatate\Logs\app.log.
    /// Thread-safe via lock for single-process desktop use.
    ///
    /// SECURITY: Never log plain-text passwords, password hashes, or
    ///           sensitive personal data unnecessarily.
    /// </summary>
    public static class LogService
    {
        // ──────────────────────────────────────────────
        // Configuration
        // ──────────────────────────────────────────────

        private static string _logFilePath;
        private static readonly object _lock = new object();

        /// <summary>Full path to the current log file.</summary>
        public static string LogFilePath
        {
            get { return _logFilePath != null ? _logFilePath : "log not initialized"; }
        }

        // ──────────────────────────────────────────────
        // Initialization
        // ──────────────────────────────────────────────

        /// <summary>
        /// Must be called once at application startup before any logging.
        /// Creates the log directory and file if they do not exist.
        /// Rotates old log if it exceeds 5 MB.
        /// </summary>
        public static void Initialize()
        {
            try
            {
                string appDataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "tahiri_lilatate",
                    "Logs");

                Directory.CreateDirectory(appDataDir);

                // Use a daily log file: app_2026-09-15.log
                string dateStamp = DateTime.Now.ToString("yyyy-MM-dd");
                _logFilePath = Path.Combine(appDataDir, string.Format("app_{0}.log", dateStamp));

                // Rotate if file exceeds 5 MB
                if (File.Exists(_logFilePath))
                {
                    var info = new FileInfo(_logFilePath);
                    if (info.Length > 5 * 1024 * 1024)
                    {
                        string archivePath = Path.Combine(appDataDir,
                            string.Format("app_{0}_{1:HHmmss}.bak.log", dateStamp, DateTime.Now));
                        File.Move(_logFilePath, archivePath);
                    }
                }
            }
            catch
            {
                // If logging cannot be initialized, silently fall back to no-op
                _logFilePath = null;
            }
        }

        // ──────────────────────────────────────────────
        // Log methods
        // ──────────────────────────────────────────────

        /// <summary>Logs an informational message.</summary>
        public static void Info(string message)
        {
            Write("INFO ", message, null);
        }

        /// <summary>Logs a warning message.</summary>
        public static void Warning(string message)
        {
            Write("WARN ", message, null);
        }

        /// <summary>Logs an error message with optional exception details.</summary>
        public static void Error(string message, Exception ex = null)
        {
            Write("ERROR", message, ex);
        }

        // ──────────────────────────────────────────────
        // Internal
        // ──────────────────────────────────────────────

        private static void Write(string level, string message, Exception ex)
        {
            if (_logFilePath == null) return;

            try
            {
                string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string line = string.Format("[{0}] [{1}] {2}", timestamp, level, message);

                if (ex != null)
                {
                    Exception curr = ex;
                    while (curr != null)
                    {
                        line += Environment.NewLine + "  EXCEPTION [" + curr.GetType().Name + "]: " + curr.Message
                             + Environment.NewLine + "  STACK: " + curr.StackTrace;
                        curr = curr.InnerException;
                    }
                }

                lock (_lock)
                {
                    File.AppendAllText(_logFilePath, line + Environment.NewLine);
                }

#if DEBUG
                System.Diagnostics.Debug.WriteLine(line);
#endif
            }
            catch
            {
                // Never throw from a logger
            }
        }
    }
}
