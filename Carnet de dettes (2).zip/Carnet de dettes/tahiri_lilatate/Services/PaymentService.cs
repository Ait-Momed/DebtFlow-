using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using tahiri_lilatate.Models;

namespace tahiri_lilatate.Services
{
    public class PaymentResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public Payment Payment { get; set; }
        public Debt Debt { get; set; }
    }

    /// <summary>
    /// Service managing payments and partial payments for debts.
    /// 100% C# 5.0 compatible.
    /// </summary>
    public static class PaymentService
    {
        private static Payment MapReaderToPayment(SqliteDataReader reader)
        {
            var p = new Payment();
            p.Id = Convert.ToInt32(reader["Id"]);
            p.DebtId = Convert.ToInt32(reader["DebtId"]);
            p.Amount = Convert.ToDecimal(reader["Amount"]);
            p.PaymentDate = Convert.ToString(reader["PaymentDate"]);
            p.Notes = reader["Notes"] != DBNull.Value ? Convert.ToString(reader["Notes"]) : null;

            for (int i = 0; i < reader.FieldCount; i++)
            {
                string name = reader.GetName(i);
                if (name.Equals("CustomerFullName", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    p.CustomerFullName = Convert.ToString(reader[i]);
                else if (name.Equals("CustomerPhone", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    p.CustomerPhone = Convert.ToString(reader[i]);
                else if (name.Equals("CustomerCIN", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    p.CustomerCIN = Convert.ToString(reader[i]);
                else if (name.Equals("DebtAmount", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    p.DebtAmount = Convert.ToDecimal(reader[i]);
            }

            return p;
        }

        public static List<Payment> GetPaymentsByDebtId(int debtId)
        {
            var list = new List<Payment>();
            string sql = @"
                SELECT 
                    p.*,
                    d.Amount AS DebtAmount,
                    c.FullName AS CustomerFullName,
                    c.Phone AS CustomerPhone,
                    c.CIN AS CustomerCIN
                FROM Payments p
                JOIN Debts d ON p.DebtId = d.Id
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE p.DebtId = @debtId
                ORDER BY p.PaymentDate DESC, p.Id DESC;
            ";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                while (reader.Read())
                {
                    list.Add(MapReaderToPayment(reader));
                }
            }, cmd =>
            {
                cmd.Parameters.AddWithValue("@debtId", debtId);
            });

            return list;
        }

        public static List<Payment> GetAllPayments(string searchQuery)
        {
            var list = new List<Payment>();
            string sql = @"
                SELECT 
                    p.*,
                    d.Amount AS DebtAmount,
                    c.FullName AS CustomerFullName,
                    c.Phone AS CustomerPhone,
                    c.CIN AS CustomerCIN
                FROM Payments p
                JOIN Debts d ON p.DebtId = d.Id
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE c.IsArchived = 0
            ";

            if (!string.IsNullOrWhiteSpace(searchQuery))
            {
                sql += " AND (c.FullName LIKE @query OR c.Phone LIKE @query OR c.CIN LIKE @query) ";
            }

            sql += " ORDER BY p.PaymentDate DESC, p.Id DESC;";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                while (reader.Read())
                {
                    list.Add(MapReaderToPayment(reader));
                }
            }, cmd =>
            {
                if (!string.IsNullOrWhiteSpace(searchQuery))
                {
                    cmd.Parameters.AddWithValue("@query", "%" + searchQuery.Trim() + "%");
                }
            });

            return list;
        }

        public static Payment GetPaymentById(int id)
        {
            Payment payment = null;
            string sql = @"
                SELECT 
                    p.*,
                    d.Amount AS DebtAmount,
                    c.FullName AS CustomerFullName,
                    c.Phone AS CustomerPhone,
                    c.CIN AS CustomerCIN
                FROM Payments p
                JOIN Debts d ON p.DebtId = d.Id
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE p.Id = @id LIMIT 1;
            ";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                if (reader.Read())
                {
                    payment = MapReaderToPayment(reader);
                }
            }, cmd =>
            {
                cmd.Parameters.AddWithValue("@id", id);
            });

            return payment;
        }

        public static PaymentResult AddPayment(Payment payment)
        {
            var res = new PaymentResult();
            if (payment == null)
            {
                res.Success = false;
                res.Message = "Données de paiement invalides.";
                return res;
            }

            if (payment.Amount <= 0)
            {
                res.Success = false;
                res.Message = "Le montant du paiement doit être supérieur à 0 DH.";
                return res;
            }

            if (string.IsNullOrWhiteSpace(payment.PaymentDate))
            {
                res.Success = false;
                res.Message = "Veuillez sélectionner une date valide.";
                return res;
            }

            using (var conn = DatabaseService.OpenConnection())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    // 1. Fetch debt and customer status
                    decimal debtAmount = 0;
                    int isArchived = 0;
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = @"
                            SELECT d.Amount, c.IsArchived 
                            FROM Debts d 
                            JOIN Customers c ON d.CustomerId = c.Id 
                            WHERE d.Id = @debtId LIMIT 1;";
                        cmd.Parameters.AddWithValue("@debtId", payment.DebtId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                tx.Rollback();
                                res.Success = false;
                                res.Message = "Dette introuvable.";
                                return res;
                            }
                            debtAmount = Convert.ToDecimal(reader["Amount"]);
                            isArchived = Convert.ToInt32(reader["IsArchived"]);
                        }
                    }

                    if (isArchived == 1)
                    {
                        tx.Rollback();
                        res.Success = false;
                        res.Message = "Impossible d'enregistrer un paiement pour un client archivé.";
                        return res;
                    }

                    // 2. Fetch current total paid
                    decimal currentTotalPaid = 0;
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = "SELECT IFNULL(SUM(Amount), 0) FROM Payments WHERE DebtId = @debtId;";
                        cmd.Parameters.AddWithValue("@debtId", payment.DebtId);
                        currentTotalPaid = Convert.ToDecimal(cmd.ExecuteScalar());
                    }

                    decimal remaining = debtAmount - currentTotalPaid;
                    if (remaining <= 0)
                    {
                        tx.Rollback();
                        res.Success = false;
                        res.Message = "Cette dette est déjà entièrement payée.";
                        return res;
                    }

                    // 3. Strict anti-overpayment check
                    if (payment.Amount > remaining)
                    {
                        tx.Rollback();
                        res.Success = false;
                        res.Message = string.Format("Le montant du versement ({0:N2} DH) dépasse le reste dû ({1:N2} DH).", payment.Amount, remaining);
                        return res;
                    }

                    // 4. Insert payment
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = @"
                            INSERT INTO Payments (DebtId, Amount, PaymentDate, Notes)
                            VALUES (@debtId, @amount, @paymentDate, @notes);
                            SELECT last_insert_rowid();";
                        cmd.Parameters.AddWithValue("@debtId", payment.DebtId);
                        cmd.Parameters.AddWithValue("@amount", payment.Amount);
                        cmd.Parameters.AddWithValue("@paymentDate", payment.PaymentDate);
                        cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(payment.Notes) ? (object)DBNull.Value : payment.Notes.Trim());

                        object idObj = cmd.ExecuteScalar();
                        if (idObj != null)
                        {
                            payment.Id = Convert.ToInt32(idObj);
                        }
                    }

                    tx.Commit();

                    // 5. Retrieve updated debt
                    Debt updatedDebt = DebtService.GetDebtById(payment.DebtId);
                    res.Success = true;
                    res.Message = "Paiement enregistré avec succès.";
                    res.Payment = payment;
                    res.Debt = updatedDebt;
                    return res;
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    LogService.Error("Erreur AddPayment", ex);
                    res.Success = false;
                    res.Message = "Erreur système lors de l'enregistrement du paiement.";
                    return res;
                }
            }
        }
    }
}
