using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using tahiri_lilatate.Models;

namespace tahiri_lilatate.Services
{
    public class DebtResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public Debt Debt { get; set; }
    }

    public static class DebtService
    {
        /// <summary>
        /// Maps a SQLite reader to a Debt object.
        /// Requires the query to SELECT Debts.*, IFNULL(SUM(Payments.Amount), 0) AS TotalPaid, 
        /// and optionally Customers.FullName, Customers.Phone, Customers.CIN.
        /// </summary>
        private static Debt MapReaderToDebt(SqliteDataReader reader)
        {
            var debt = new Debt
            {
                Id = Convert.ToInt32(reader["Id"]),
                CustomerId = Convert.ToInt32(reader["CustomerId"]),
                Amount = Convert.ToDecimal(reader["Amount"]),
                DebtDate = Convert.ToString(reader["DebtDate"]),
                Notes = reader["Notes"] != DBNull.Value ? Convert.ToString(reader["Notes"]) : null,
                TotalPaid = Convert.ToDecimal(reader["TotalPaid"])
            };

            // Safely map optional customer info
            for (int i = 0; i < reader.FieldCount; i++)
            {
                string colName = reader.GetName(i);
                if (colName.Equals("FullName", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    debt.CustomerFullName = Convert.ToString(reader[i]);
                else if (colName.Equals("Phone", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    debt.CustomerPhone = Convert.ToString(reader[i]);
                else if (colName.Equals("CIN", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    debt.CustomerCIN = Convert.ToString(reader[i]);
                else if (colName.Equals("LastPaymentDate", StringComparison.OrdinalIgnoreCase) && reader[i] != DBNull.Value)
                    debt.LastPaymentDate = Convert.ToString(reader[i]);
            }

            return debt;
        }

        public static List<Debt> GetDebtsByCustomerId(int customerId)
        {
            var list = new List<Debt>();
            string sql = @"
                SELECT 
                    d.*,
                    IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
                    (SELECT MAX(PaymentDate) FROM Payments WHERE DebtId = d.Id) AS LastPaymentDate,
                    c.FullName, c.Phone, c.CIN
                FROM Debts d
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE d.CustomerId = @customerId
                ORDER BY d.DebtDate DESC, d.Id DESC;
            ";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                while (reader.Read())
                {
                    list.Add(MapReaderToDebt(reader));
                }
            }, cmd =>
            {
                cmd.Parameters.AddWithValue("@customerId", customerId);
            });

            return list;
        }

        public static List<Debt> GetAllActiveDebts(string searchQuery)
        {
            var list = new List<Debt>();
            string sql = @"
                SELECT 
                    d.*,
                    IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
                    (SELECT MAX(PaymentDate) FROM Payments WHERE DebtId = d.Id) AS LastPaymentDate,
                    c.FullName, c.Phone, c.CIN
                FROM Debts d
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE c.IsArchived = 0
            ";

            if (!string.IsNullOrWhiteSpace(searchQuery))
            {
                sql += " AND (c.FullName LIKE @query OR c.Phone LIKE @query OR c.CIN LIKE @query) ";
            }
            
            sql += " ORDER BY d.DebtDate DESC, d.Id DESC;";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                while (reader.Read())
                {
                    list.Add(MapReaderToDebt(reader));
                }
            }, cmd =>
            {
                if (!string.IsNullOrWhiteSpace(searchQuery))
                {
                    cmd.Parameters.AddWithValue("@query", "%" + searchQuery.Trim() + "%");
                }
            });

            return list;
        }

        public static Debt GetDebtById(int id)
        {
            Debt debt = null;
            string sql = @"
                SELECT 
                    d.*,
                    IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
                    (SELECT MAX(PaymentDate) FROM Payments WHERE DebtId = d.Id) AS LastPaymentDate,
                    c.FullName, c.Phone, c.CIN
                FROM Debts d
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE d.Id = @id LIMIT 1;
            ";

            DatabaseService.ExecuteReader(sql, reader =>
            {
                if (reader.Read())
                {
                    debt = MapReaderToDebt(reader);
                }
            }, cmd =>
            {
                cmd.Parameters.AddWithValue("@id", id);
            });

            return debt;
        }

        public static DebtResult AddDebt(Debt debt)
        {
            try
            {
                if (debt.Amount <= 0)
                    return new DebtResult { Success = false, Message = "Le montant doit être supérieur à 0 DH." };

                if (string.IsNullOrWhiteSpace(debt.DebtDate))
                    return new DebtResult { Success = false, Message = "Veuillez sélectionner une date valide." };

                // Validate customer exists and is active
                object activeStatus = DatabaseService.ExecuteScalar(
                    "SELECT IsArchived FROM Customers WHERE Id = @id LIMIT 1;", 
                    cmd => cmd.Parameters.AddWithValue("@id", debt.CustomerId)
                );

                if (activeStatus == null)
                    return new DebtResult { Success = false, Message = "Client introuvable." };
                
                if (Convert.ToInt32(activeStatus) == 1)
                    return new DebtResult { Success = false, Message = "Impossible d'ajouter une dette pour un client archivé." };

                // Check if customer already has an existing debt in table
                object existingIdObj = DatabaseService.ExecuteScalar(
                    "SELECT Id FROM Debts WHERE CustomerId = @customerId ORDER BY Id DESC LIMIT 1;",
                    cmd => cmd.Parameters.AddWithValue("@customerId", debt.CustomerId)
                );

                if (existingIdObj != null && existingIdObj != DBNull.Value)
                {
                    int existingId = Convert.ToInt32(existingIdObj);
                    string updateSql = @"
                        UPDATE Debts 
                        SET Amount = Amount + @amount, 
                            DebtDate = @debtDate, 
                            Notes = CASE 
                                WHEN Notes IS NULL OR Notes = '' THEN @notes 
                                WHEN @notes IS NULL OR @notes = '' THEN Notes 
                                ELSE Notes || ' | ' || @notes 
                            END
                        WHERE Id = @id;
                    ";
                    int affected = DatabaseService.ExecuteNonQuery(updateSql, cmd =>
                    {
                        cmd.Parameters.AddWithValue("@id", existingId);
                        cmd.Parameters.AddWithValue("@amount", debt.Amount);
                        cmd.Parameters.AddWithValue("@debtDate", debt.DebtDate);
                        cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(debt.Notes) ? (object)DBNull.Value : debt.Notes.Trim());
                    });

                    if (affected > 0)
                    {
                        debt.Id = existingId;
                        return new DebtResult { Success = true, Message = "Montant ajouté à la dette existante avec succès.", Debt = GetDebtById(existingId) };
                    }
                }

                string sql = @"
                    INSERT INTO Debts (CustomerId, Amount, DebtDate, Notes)
                    VALUES (@customerId, @amount, @debtDate, @notes);
                    SELECT last_insert_rowid();
                ";

                object idObj = DatabaseService.ExecuteScalar(sql, cmd =>
                {
                    cmd.Parameters.AddWithValue("@customerId", debt.CustomerId);
                    cmd.Parameters.AddWithValue("@amount", debt.Amount);
                    cmd.Parameters.AddWithValue("@debtDate", debt.DebtDate);
                    cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(debt.Notes) ? (object)DBNull.Value : debt.Notes.Trim());
                });

                if (idObj != null)
                {
                    debt.Id = Convert.ToInt32(idObj);
                    return new DebtResult { Success = true, Message = "Dette ajoutée avec succès.", Debt = debt };
                }

                return new DebtResult { Success = false, Message = "Erreur lors de la création de la dette." };
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur AddDebt", ex);
                return new DebtResult { Success = false, Message = "Erreur système lors de l'ajout de la dette." };
            }
        }

        public static DebtResult UpdateDebt(Debt debt)
        {
            try
            {
                if (debt.Amount <= 0)
                    return new DebtResult { Success = false, Message = "Le montant doit être supérieur à 0 DH." };

                if (string.IsNullOrWhiteSpace(debt.DebtDate))
                    return new DebtResult { Success = false, Message = "Veuillez sélectionner une date valide." };

                var existing = GetDebtById(debt.Id);
                if (existing == null)
                    return new DebtResult { Success = false, Message = "Dette introuvable." };

                if (debt.Amount < existing.TotalPaid)
                    return new DebtResult { Success = false, Message = "Le montant de la dette ne peut pas être inférieur au montant déjà payé." };

                string sql = @"
                    UPDATE Debts 
                    SET Amount = @amount, 
                        DebtDate = @debtDate, 
                        Notes = @notes
                    WHERE Id = @id;
                ";

                int affected = DatabaseService.ExecuteNonQuery(sql, cmd =>
                {
                    cmd.Parameters.AddWithValue("@id", debt.Id);
                    cmd.Parameters.AddWithValue("@amount", debt.Amount);
                    cmd.Parameters.AddWithValue("@debtDate", debt.DebtDate);
                    cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(debt.Notes) ? (object)DBNull.Value : debt.Notes.Trim());
                });

                if (affected > 0)
                {
                    return new DebtResult { Success = true, Message = "Dette modifiée avec succès.", Debt = GetDebtById(debt.Id) };
                }

                return new DebtResult { Success = false, Message = "Erreur lors de la modification de la dette." };
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur UpdateDebt", ex);
                return new DebtResult { Success = false, Message = "Erreur système lors de la modification de la dette." };
            }
        }

        /// <summary>
        /// Supprime une dette par son ID.
        /// Refuse si des paiements lies existent (integrite des donnees).
        /// </summary>
        public static DebtResult DeleteDebt(int id)
        {
            try
            {
                var existing = GetDebtById(id);
                if (existing == null)
                    return new DebtResult { Success = false, Message = "Dette introuvable." };

                object payCount = DatabaseService.ExecuteScalar(
                    "SELECT COUNT(*) FROM Payments WHERE DebtId = @id;",
                    cmd => cmd.Parameters.AddWithValue("@id", id)
                );

                if (payCount != null && Convert.ToInt64(payCount) > 0)
                    return new DebtResult
                    {
                        Success = false,
                        Message = "Impossible de supprimer cette dette : elle contient des paiements enregistres. Supprimez d abord les paiements associes."
                    };

                int affected = DatabaseService.ExecuteNonQuery(
                    "DELETE FROM Debts WHERE Id = @id;",
                    cmd => cmd.Parameters.AddWithValue("@id", id)
                );

                if (affected > 0)
                    return new DebtResult { Success = true, Message = "Dette supprimee avec succes." };

                return new DebtResult { Success = false, Message = "Erreur lors de la suppression de la dette." };
            }
            catch (Exception ex)
            {
                LogService.Error("Erreur DeleteDebt", ex);
                return new DebtResult { Success = false, Message = "Erreur systeme lors de la suppression de la dette." };
            }
        }

        /// <summary>
        /// Recherche avancee avec filtres : texte, statut, periode, dates.
        /// </summary>
        public static List<Debt> GetDebtsByFilter(string searchQuery, string statusFilter,
            string periodFilter, string dateFrom, string dateTo)
        {
            var list = new List<Debt>();
            var cond = new System.Text.StringBuilder();
            var acts = new System.Collections.Generic.List<Action<Microsoft.Data.Sqlite.SqliteCommand>>();

            string sql = @"
                SELECT d.*,
                    IFNULL((SELECT SUM(Amount) FROM Payments WHERE DebtId = d.Id), 0) AS TotalPaid,
                    (SELECT MAX(PaymentDate) FROM Payments WHERE DebtId = d.Id) AS LastPaymentDate,
                    c.FullName, c.Phone, c.CIN
                FROM Debts d
                JOIN Customers c ON d.CustomerId = c.Id
                WHERE c.IsArchived = 0";

            if (!string.IsNullOrWhiteSpace(searchQuery))
            {
                cond.Append(" AND (c.FullName LIKE @q OR c.Phone LIKE @q OR c.CIN LIKE @q OR d.Notes LIKE @q)");
                string like = "%" + searchQuery.Trim() + "%";
                acts.Add(cmd => cmd.Parameters.AddWithValue("@q", like));
            }

            if (!string.IsNullOrWhiteSpace(periodFilter))
            {
                DateTime now = DateTime.Today;
                if (periodFilter.ToLower() == "today")
                {
                    cond.Append(" AND d.DebtDate >= @df AND d.DebtDate < @dt");
                    string df = now.ToString("yyyy-MM-dd"), dt = now.AddDays(1).ToString("yyyy-MM-dd");
                    acts.Add(cmd => { cmd.Parameters.AddWithValue("@df", df); cmd.Parameters.AddWithValue("@dt", dt); });
                }
                else if (periodFilter.ToLower() == "week")
                {
                    int diff = (7 + (int)now.DayOfWeek - (int)DayOfWeek.Monday) % 7;
                    DateTime mon = now.AddDays(-diff);
                    cond.Append(" AND d.DebtDate >= @df AND d.DebtDate < @dt");
                    string df = mon.ToString("yyyy-MM-dd"), dt = mon.AddDays(7).ToString("yyyy-MM-dd");
                    acts.Add(cmd => { cmd.Parameters.AddWithValue("@df", df); cmd.Parameters.AddWithValue("@dt", dt); });
                }
                else if (periodFilter.ToLower() == "month")
                {
                    DateTime fd = new DateTime(now.Year, now.Month, 1);
                    cond.Append(" AND d.DebtDate >= @df AND d.DebtDate < @dt");
                    string df = fd.ToString("yyyy-MM-dd"), dt = fd.AddMonths(1).ToString("yyyy-MM-dd");
                    acts.Add(cmd => { cmd.Parameters.AddWithValue("@df", df); cmd.Parameters.AddWithValue("@dt", dt); });
                }
                else if (periodFilter.ToLower() == "custom")
                {
                    if (!string.IsNullOrWhiteSpace(dateFrom))
                    {
                        cond.Append(" AND d.DebtDate >= @df");
                        string df = dateFrom;
                        acts.Add(cmd => cmd.Parameters.AddWithValue("@df", df));
                    }
                    if (!string.IsNullOrWhiteSpace(dateTo))
                    {
                        cond.Append(" AND d.DebtDate <= @dt");
                        string dt = dateTo;
                        acts.Add(cmd => cmd.Parameters.AddWithValue("@dt", dt));
                    }
                }
            }

            sql += cond.ToString() + " ORDER BY d.DebtDate DESC, d.Id DESC;";
            string captStatus = statusFilter;
            var captActs = acts;

            DatabaseService.ExecuteReader(sql, reader =>
            {
                while (reader.Read())
                {
                    var debt = MapReaderToDebt(reader);
                    if (!string.IsNullOrWhiteSpace(captStatus) &&
                        !captStatus.Equals("all", StringComparison.OrdinalIgnoreCase) &&
                        !debt.Status.Equals(captStatus, StringComparison.OrdinalIgnoreCase))
                        continue;
                    list.Add(debt);
                }
            }, cmd => { foreach (var a in captActs) a(cmd); });

            return list;
        }

        // Dashboard stats (future usage)
        public static int GetTotalDebtCount()
        {
            try { object r = DatabaseService.ExecuteScalar("SELECT COUNT(*) FROM Debts d JOIN Customers c ON c.Id=d.CustomerId WHERE c.IsArchived=0;"); return r!=null?(int)(long)r:0; }
            catch { return 0; }
        }
        public static decimal GetTotalDebtAmount()
        {
            try { object r = DatabaseService.ExecuteScalar("SELECT IFNULL(SUM(d.Amount),0) FROM Debts d JOIN Customers c ON c.Id=d.CustomerId WHERE c.IsArchived=0;"); return r!=null?Convert.ToDecimal(r):0m; }
            catch { return 0m; }
        }
        public static decimal GetTotalRemainingAmount()
        {
            try { object r = DatabaseService.ExecuteScalar("SELECT IFNULL(SUM(d.Amount-IFNULL((SELECT SUM(p.Amount) FROM Payments p WHERE p.DebtId=d.Id),0)),0) FROM Debts d JOIN Customers c ON c.Id=d.CustomerId WHERE c.IsArchived=0;"); return r!=null?Convert.ToDecimal(r):0m; }
            catch { return 0m; }
        }
        public static decimal GetTotalPaidAmount()
        {
            try { object r = DatabaseService.ExecuteScalar("SELECT IFNULL(SUM(Amount),0) FROM Payments;"); return r!=null?Convert.ToDecimal(r):0m; }
            catch { return 0m; }
        }
    }
}
