/**
 * auth.js — Tahiri Lilatate
 * Handles authentication interactions, client-side validation, password visibility toggles,
 * and communication with C# through WebView2.
 * 
 * IMPORTANT: No SQL queries, passwords or hashes are exposed to or stored in JavaScript.
 */

'use strict';

(function () {
  // ──────────────────────────────────────────────
  // DOM Elements
  // ──────────────────────────────────────────────
  const loginForm = document.getElementById('loginForm');
  const usernameInput = document.getElementById('usernameInput');
  const passwordInput = document.getElementById('passwordInput');
  const btnSubmitLogin = document.getElementById('btnSubmitLogin');
  const btnTogglePassword = document.getElementById('btnTogglePassword');
  const iconEye = document.getElementById('iconEye');
  const iconEyeOff = document.getElementById('iconEyeOff');
  const loginAlert = document.getElementById('loginAlert');
  const loginAlertText = document.getElementById('loginAlertText');

  let lockoutCountdownTimer = null;

  // ──────────────────────────────────────────────
  // Password Visibility Toggle
  // ──────────────────────────────────────────────
  if (btnTogglePassword && passwordInput) {
    btnTogglePassword.addEventListener('click', function (e) {
      e.preventDefault();
      const isPassword = passwordInput.getAttribute('type') === 'password';
      passwordInput.setAttribute('type', isPassword ? 'text' : 'password');

      if (iconEye) {
        if (isPassword) {
          // Show Eye Off icon
          iconEye.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line>';
        } else {
          // Show Eye icon
          iconEye.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>';
        }
      }
      btnTogglePassword.setAttribute('title', isPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe');
      btnTogglePassword.setAttribute('aria-label', isPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe');
    });
  }

  // ──────────────────────────────────────────────
  // Window Control Buttons (Minimize / Maximize / Close)
  // ──────────────────────────────────────────────
  const btnMin = document.getElementById('btnWinMinimize');
  const btnMax = document.getElementById('btnWinMaximize');
  const btnClose = document.getElementById('btnWinClose');

  if (btnMin) btnMin.addEventListener('click', () => postToCSharp('window_minimize'));
  if (btnMax) btnMax.addEventListener('click', () => postToCSharp('window_maximize'));
  if (btnClose) btnClose.addEventListener('click', () => postToCSharp('window_close'));

  // ──────────────────────────────────────────────
  // Inline Alert Helpers
  // ──────────────────────────────────────────────
  function showLoginAlert(message, type) {
    if (!loginAlert || !loginAlertText) return;
    loginAlert.className = 'alert-inline alert-' + (type || 'error');
    loginAlertText.textContent = message;
    loginAlert.style.display = 'flex';
  }

  function hideLoginAlert() {
    if (!loginAlert) return;
    loginAlert.style.display = 'none';
  }

  // ──────────────────────────────────────────────
  // C# ↔ WebView2 Bridge Communication
  // ──────────────────────────────────────────────
  function postToCSharp(action, payload) {
    const message = JSON.stringify({ action: action, payload: payload || {} });
    if (window.chrome && window.chrome.webview && window.chrome.webview.postMessage) {
      window.chrome.webview.postMessage(message);
    } else {
      console.warn('[WebView2 Bridge] Not available. Message:', message);
    }
  }

  // Listen for messages from C#
  function handleIncomingMessage(event) {
    try {
      const data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
      if (!data || !data.action) return;

      if (data.action === 'login_response') {
        handleLoginResponse(data.payload);
      }
    } catch (err) {
      console.error('[auth.js] Error parsing incoming message:', err);
    }
  }

  window.addEventListener('message', handleIncomingMessage);
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', handleIncomingMessage);
  }

  // ──────────────────────────────────────────────
  // Login Form Submission & Validation
  // ──────────────────────────────────────────────
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      hideLoginAlert();

      const username = (usernameInput.value || '').trim();
      const password = passwordInput.value || '';

      // Validation 1: Username cannot be empty
      if (!username) {
        showLoginAlert("Veuillez saisir votre nom d'utilisateur.", 'error');
        usernameInput.focus();
        return;
      }

      // Validation 2: Password cannot be empty
      if (!password) {
        showLoginAlert("Veuillez saisir votre mot de passe.", 'error');
        passwordInput.focus();
        return;
      }

      // Indicate loading
      btnSubmitLogin.disabled = true;
      btnSubmitLogin.textContent = 'Connexion en cours…';

      // Send credentials securely to C# via WebView2 bridge
      postToCSharp('login', {
        username: username,
        password: password
      });
    });
  }

  function handleLoginResponse(payload) {
    btnSubmitLogin.disabled = false;
    btnSubmitLogin.textContent = 'Se connecter';

    if (!payload) {
      showLoginAlert("Une erreur est survenue. Veuillez réessayer.", 'error');
      return;
    }

    if (payload.success) {
      showLoginAlert('Connexion réussie. Redirection…', 'success');
      btnSubmitLogin.disabled = true;
      // C# MainWindow handles navigation to index.html
    } else {
      if (payload.remainingSeconds && payload.remainingSeconds > 0) {
        startLockoutCountdown(payload.remainingSeconds);
      } else {
        showLoginAlert(payload.message || "Nom d'utilisateur ou mot de passe incorrect.", 'error');
      }
      passwordInput.value = '';
      passwordInput.focus();
    }
  }

  function startLockoutCountdown(seconds) {
    if (lockoutCountdownTimer) {
      clearInterval(lockoutCountdownTimer);
    }

    let remaining = seconds;
    btnSubmitLogin.disabled = true;

    function update() {
      if (remaining <= 0) {
        clearInterval(lockoutCountdownTimer);
        btnSubmitLogin.disabled = false;
        hideLoginAlert();
        return;
      }
      showLoginAlert("Trop de tentatives. Veuillez patienter encore " + remaining + " seconde(s).", 'warning');
      remaining--;
    }

    update();
    lockoutCountdownTimer = setInterval(update, 1000);
  }

})();
