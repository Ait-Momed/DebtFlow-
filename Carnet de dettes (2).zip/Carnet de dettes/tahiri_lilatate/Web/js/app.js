/**
 * app.js — Tahiri Lilatate
 * Core frontend application: router, page renderers, clock, C# bridge.
 *
 * Architecture:
 *   - App.router     → maps page names to render functions
 *   - App.navigate() → activates a page
 *   - App.bridge     → C# ↔ JavaScript communication layer
 *   - App.toast      → notification system
 *   - App.utils      → formatting helpers
 *
 * IMPORTANT: JavaScript NEVER accesses SQLite directly.
 * All data operations go through the C# bridge via postMessage.
 */

'use strict';

// ═══════════════════════════════════════════════════════════════
// App namespace
// ═══════════════════════════════════════════════════════════════
const App = (function () {

  // ──────────────────────────────────────────────
  // State
  // ──────────────────────────────────────────────
  let currentPage = null;

  // ──────────────────────────────────────────────
  // DOM references
  // ──────────────────────────────────────────────
  const $ = id => document.getElementById(id);
  const content  = $('content');
  const pageTitle = $('pageTitle');
  const clockEl  = $('headerClock');
  const dateEl   = $('headerDate');

  // ──────────────────────────────────────────────
  // Page route map (NO Dashboard: starts with Clients)
  // ──────────────────────────────────────────────
  const routes = {
    customers : { title: 'Clients',    render: renderCustomers },
    debts     : { title: 'Dettes',     render: renderDebts     },
    payments  : { title: 'Paiements',  render: renderPayments  },
    archive   : { title: 'Archive',    render: renderArchive   },
    settings  : { title: 'Paramètres', render: renderSettings  },
  };

  // ──────────────────────────────────────────────
  // Router
  // ──────────────────────────────────────────────

  /**
   * Navigate to a named page.
   * Updates active sidebar item, page title, and content area.
   */
  function navigate(pageName) {
    const route = routes[pageName];
    if (!route) {
      console.warn('[App] Unknown page:', pageName);
      return;
    }

    // Update sidebar active state
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === pageName);
    });

    // Update header title
    pageTitle.textContent = route.title;
    currentPage = pageName;

    // Render page content with transition
    content.innerHTML = '';
    const wrapper = document.createElement('div');
    wrapper.className = 'page-enter';
    wrapper.innerHTML = route.render();
    content.appendChild(wrapper);

    // Bind page-specific event listeners
    bindPageEvents(pageName);
  }

  /** Binds DOM event listeners for the just-rendered page. */
  function bindPageEvents(pageName) {
    if (pageName === 'customers') {
      initCustomersPage();
    } else if (pageName === 'debts') {
      Debts.initPage();
      Debts.initModals();
    } else if (pageName === 'payments') {
      initPaymentsPage();
    } else if (pageName === 'archive') {
      if (typeof Archive !== 'undefined') {
        Archive.initPage();
      }
    } else if (pageName === 'settings') {
      initSettingsPage();
    }
  }

  // ──────────────────────────────────────────────
  // Customers Module
  // ──────────────────────────────────────────────

  let searchTimeout = null;

  function renderCustomers() {
    return `
      <div class="page-header">
        <span class="page-header-title">
          Clients 
          <span class="customer-count" id="customerCountLabel">0</span>
        </span>
        <div class="page-header-actions">
          <div class="search-bar">
            ${svgSearchIcon()}
            <input type="text" class="form-control" id="searchInput" placeholder="Rechercher un client (Nom, Tél, CIN)…" />
          </div>
          <button class="btn btn-primary" id="btnOpenAddCustomerModal">
            + Nouveau client
          </button>
        </div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Nom complet</th>
              <th>Téléphone</th>
              <th>CIN</th>
              <th>Adresse</th>
              <th>Date d'inscription</th>
              <th>Solde dû</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="customersTableBody">
            <tr>
              <td colspan="8" class="table-empty">
                <div class="empty-state">
                  ${svgEmptyIcon()}
                  <div class="empty-state-title">Chargement...</div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  }

  function initCustomersPage() {
    // Initial fetch
    bridge.send('get_customers', { query: '' });

    // Search logic with debounce
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
          bridge.send('get_customers', { query: e.target.value.trim() });
        }, 250);
      });
    }

    // Modal Triggers
    const btnOpenAdd = document.getElementById('btnOpenAddCustomerModal');
    if (btnOpenAdd) {
      btnOpenAdd.onclick = function () {
        const form = document.getElementById('addCustomerForm');
        if (form) form.reset();
        clearFormErrors('addCustomerForm');
        const overlay = document.getElementById('addCustomerModalOverlay');
        if (overlay) {
          overlay.classList.add('active');
          setTimeout(function () {
            const input = document.getElementById('addFullName');
            if (input) {
              input.focus();
              input.select();
            }
          }, 80);
        }
      };
    }

    // Cancel & Close Add Customer Modal
    const btnCancelAddCust = document.getElementById('btnCancelAddCustomer');
    if (btnCancelAddCust) {
      btnCancelAddCust.onclick = function () {
        const overlay = document.getElementById('addCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('addCustomerForm');
        if (form) form.reset();
        clearFormErrors('addCustomerForm');
        const btn = document.getElementById('btnSubmitAddCustomer');
        if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer'; }
      };
    }
    const btnCloseAddCust = document.getElementById('btnCloseAddCustomerModal');
    if (btnCloseAddCust) {
      btnCloseAddCust.onclick = function () {
        const overlay = document.getElementById('addCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('addCustomerForm');
        if (form) form.reset();
        clearFormErrors('addCustomerForm');
        const btn = document.getElementById('btnSubmitAddCustomer');
        if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer'; }
      };
    }

    // Cancel & Close Edit Customer Modal
    const btnCancelEditCust = document.getElementById('btnCancelEditCustomer');
    if (btnCancelEditCust) {
      btnCancelEditCust.onclick = function () {
        const overlay = document.getElementById('editCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('editCustomerForm');
        if (form) form.reset();
        clearFormErrors('editCustomerForm');
        const btn = document.getElementById('btnSubmitEditCustomer');
        if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer les modifications'; }
      };
    }
    const btnCloseEditCust = document.getElementById('btnCloseEditCustomerModal');
    if (btnCloseEditCust) {
      btnCloseEditCust.onclick = function () {
        const overlay = document.getElementById('editCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('editCustomerForm');
        if (form) form.reset();
        clearFormErrors('editCustomerForm');
        const btn = document.getElementById('btnSubmitEditCustomer');
        if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer les modifications'; }
      };
    }

    // Close View Customer Modal
    const btnCloseViewCust = document.getElementById('btnCloseViewCustomer');
    if (btnCloseViewCust) {
      btnCloseViewCust.onclick = function () {
        const overlay = document.getElementById('viewCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
      };
    }
    const btnCloseViewCust2 = document.getElementById('btnCloseViewCustomerModal');
    if (btnCloseViewCust2) {
      btnCloseViewCust2.onclick = function () {
        const overlay = document.getElementById('viewCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
      };
    }

    // Cancel & Close Archive Customer Modal
    const btnCancelArchCust = document.getElementById('btnCancelArchiveCustomer');
    if (btnCancelArchCust) {
      btnCancelArchCust.onclick = function () {
        const overlay = document.getElementById('archiveCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
      };
    }
    const btnCloseArchCust = document.getElementById('btnCloseArchiveCustomerModal');
    if (btnCloseArchCust) {
      btnCloseArchCust.onclick = function () {
        const overlay = document.getElementById('archiveCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
      };
    }

    // Form Submits: Add Customer
    const addForm = document.getElementById('addCustomerForm');
    if (addForm) {
      addForm.onsubmit = function (e) {
        e.preventDefault();
        clearFormErrors('addCustomerForm');

        const fullNameInput = document.getElementById('addFullName');
        const fullName = (fullNameInput ? fullNameInput.value : '').trim();
        if (!fullName) {
          showFormError('addCustomerForm', 'FullName', 'Le nom complet est obligatoire.');
          if (fullNameInput) fullNameInput.focus();
          return;
        }

        const btn = document.getElementById('btnSubmitAddCustomer');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'Enregistrement...';
        }
        
        const debtVal = (document.getElementById('addInitialDebt')?.value || '').trim();
        const initialDebt = debtVal ? parseFloat(debtVal) : 0;

        const payload = {
          FullName: fullName,
          Phone: (document.getElementById('addPhone')?.value || '').trim(),
          CIN: (document.getElementById('addCIN')?.value || '').trim(),
          InitialDebt: !isNaN(initialDebt) && initialDebt > 0 ? initialDebt : 0,
          Address: (document.getElementById('addAddress')?.value || '').trim(),
          Notes: (document.getElementById('addNotes')?.value || '').trim()
        };
        bridge.send('add_customer', payload);
      };
    }

    // Form Submits: Edit Customer
    const editForm = document.getElementById('editCustomerForm');
    if (editForm) {
      editForm.onsubmit = function (e) {
        e.preventDefault();
        clearFormErrors('editCustomerForm');

        const fullNameInput = document.getElementById('editFullName');
        const fullName = (fullNameInput ? fullNameInput.value : '').trim();
        if (!fullName) {
          showFormError('editCustomerForm', 'FullName', 'Le nom complet est obligatoire.');
          if (fullNameInput) fullNameInput.focus();
          return;
        }

        const btn = document.getElementById('btnSubmitEditCustomer');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'Enregistrement...';
        }

        const payload = {
          Id: parseInt(document.getElementById('editCustomerId').value),
          FullName: fullName,
          Phone: (document.getElementById('editPhone')?.value || '').trim(),
          CIN: (document.getElementById('editCIN')?.value || '').trim(),
          Address: (document.getElementById('editAddress')?.value || '').trim(),
          Notes: (document.getElementById('editNotes')?.value || '').trim()
        };
        bridge.send('update_customer', payload);
      };
    }

    const btnConfirmArchive = document.getElementById('btnConfirmArchiveCustomer');
    if (btnConfirmArchive) {
      btnConfirmArchive.onclick = function () {
        btnConfirmArchive.disabled = true;
        btnConfirmArchive.textContent = 'Archivage...';
        const id = parseInt(document.getElementById('archiveCustomerId').value);
        bridge.send('archive_customer', { Id: id });
      };
    }
  }

  function clearFormErrors(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.querySelectorAll('.field-error').forEach(el => el.style.display = 'none');
  }

  function showFormError(formId, fieldName, message) {
    let elId = '';
    const prefix = formId === 'addCustomerForm' ? 'add' : 'edit';
    if (fieldName === 'FullName') elId = prefix + 'FullName';
    if (fieldName === 'Phone') elId = prefix + 'Phone';
    if (fieldName === 'CIN') elId = prefix + 'CIN';
    
    if (elId) {
      const input = document.getElementById(elId);
      if (input) {
        const errDiv = input.parentElement.querySelector('.field-error');
        if (errDiv) {
          errDiv.textContent = message;
          errDiv.style.display = 'block';
        }
      }
    } else {
      toast(message, 'error');
    }
  }

  window.openEditCustomer = function(id) {
    bridge.send('get_customer_by_id', { Id: id, Action: 'edit' });
  };

  window.openViewCustomer = function(id) {
    bridge.send('get_customer_by_id', { Id: id, Action: 'view' });
  };

  window.openArchiveCustomer = function(id, name) {
    if (!name && window._customersMap && window._customersMap[id]) {
      name = window._customersMap[id].FullName;
    }
    const idInput = document.getElementById('archiveCustomerId');
    if (idInput) idInput.value = id;
    const nameLabel = document.getElementById('archiveCustomerTargetName');
    if (nameLabel) nameLabel.textContent = name || '—';
    const overlay = document.getElementById('archiveCustomerModalOverlay');
    if (overlay) overlay.classList.add('active');
  };


  function renderDebts() {
    return Debts.renderPage();
  }

  function renderPayments() {
    return `
      <div class="page-header">
        <span class="page-header-title">
          Paiements
          <span class="customer-count" id="paymentCountLabel">0</span>
        </span>
        <div class="page-header-actions">
          <div class="search-bar">
            ${svgSearchIcon()}
            <input type="text" class="form-control" id="paymentSearchInput" placeholder="Rechercher par client, téléphone, CIN…" />
          </div>
          <button class="btn btn-primary" id="btnOpenChooseDebt">+ Enregistrer un paiement</button>
        </div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Client</th>
              <th>Téléphone</th>
              <th>N° Dette</th>
              <th>Montant versé</th>
              <th>Date</th>
              <th>Remarque</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="paymentsTableBody">
            <tr>
              <td colspan="7" class="table-empty">
                <div class="empty-state">
                  ${svgEmptyIcon()}
                  <div class="empty-state-title">Chargement...</div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  }

  let paymentSearchTimeout = null;

  function initPaymentsPage() {
    bridge.send('get_payments', { query: '' });

    const searchInput = document.getElementById('paymentSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        clearTimeout(paymentSearchTimeout);
        paymentSearchTimeout = setTimeout(() => {
          bridge.send('get_payments', { query: e.target.value.trim() });
        }, 250);
      });
    }

    const btnAddPay = document.getElementById('btnOpenChooseDebt');
    if (btnAddPay) {
      btnAddPay.onclick = function () {
        if (typeof Debts !== 'undefined' && Debts.openAddPayment) {
          Debts.openAddPayment();
        }
      };
    }
  }

  function renderArchive() {
    if (typeof Archive !== 'undefined' && Archive.renderPage) {
      return Archive.renderPage();
    }
    return `
      <div class="page-header">
        <span class="page-header-title">Archive</span>
      </div>
      <div class="card">
        <div class="empty-state">
          ${svgEmptyIcon()}
          <div class="empty-state-title">Archive vide</div>
          <div class="empty-state-text">Les clients et dettes archivés apparaîtront ici.</div>
        </div>
      </div>
    `;
  }

  function renderSettings() {
    return `
      <div class="page-header">
        <span class="page-header-title">Paramètres</span>
      </div>

      <div class="settings-grid mt-lg">

        <!-- ── 1. Compte administrateur ───────────────────────── -->
        <div class="card">
          <div class="settings-section-title">Compte administrateur</div>

          <div class="settings-current-user">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            Connecté en tant que : <strong id="settingsCurrentUsername">—</strong>
          </div>

          <form id="settingsCredentialsForm" autocomplete="off" onsubmit="return false;">
            <div class="settings-form-row">
              <div class="form-group">
                <label class="form-label">Nouveau nom d'utilisateur</label>
                <input type="text" class="form-control" id="settingsNewUsername" placeholder="Laisser vide pour ne pas modifier" autocomplete="off" />
                <div class="form-error" id="err-settingsNewUsername"></div>
              </div>
              <div class="form-group">
                <label class="form-label">Mot de passe actuel <span style="color:var(--color-danger)">*</span></label>
                <input type="password" class="form-control" id="settingsCurrentPassword" placeholder="Mot de passe actuel" autocomplete="current-password" />
                <div class="form-error" id="err-settingsCurrentPassword"></div>
              </div>
            </div>
            <div class="settings-form-row">
              <div class="form-group">
                <label class="form-label">Nouveau mot de passe</label>
                <input type="password" class="form-control" id="settingsNewPassword" placeholder="Laisser vide pour ne pas modifier" autocomplete="new-password" />
                <div class="form-error" id="err-settingsNewPassword"></div>
              </div>
              <div class="form-group">
                <label class="form-label">Confirmer le nouveau mot de passe</label>
                <input type="password" class="form-control" id="settingsConfirmPassword" placeholder="Confirmer le nouveau mot de passe" autocomplete="new-password" />
                <div class="form-error" id="err-settingsConfirmPassword"></div>
              </div>
            </div>
            <div class="form-error" id="err-settingsCredentials" style="margin-bottom:8px;"></div>
            <button type="button" class="btn btn-primary settings-save-btn" id="btnSaveCredentials">
              Enregistrer les modifications
            </button>
          </form>
        </div>

        <!-- ── 2. Identité du tableau de bord ─────────────────── -->
        <div class="card">
          <div class="settings-section-title">Identité du tableau de bord</div>

          <div class="form-group" style="margin-bottom: var(--space-md);">
            <label class="form-label">Nom affiché dans la barre latérale</label>
            <input type="text" class="form-control" id="settingsAppTitle" placeholder="Ex : Tahiri Lilatate" />
          </div>

          <div class="form-label" style="margin-bottom:8px;">Logo</div>
          <div class="settings-logo-row">
            <div class="settings-logo-preview" id="settingsLogoPreview">
              <span class="logo-placeholder" id="settingsLogoPlaceholder">🏪</span>
            </div>
            <div class="settings-logo-actions">
              <label class="btn-file-upload" for="settingsLogoInput">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                Choisir un logo
              </label>
              <input type="file" id="settingsLogoInput" accept="image/*" style="display:none;" />
              <button type="button" class="btn-remove-logo" id="btnRemoveLogo" style="display:none;">
                ✕ Supprimer le logo
              </button>
            </div>
          </div>

          <button type="button" class="btn btn-primary settings-save-btn" id="btnSaveIdentity">
            Enregistrer l'identité
          </button>
        </div>

        <!-- ── 3. Apparence ───────────────────────────────────── -->
        <div class="card">
          <div class="settings-section-title">Apparence</div>
          <div class="form-label" style="margin-bottom:10px;">Thème de l'interface</div>
          <div class="settings-toggle-group" id="settingsThemeGroup">
            <button type="button" class="settings-toggle-btn" data-theme-val="light" id="btnThemeLight">
              ☀️ Clair
            </button>
            <button type="button" class="settings-toggle-btn" data-theme-val="dark" id="btnThemeDark">
              🌙 Sombre
            </button>
          </div>
        </div>

        <!-- ── 4. Langue ───────────────────────────────────────── -->
        <div class="card">
          <div class="settings-section-title">Langue</div>
          <div class="form-label" style="margin-bottom:10px;">Langue de l'interface</div>
          <div class="settings-toggle-group" id="settingsLangGroup">
            <button type="button" class="settings-toggle-btn" data-lang-val="fr" id="btnLangFr">
              🇫🇷 Français
            </button>
            <button type="button" class="settings-toggle-btn" data-lang-val="ar" id="btnLangAr">
              🇲🇦 العربية
            </button>
            <button type="button" class="settings-toggle-btn" data-lang-val="en" id="btnLangEn">
              🇬🇧 English
            </button>
          </div>
        </div>

      </div>
    `;
  }


  // ──────────────────────────────────────────────
  // SVG icon helpers
  // ──────────────────────────────────────────────

  function svgIcon(name) {
    const icons = {
      users: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      dollar:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`,
      alert:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
      card: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>`,
    };
    return icons[name] || '';
  }

  function svgEmptyIcon() {
    return `<div class="empty-state-icon">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    </div>`;
  }

  function svgSearchIcon() {
    return `<svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>`;
  }

  function statCard(label, value, iconHtml, sub) {
    return `
      <div class="stat-card">
        <div class="stat-card-header">
          <span class="stat-card-label">${label}</span>
          <div class="stat-card-icon">${iconHtml}</div>
        </div>
        <div class="stat-card-value">${value}</div>
        <div class="stat-card-sub">${sub}</div>
      </div>
    `;
  }

  // ──────────────────────────────────────────────
  // Clock
  // ──────────────────────────────────────────────

  const DAYS_FR   = ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
  const MONTHS_FR = ['janv.','févr.','mars','avr.','mai','juin',
                     'juil.','août','sept.','oct.','nov.','déc.'];

  function updateClock() {
    const now = new Date();
    const h  = String(now.getHours()).padStart(2, '0');
    const m  = String(now.getMinutes()).padStart(2, '0');
    const s  = String(now.getSeconds()).padStart(2, '0');
    clockEl.textContent = `${h}:${m}:${s}`;

    const day   = DAYS_FR[now.getDay()];
    const date  = now.getDate();
    const month = MONTHS_FR[now.getMonth()];
    const year  = now.getFullYear();
    dateEl.textContent = `${day} ${date} ${month} ${year}`;
  }

  // ──────────────────────────────────────────────
  // Toast notification system
  // ──────────────────────────────────────────────

  let toastContainer = null;

  function ensureToastContainer() {
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }
    return toastContainer;
  }

  /**
   * Shows a toast notification.
   * @param {string} message  - The message to display
   * @param {'success'|'error'|'warning'|'info'} type
   * @param {number} duration - Duration in ms (default 3500)
   */
  function toast(message, type = 'info', duration = 3500) {
    const container = ensureToastContainer();
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = message;
    container.appendChild(el);

    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.3s ease';
      setTimeout(() => el.remove(), 320);
    }, duration);
  }

  // ──────────────────────────────────────────────
  // C# ↔ JavaScript bridge
  // ──────────────────────────────────────────────

  const bridge = {
    /**
     * Sends a message to C# (MainWindow.OnWebMessageReceived).
     * @param {string} action  - The action name
     * @param {object} payload - Data payload
     */
    send(action, payload = {}) {
      const message = JSON.stringify({ action, payload });
      if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage(message);
      } else {
        console.warn('[Bridge] WebView2 not available. Message:', message);
      }
    },

    /**
     * Called by C# to deliver data to the frontend.
     * C# calls: webView.CoreWebView2.PostWebMessageAsString(json)
     * @param {string} jsonMessage
     */
    receive(jsonMessage) {
      try {
        const { action, payload } = JSON.parse(jsonMessage);
        console.log('[Bridge] Received:', action, payload);

        // Dispatch to handler
        const handler = bridgeHandlers[action];
        if (handler) {
          handler(payload);
        } else {
          console.warn('[Bridge] No handler for action:', action);
        }
      } catch (e) {
        console.error('[Bridge] Failed to parse message:', e);
      }
    }
  };

  /**
   * Map of action names to handler functions.
   * Future phases will register handlers here.
   */
  const bridgeHandlers = {
    'auth_state': payload => {
      if (payload) {
        if (!payload.isAuthenticated) {
          window.location.href = 'login.html';
        } else {
          if (payload.username) {
            const el = document.getElementById('headerAdminName');
            if (el) el.textContent = payload.username;
          }
          // Apply persisted theme and language on every page load
          if (payload.app_theme)    applyTheme(payload.app_theme);
          if (payload.app_language) applyLanguage(payload.app_language);
          // Update sidebar brand title
          if (payload.app_title) {
            const brandName = document.getElementById('sidebarBrandName');
            if (brandName) brandName.textContent = payload.app_title;
          }
          // Update sidebar logo
          if (payload.app_logo) {
            updateSidebarLogo(payload.app_logo);
          }
        }
      }
    },

    'debts_list': function(payload) {
      if (!payload.success) { App.toast('Erreur lors du chargement des dettes.', 'error'); return; }
      Debts.onDebtsList(payload);
    },
    'customer_debts_list': function(payload) {
      Debts.onCustomerDebtsList(payload);
    },
    'debt_details': function(payload) {
      Debts.onDebtDetails(payload);
    },
    'add_debt_response': function(payload) {
      Debts.onAddDebtResponse(payload);
    },
    'update_debt_response': function(payload) {
      Debts.onUpdateDebtResponse(payload);
    },
    'delete_debt_response': function(payload) {
      if (typeof Debts !== 'undefined' && Debts.onDeleteDebtResponse) {
        Debts.onDeleteDebtResponse(payload);
      }
    },
    'add_payment_response': function(payload) {
      if (typeof Debts !== 'undefined' && Debts.onAddPaymentResponse) {
        Debts.onAddPaymentResponse(payload);
      }
    },
    'debt_payments_list': function(payload) {
      if (typeof Debts !== 'undefined' && Debts.onDebtPaymentsList) {
        Debts.onDebtPaymentsList(payload);
      }
    },
    'payments_list': payload => {
      if (!payload || !payload.success) {
        toast('Erreur lors du chargement des paiements.', 'error');
        return;
      }
      const tbody = document.getElementById('paymentsTableBody');
      const countLabel = document.getElementById('paymentCountLabel');
      if (!tbody) return;

      const payments = payload.payments || [];
      if (countLabel) countLabel.textContent = payments.length;

      if (payments.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="7" class="table-empty">
              <div class="empty-state">
                ${svgEmptyIcon()}
                <div class="empty-state-title">Aucun versement trouvé</div>
                <div class="empty-state-text">Cliquez sur "+ Enregistrer un paiement" pour enregistrer un versement.</div>
              </div>
            </td>
          </tr>`;
        return;
      }

      tbody.innerHTML = payments.map(p => `
        <tr>
          <td><strong>${utils.escapeHtml(p.CustomerName || '—')}</strong></td>
          <td>${p.CustomerPhone ? utils.escapeHtml(p.CustomerPhone) : '—'}</td>
          <td><span class="text-muted" style="font-weight: 600;">#${String(p.DebtId).padStart(3, '0')}</span></td>
          <td><strong style="color: var(--color-primary); font-weight: 700;">+ ${utils.formatDirham(p.Amount)}</strong></td>
          <td>${utils.formatDate(p.PaymentDate)}</td>
          <td>${p.Notes ? utils.escapeHtml(p.Notes) : '—'}</td>
          <td>
            <div class="action-buttons">
              <button type="button" class="btn-action btn-print" onclick="Debts.printReceipt(${p.DebtId})" title="Imprimer le reçu">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('');
    },
    'archive_list': payload => {
      if (typeof Archive !== 'undefined' && Archive.onArchiveList) {
        Archive.onArchiveList(payload);
      }
    },
    'restore_customer_response': payload => {
      if (typeof Archive !== 'undefined' && Archive.onRestoreResponse) {
        Archive.onRestoreResponse(payload);
      }
    },
    'delete_permanent_response': payload => {
      if (typeof Archive !== 'undefined' && Archive.onDeletePermanentResponse) {
        Archive.onDeletePermanentResponse(payload);
      }
    },
    'app_settings': payload => {
      onAppSettingsReceived(payload);
    },
    'update_app_settings_response': payload => {
      const btn = document.getElementById('btnSaveIdentity');
      if (btn) { btn.disabled = false; btn.textContent = "Enregistrer l'identité"; }
      if (payload && payload.success) {
        toast('Paramètres enregistrés.', 'success');
        // Update sidebar title live
        if (payload.app_title !== undefined) {
          const brandName = document.getElementById('sidebarBrandName');
          if (brandName) brandName.textContent = payload.app_title || 'Tahiri Lilatate';
        }
        if (payload.app_logo !== undefined) {
          updateSidebarLogo(payload.app_logo);
        }
      } else {
        toast((payload && payload.message) || 'Erreur lors de l\'enregistrement.', 'error');
      }
    },
    'update_admin_credentials_response': payload => {
      const btn = document.getElementById('btnSaveCredentials');
      if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer les modifications'; }
      const errEl = document.getElementById('err-settingsCredentials');
      if (payload && payload.success) {
        if (errEl) errEl.textContent = '';
        const msg = (payload.message) || 'Les informations du compte administrateur ont été mises à jour avec succès.';
        toast(msg, 'success');
        // Clear all credential fields including new username
        ['settingsNewUsername','settingsCurrentPassword','settingsNewPassword','settingsConfirmPassword'].forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = '';
        });
        // Update the displayed username
        if (payload.username) {
          const su = document.getElementById('settingsCurrentUsername');
          if (su) su.textContent = payload.username;
          const ha = document.getElementById('headerAdminName');
          if (ha) ha.textContent = payload.username;
        }
      } else {
        const msg = (payload && payload.message) || 'Erreur lors de la mise à jour des identifiants.';
        if (errEl) errEl.textContent = msg;
        toast(msg, 'error');
      }
    },
    'customers_list': payload => {
      if (!payload || !payload.success) {
        toast('Erreur lors du chargement des clients.', 'error');
        return;
      }
      const customers = payload.customers || [];
      window._customersMap = {};
      customers.forEach(c => { window._customersMap[c.Id] = c; });

      if (typeof Debts !== 'undefined' && Debts.populateCustomerSelectForDebt) {
        Debts.populateCustomerSelectForDebt();
      }

      const tbody = document.getElementById('customersTableBody');
      const countLabel = document.getElementById('customerCountLabel');
      if (!tbody) return;

      if (countLabel) countLabel.textContent = customers.length;
      
      if (customers.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="8" class="table-empty">
              <div class="empty-state-compact">
                <div class="empty-state-title">Aucun client trouvé</div>
              </div>
            </td>
          </tr>`;
        return;
      }
      
      tbody.innerHTML = customers.map(c => `
        <tr>
          <td><strong>${utils.escapeHtml(c.FullName)}</strong></td>
          <td>${c.Phone ? utils.escapeHtml(c.Phone) : '—'}</td>
          <td>${c.CIN ? utils.escapeHtml(c.CIN) : '—'}</td>
          <td class="text-muted">${c.Address ? utils.escapeHtml(c.Address).substring(0, 30) + (c.Address.length > 30 ? '...' : '') : '—'}</td>
          <td>${utils.formatDate(c.RegistrationDate)}</td>
          <td><strong style="color: ${(c.TotalRemaining > 0 ? 'var(--color-danger)' : 'var(--color-primary)')};">${utils.formatDirham(c.TotalRemaining || 0)}</strong></td>
          <td><span class="badge ${(c.TotalRemaining > 0 ? 'badge-warning' : 'badge-success')}">${(c.TotalRemaining > 0 ? 'En dette' : 'À jour')}</span></td>
          <td>
            <div class="action-buttons">
              <button type="button" class="btn-action btn-view" onclick="window.openViewCustomer(${c.Id})" title="Voir les détails">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              </button>
              <button type="button" class="btn-action btn-edit" onclick="window.openEditCustomer(${c.Id})" title="Modifier">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
              </button>
              <button type="button" class="btn-action btn-delete" onclick="window.openArchiveCustomer(${c.Id})" title="Supprimer / Archiver">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('');
    },
    
    'add_customer_response': payload => {
      const btn = document.getElementById('btnSubmitAddCustomer');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Enregistrer';
      }
      
      if (payload.success) {
        const overlay = document.getElementById('addCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('addCustomerForm');
        if (form) form.reset();
        clearFormErrors('addCustomerForm');
        toast(payload.message || 'Client ajouté avec succès.', 'success');
        bridge.send('get_customers', { query: document.getElementById('searchInput')?.value || '' });
        bridge.send('get_debts', { query: '' });
      } else {
        if (payload.validationErrors) {
          payload.validationErrors.forEach(err => {
            showFormError('addCustomerForm', err.field, err.message);
          });
        } else {
          toast(payload.message || 'Erreur lors de l\'ajout.', 'error');
        }
      }
    },
    
    'update_customer_response': payload => {
      const btn = document.getElementById('btnSubmitEditCustomer');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Enregistrer les modifications';
      }
      
      if (payload.success) {
        const overlay = document.getElementById('editCustomerModalOverlay');
        if (overlay) overlay.classList.remove('active', 'visible');
        const form = document.getElementById('editCustomerForm');
        if (form) form.reset();
        clearFormErrors('editCustomerForm');
        toast(payload.message || 'Client mis à jour avec succès.', 'success');
        bridge.send('get_customers', { query: document.getElementById('searchInput')?.value || '' });
      } else {
        if (payload.validationErrors) {
          payload.validationErrors.forEach(err => {
            showFormError('editCustomerForm', err.field, err.message);
          });
        } else {
          toast(payload.message || 'Erreur lors de la mise à jour.', 'error');
        }
      }
    },
    
    'archive_customer_response': payload => {
      const btn = document.getElementById('btnConfirmArchiveCustomer');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Archiver';
      }
      
      if (payload.success) {
        document.getElementById('archiveCustomerModalOverlay').classList.remove('active');
        toast(payload.message || 'Client archivé avec succès.', 'success');
        bridge.send('get_customers', { query: document.getElementById('searchInput')?.value || '' });
      } else {
        toast(payload.message || 'Erreur lors de l\'archivage.', 'error');
      }
    },
    
    'customer_details': payload => {
      if (!payload.success || !payload.customer) {
        toast(payload.message || 'Client introuvable.', 'error');
        return;
      }
      const c = payload.customer;
      
      if (payload.actionRequested === 'edit') {
        document.getElementById('editCustomerId').value = c.Id;
        document.getElementById('editFullName').value = c.FullName;
        document.getElementById('editPhone').value = c.Phone || '';
        document.getElementById('editCIN').value = c.CIN || '';
        document.getElementById('editAddress').value = c.Address || '';
        document.getElementById('editNotes').value = c.Notes || '';
        
        clearFormErrors('editCustomerForm');
        document.getElementById('editCustomerModalOverlay').classList.add('active');
      } 
      else if (payload.actionRequested === 'view') {
        document.getElementById('viewFullName').textContent = c.FullName;
        document.getElementById('viewPhone').textContent = c.Phone || '—';
        document.getElementById('viewCIN').textContent = c.CIN || '—';
        document.getElementById('viewAddress').textContent = c.Address || '—';
        document.getElementById('viewNotes').textContent = c.Notes || '—';
        document.getElementById('viewRegistrationDate').textContent = utils.formatDate(c.RegistrationDate);
        
        document.getElementById('viewCustomerModalOverlay').classList.add('active');
        // Load debts for this customer
        if (typeof Debts !== 'undefined') {
          Debts.loadCustomerDebts(c.Id, c.FullName);
        }
        // Wire the Add Debt button
        var btnAddFromCustomer = document.getElementById('btnAddDebtFromCustomer');
        if (btnAddFromCustomer) {
          btnAddFromCustomer.onclick = function() {
            if (typeof Debts !== 'undefined') Debts.openAddDebt(c.Id, c.FullName);
          };
        }
      }
    }
  };

  // ──────────────────────────────────────────────
  // Utility helpers
  // ──────────────────────────────────────────────

  const utils = {
    /**
     * Formats a decimal number as Moroccan Dirham.
     * Example: 1500.5 → "1 500,50 DH"
     */
    formatDirham(amount) {
      if (amount === null || amount === undefined || amount === '—') return '— DH';
      const num = parseFloat(amount);
      if (isNaN(num)) return '— DH';
      return num.toLocaleString('fr-MA', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }) + ' DH';
    },

    /**
     * Formats an ISO date string as "15 sept. 2026"
     */
    formatDate(isoString) {
      if (!isoString) return '—';
      try {
        const d = new Date(isoString);
        return d.toLocaleDateString('fr-MA', {
          day: '2-digit', month: 'short', year: 'numeric'
        });
      } catch { return isoString; }
    },

    /**
     * Returns a status badge HTML string.
     */
    statusBadge(status) {
      const map = {
        'Payé':                ['badge-success', '✓ Payé'],
        'Partiellement payé':  ['badge-warning', '◑ Partiel'],
        'Non payé':            ['badge-danger',  '✕ Non payé'],
      };
      const [cls, label] = map[status] || ['badge-info', status];
      return `<span class="badge ${cls}">${label}</span>`;
    },

    /**
     * Escapes HTML special characters to prevent XSS.
     */
    escapeHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }
  };

  // ──────────────────────────────────────────────
  // Theme & Language helpers
  // ──────────────────────────────────────────────

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    // Highlight active button if settings page is open
    document.querySelectorAll('[data-theme-val]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.themeVal === theme);
    });
    try {
      if (typeof bridge !== 'undefined' && bridge.send) {
        bridge.send('update_theme', { theme: theme });
      }
    } catch (e) {
      console.warn('Could not notify native window of theme change', e);
    }
  }

  const I18N = {
    fr: {
      nav_customers: 'Clients',
      nav_debts: 'Dettes',
      nav_payments: 'Paiements',
      nav_archive: 'Archive',
      nav_settings: 'Paramètres',
      logout: 'Déconnexion',
      save: 'Enregistrer',
      cancel: 'Annuler',
      delete: 'Supprimer',
      close: 'Fermer',
      save_changes: 'Enregistrer les modifications',
      archive: 'Archiver',
      restore: 'Restaurer',
      add_debt: 'Ajouter la dette',
      new_customer: '+ Nouveau client',
      new_debt: '+ Nouvelle dette',
      record_payment: '+ Enregistrer un versement',
      search_placeholder: 'Rechercher un client (Nom, Tél, CIN)…',
      lang_applied: 'Langue : Français'
    },
    ar: {
      nav_customers: 'الزبائن',
      nav_debts: 'الديون',
      nav_payments: 'الدفعات',
      nav_archive: 'الأرشيف',
      nav_settings: 'الإعدادات',
      logout: 'تسجيل الخروج',
      save: 'حفظ',
      cancel: 'إلغاء',
      delete: 'حذف',
      close: 'إغلاق',
      save_changes: 'حفظ التعديلات',
      archive: 'أرشفة',
      restore: 'استرجاع',
      add_debt: 'إضافة الدين',
      new_customer: '+ زبون جديد',
      new_debt: '+ دين جديد',
      record_payment: '+ تسجيل دفعة',
      search_placeholder: 'البحث عن زبون (الاسم، الهاتف، بطاقة التعريف)...',
      lang_applied: 'اللغة: العربية'
    },
    en: {
      nav_customers: 'Customers',
      nav_debts: 'Debts',
      nav_payments: 'Payments',
      nav_archive: 'Archive',
      nav_settings: 'Settings',
      logout: 'Logout',
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      close: 'Close',
      save_changes: 'Save changes',
      archive: 'Archive',
      restore: 'Restore',
      add_debt: 'Add debt',
      new_customer: '+ New Customer',
      new_debt: '+ New Debt',
      record_payment: '+ Record Payment',
      search_placeholder: 'Search customer (Name, Phone, ID)...',
      lang_applied: 'Language: English'
    }
  };

  function applyLanguage(lang) {
    const validLangs = ['fr', 'ar', 'en'];
    const l = validLangs.includes(lang) ? lang : 'fr';
    const t = I18N[l] || I18N.fr;

    document.documentElement.setAttribute('lang', l);
    document.documentElement.setAttribute('dir', l === 'ar' ? 'rtl' : 'ltr');

    // Update routes titles
    if (routes.customers) routes.customers.title = t.nav_customers;
    if (routes.debts)     routes.debts.title     = t.nav_debts;
    if (routes.payments)  routes.payments.title  = t.nav_payments;
    if (routes.archive)   routes.archive.title   = t.nav_archive;
    if (routes.settings)  routes.settings.title  = t.nav_settings;

    // Update sidebar navigation labels
    const navMap = {
      customers: t.nav_customers,
      debts: t.nav_debts,
      payments: t.nav_payments,
      archive: t.nav_archive,
      settings: t.nav_settings
    };
    Object.keys(navMap).forEach(key => {
      const el = document.querySelector(`.nav-item[data-page="${key}"] .nav-label`);
      if (el) el.textContent = navMap[key];
    });

    // Update sidebar logout button
    const logoutSpan = document.querySelector('#btnSidebarLogout span');
    if (logoutSpan) logoutSpan.textContent = t.logout;

    // Update current page title
    if (currentPage && routes[currentPage]) {
      pageTitle.textContent = routes[currentPage].title;
    }

    // Update common modal buttons
    const btnCancelAddCust = document.getElementById('btnCancelAddCustomer');
    if (btnCancelAddCust) btnCancelAddCust.textContent = t.cancel;
    const btnSubmitAddCust = document.getElementById('btnSubmitAddCustomer');
    if (btnSubmitAddCust && !btnSubmitAddCust.disabled) btnSubmitAddCust.textContent = t.save;

    const btnCancelEditCust = document.getElementById('btnCancelEditCustomer');
    if (btnCancelEditCust) btnCancelEditCust.textContent = t.cancel;
    const btnSubmitEditCust = document.getElementById('btnSubmitEditCustomer');
    if (btnSubmitEditCust && !btnSubmitEditCust.disabled) btnSubmitEditCust.textContent = t.save_changes;

    const btnCloseViewCust = document.getElementById('btnCloseViewCustomer');
    if (btnCloseViewCust) btnCloseViewCust.textContent = t.close;

    const btnCancelArchCust = document.getElementById('btnCancelArchiveCustomer');
    if (btnCancelArchCust) btnCancelArchCust.textContent = t.cancel;
    const btnConfirmArchCust = document.getElementById('btnConfirmArchiveCustomer');
    if (btnConfirmArchCust && !btnConfirmArchCust.disabled) btnConfirmArchCust.textContent = t.archive;

    const btnCancelPay = document.getElementById('btnCancelAddPayment');
    if (btnCancelPay) btnCancelPay.textContent = t.cancel;
    const btnSubmitPay = document.getElementById('btnSubmitAddPayment');
    if (btnSubmitPay && !btnSubmitPay.disabled) btnSubmitPay.textContent = t.save;

    const btnCancelAddD = document.getElementById('btnCancelAddDebt');
    if (btnCancelAddD) btnCancelAddD.textContent = t.cancel;
    const btnSubmitAddD = document.getElementById('btnSubmitAddDebt');
    if (btnSubmitAddD && !btnSubmitAddD.disabled) btnSubmitAddD.textContent = t.add_debt;

    const btnCancelEditD = document.getElementById('btnCancelEditDebt');
    if (btnCancelEditD) btnCancelEditD.textContent = t.cancel;
    const btnSubmitEditD = document.getElementById('btnSubmitEditDebt');
    if (btnSubmitEditD && !btnSubmitEditD.disabled) btnSubmitEditD.textContent = t.save_changes;

    const btnCloseViewD = document.getElementById('btnCloseViewDebt');
    if (btnCloseViewD) btnCloseViewD.textContent = t.close;

    const btnCancelDelD = document.getElementById('btnCancelDeleteDebt');
    if (btnCancelDelD) btnCancelDelD.textContent = t.cancel;
    const btnConfirmDelD = document.getElementById('btnConfirmDeleteDebt');
    if (btnConfirmDelD && !btnConfirmDelD.disabled) btnConfirmDelD.textContent = t.delete;

    // Highlight active button if settings page is open
    document.querySelectorAll('[data-lang-val]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.langVal === l);
    });
  }

  function updateSidebarLogo(base64) {
    const iconEl = document.getElementById('sidebarBrandIcon');
    if (!iconEl) return;
    if (base64) {
      iconEl.innerHTML = `<img src="${base64}" alt="Logo" style="width:28px;height:28px;object-fit:contain;border-radius:4px;" />`;
    } else {
      iconEl.innerHTML = '●';
    }
  }

  // ──────────────────────────────────────────────
  // Settings Page Logic
  // ──────────────────────────────────────────────

  /** Called when C# returns app_settings payload */
  function onAppSettingsReceived(payload) {
    if (!payload) return;

    // Fill username display
    const su = document.getElementById('settingsCurrentUsername');
    if (su) su.textContent = payload.username || '—';

    // Fill identity fields
    const titleInput = document.getElementById('settingsAppTitle');
    if (titleInput) titleInput.value = payload.app_title || '';

    // Fill logo preview
    if (payload.app_logo) {
      const preview = document.getElementById('settingsLogoPreview');
      const placeholder = document.getElementById('settingsLogoPlaceholder');
      const removeBtn = document.getElementById('btnRemoveLogo');
      if (preview) {
        if (placeholder) placeholder.style.display = 'none';
        // Remove any existing img
        const oldImg = preview.querySelector('img');
        if (oldImg) oldImg.remove();
        const img = document.createElement('img');
        img.src = payload.app_logo;
        img.alt = 'Logo';
        preview.appendChild(img);
      }
      if (removeBtn) removeBtn.style.display = '';
    }

    // Apply theme toggles
    const currentTheme = payload.app_theme || 'light';
    applyTheme(currentTheme);

    // Apply language toggles
    const currentLang = payload.app_language || 'fr';
    applyLanguage(currentLang);
  }

  /** Initializes the Settings page — called when navigating to 'settings' */
  function initSettingsPage() {
    // Ask C# for persisted settings
    bridge.send('get_app_settings', {});

    // ── Theme toggle buttons
    document.querySelectorAll('[data-theme-val]').forEach(btn => {
      btn.addEventListener('click', () => {
        const theme = btn.dataset.themeVal;
        applyTheme(theme);
        bridge.send('update_app_settings', { app_theme: theme });
      });
    });

    // ── Language toggle buttons
    document.querySelectorAll('[data-lang-val]').forEach(btn => {
      btn.addEventListener('click', () => {
        const lang = btn.dataset.langVal;
        applyLanguage(lang);
        bridge.send('update_app_settings', { app_language: lang });
        // Small toast confirmation
        const labels = { fr: 'Langue : Français', ar: 'اللغة : العربية', en: 'Language: English' };
        toast(labels[lang] || 'Langue mise à jour.', 'info', 2000);
      });
    });

    // ── Save credentials button
    const btnSaveCreds = document.getElementById('btnSaveCredentials');
    if (btnSaveCreds) {
      btnSaveCreds.addEventListener('click', () => {
        // Clear previous errors
        ['settingsNewUsername','settingsCurrentPassword','settingsNewPassword','settingsConfirmPassword','settingsCredentials'].forEach(id => {
          const el = document.getElementById('err-' + id);
          if (el) el.textContent = '';
        });

        const currentPwd  = (document.getElementById('settingsCurrentPassword')?.value || '').trim();
        const newUsername = (document.getElementById('settingsNewUsername')?.value || '').trim();
        const newPwd      = (document.getElementById('settingsNewPassword')?.value || '');
        const confirmPwd  = (document.getElementById('settingsConfirmPassword')?.value || '');

        // Validate
        if (!currentPwd) {
          const el = document.getElementById('err-settingsCurrentPassword');
          if (el) el.textContent = 'Le mot de passe actuel est obligatoire.';
          return;
        }
        if (newUsername && newUsername.length < 3) {
          const el = document.getElementById('err-settingsNewUsername');
          if (el) el.textContent = 'Le nom d\'utilisateur doit avoir au moins 3 caractères.';
          return;
        }
        if (newPwd && newPwd !== confirmPwd) {
          const el = document.getElementById('err-settingsConfirmPassword');
          if (el) el.textContent = 'Les mots de passe ne correspondent pas.';
          return;
        }
        if (!newUsername && !newPwd) {
          const el = document.getElementById('err-settingsCredentials');
          if (el) el.textContent = 'Veuillez modifier au moins le nom d\'utilisateur ou le mot de passe.';
          return;
        }

        btnSaveCreds.disabled = true;
        btnSaveCreds.textContent = 'Enregistrement…';
        bridge.send('update_admin_credentials', {
          currentPassword: currentPwd,
          newUsername:     newUsername || null,
          newPassword:     newPwd     || null
        });
      });
    }

    // ── Save identity button
    const btnSaveId = document.getElementById('btnSaveIdentity');
    if (btnSaveId) {
      btnSaveId.addEventListener('click', () => {
        const appTitle = (document.getElementById('settingsAppTitle')?.value || '').trim();
        // Get logo from preview (base64)
        const preview = document.getElementById('settingsLogoPreview');
        const logoImg = preview ? preview.querySelector('img') : null;
        const logoBase64 = logoImg ? logoImg.src : null;

        btnSaveId.disabled = true;
        btnSaveId.textContent = 'Enregistrement…';
        bridge.send('update_app_settings', {
          app_title: appTitle || null,
          app_logo:  logoBase64
        });
      });
    }

    // ── Logo file input
    const logoInput = document.getElementById('settingsLogoInput');
    if (logoInput) {
      logoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
          const base64 = ev.target.result;
          const preview = document.getElementById('settingsLogoPreview');
          const placeholder = document.getElementById('settingsLogoPlaceholder');
          const removeBtn = document.getElementById('btnRemoveLogo');
          if (preview) {
            if (placeholder) placeholder.style.display = 'none';
            const oldImg = preview.querySelector('img');
            if (oldImg) oldImg.remove();
            const img = document.createElement('img');
            img.src = base64;
            img.alt = 'Logo';
            preview.appendChild(img);
          }
          if (removeBtn) removeBtn.style.display = '';
        };
        reader.readAsDataURL(file);
        // Reset input so same file can be re-selected
        logoInput.value = '';
      });
    }

    // ── Remove logo button
    const btnRemoveLogo = document.getElementById('btnRemoveLogo');
    if (btnRemoveLogo) {
      btnRemoveLogo.addEventListener('click', () => {
        const preview = document.getElementById('settingsLogoPreview');
        const placeholder = document.getElementById('settingsLogoPlaceholder');
        if (preview) {
          const oldImg = preview.querySelector('img');
          if (oldImg) oldImg.remove();
          if (placeholder) placeholder.style.display = '';
        }
        btnRemoveLogo.style.display = 'none';
      });
    }
  }

  // ──────────────────────────────────────────────
  // Sidebar click handler & Logout confirmation
  // ──────────────────────────────────────────────

  function initSidebar() {
    document.querySelectorAll('.nav-item').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        navigate(el.dataset.page);
      });
    });
  }

  function initLogout() {
    const btnSidebarLogout = $('btnSidebarLogout');
    const logoutModalOverlay = $('logoutModalOverlay');
    const btnCloseLogoutModal = $('btnCloseLogoutModal');
    const btnCancelLogout = $('btnCancelLogout');
    const btnConfirmLogout = $('btnConfirmLogout');

    function openModal() {
      if (logoutModalOverlay) logoutModalOverlay.classList.add('visible');
    }
    function closeModal() {
      if (logoutModalOverlay) logoutModalOverlay.classList.remove('visible');
    }

    if (btnSidebarLogout) btnSidebarLogout.addEventListener('click', openModal);
    if (btnCloseLogoutModal) btnCloseLogoutModal.addEventListener('click', closeModal);
    if (btnCancelLogout) btnCancelLogout.addEventListener('click', closeModal);
    if (logoutModalOverlay) {
      logoutModalOverlay.addEventListener('click', e => {
        if (e.target === logoutModalOverlay) closeModal();
      });
    }

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && logoutModalOverlay && logoutModalOverlay.classList.contains('visible')) {
        closeModal();
      }
    });

    if (btnConfirmLogout) {
      btnConfirmLogout.addEventListener('click', () => {
        btnConfirmLogout.disabled = true;
        btnConfirmLogout.textContent = 'Déconnexion…';
        bridge.send('logout');
      });
    }
  }

  // ──────────────────────────────────────────────
  // Initialization
  // ──────────────────────────────────────────────

  function init() {
    initSidebar();
    initLogout();
    if (typeof Debts !== 'undefined' && Debts.initModals) {
      Debts.initModals();
    }

    // Global modal close handlers (X buttons, backdrop clicks, Escape key)
    document.addEventListener('click', function (e) {
      const closeTrigger = e.target.closest('.modal-close, .btn-close, [data-dismiss="modal"]');
      if (closeTrigger) {
        const overlay = closeTrigger.closest('.modal-overlay');
        if (overlay) {
          overlay.classList.remove('active', 'visible');
          const f = overlay.querySelector('form');
          if (f) {
            f.reset();
            overlay.querySelectorAll('.field-error, .form-error').forEach(err => { err.style.display = 'none'; });
          }
        }
        return;
      }
      if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active', 'visible');
        const f = e.target.querySelector('form');
        if (f) {
          f.reset();
          e.target.querySelectorAll('.field-error, .form-error').forEach(err => { err.style.display = 'none'; });
        }
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        const activeModal = document.querySelector('.modal-overlay.active, .modal-overlay.visible');
        if (activeModal) {
          activeModal.classList.remove('active', 'visible');
          const f = activeModal.querySelector('form');
          if (f) {
            f.reset();
            activeModal.querySelectorAll('.field-error, .form-error').forEach(err => { err.style.display = 'none'; });
          }
        }
      }
    });

    updateClock();
    setInterval(updateClock, 1000);

    // Bind Window Control Buttons (Minimize / Maximize / Close)
    const btnMin = document.getElementById('btnWinMinimize');
    const btnMax = document.getElementById('btnWinMaximize');
    const btnClose = document.getElementById('btnWinClose');

    if (btnMin) btnMin.addEventListener('click', () => bridge.send('window_minimize'));
    if (btnMax) btnMax.addEventListener('click', () => bridge.send('window_maximize'));
    if (btnClose) btnClose.addEventListener('click', () => bridge.send('window_close'));

    // Register the C# → JS bridge receiver on the window object
    window.addEventListener('message', e => bridge.receive(e.data));
    if (window.chrome && window.chrome.webview) {
      window.chrome.webview.addEventListener('message', e => bridge.receive(e.data));
    }

    // Check authentication with backend
    bridge.send('check_auth');

    // Default page is Clients (NO Dashboard)
    navigate('customers');
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // ──────────────────────────────────────────────
  // Public API (for C# to call via ExecuteScriptAsync)
  // ──────────────────────────────────────────────
  return {
    navigate,
    toast,
    bridge,
    utils,
  };

})();
