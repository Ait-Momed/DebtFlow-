/**
 * debts.js — Tahiri Lilatate
 * Handles all UI logic for the Debts page, partial payments, receipt printing,
 * and customer debts panel. Communicates with C# via App.bridge.
 */

'use strict';

var Debts = (function () {

  var searchTimeout = null;
  var currentAddDebtCustomerId = null;
  var currentAddDebtCustomerName = null;
  var currentEditDebtId = null;
  var currentPaymentDebtId = null;
  var _debtsMap = {};

  // ──────────────────────────────────────────────
  // Status badge helper
  // ──────────────────────────────────────────────
  function statusBadge(status) {
    if (status === 'Payé') return '<span class="badge badge-success">✓ Payé</span>';
    if (status === 'Partiellement payé') return '<span class="badge badge-warning">◑ Partiel</span>';
    return '<span class="badge badge-danger">✕ Non payé</span>';
  }

  // ──────────────────────────────────────────────
  // Page "Dettes" renderer
  // Table columns requested:
  // ──────────────────────────────────────────────
  // Page "Dettes" renderer
  // Table columns:
  // N° Dette | Client | Téléphone | CIN | Date | Montant | Payé | Restant | Statut | Actions
  // ──────────────────────────────────────────────
  function renderPage() {
    return (
      '<div class="page-header">' +
        '<span class="page-header-title">' +
          'Dettes ' +
          '<span class="customer-count" id="debtCountLabel">0</span>' +
        '</span>' +
        '<div class="page-header-actions" style="flex-wrap: wrap; gap: 8px;">' +
          '<div class="search-bar">' +
            '<svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>' +
            '<input type="text" class="form-control" id="debtSearchInput" placeholder="Rechercher (Client, Tél, CIN, Note)…" style="min-width: 200px;" />' +
          '</div>' +
          '<select class="form-control" id="debtStatusFilter" style="width: auto; min-width: 140px;" title="Filtrer par statut">' +
            '<option value="all">Tous les statuts</option>' +
            '<option value="Non payé">Non payée</option>' +
            '<option value="Partiellement payé">Partiellement payée</option>' +
            '<option value="Payé">Payée</option>' +
          '</select>' +
          '<select class="form-control" id="debtPeriodFilter" style="width: auto; min-width: 140px;" title="Filtrer par date">' +
            '<option value="">Toutes les dates</option>' +
            '<option value="today">Aujourd\'hui</option>' +
            '<option value="week">Cette semaine</option>' +
            '<option value="month">Ce mois</option>' +
            '<option value="custom">Personnalisée</option>' +
          '</select>' +
          '<div id="debtCustomDates" style="display: none; align-items: center; gap: 4px;">' +
            '<input type="date" class="form-control" id="debtDateFrom" style="width: 130px;" title="Date début" />' +
            '<span style="font-size: 12px; color: var(--color-text-muted);">à</span>' +
            '<input type="date" class="form-control" id="debtDateTo" style="width: 130px;" title="Date fin" />' +
          '</div>' +
          '<button type="button" class="btn btn-primary" onclick="Debts.openAddDebt()" id="btnOpenAddDebtFromPage">' +
            '+ Nouvelle dette' +
          '</button>' +
        '</div>' +
      '</div>' +

      '<div class="table-wrapper">' +
        '<table>' +
          '<thead><tr>' +
            '<th>N° Dette</th>' +
            '<th>Client</th>' +
            '<th>Téléphone</th>' +
            '<th>CIN</th>' +
            '<th>Date</th>' +
            '<th>Montant</th>' +
            '<th>Payé</th>' +
            '<th>Restant</th>' +
            '<th>Statut</th>' +
            '<th>Actions</th>' +
          '</tr></thead>' +
          '<tbody id="debtsTableBody">' +
            '<tr><td colspan="10" class="table-empty">' +
              '<div class="empty-state">' +
                '<div class="empty-state-icon">' +
                  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
                    '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>' +
                    '<polyline points="9 22 9 12 15 12 15 22"/>' +
                  '</svg>' +
                '</div>' +
                '<div class="empty-state-title">Chargement...</div>' +
              '</div>' +
            '</td></tr>' +
          '</tbody>' +
        '</table>' +
      '</div>'
    );
  }

  function fetchDebts() {
    var searchInput = document.getElementById('debtSearchInput');
    var statusSelect = document.getElementById('debtStatusFilter');
    var periodSelect = document.getElementById('debtPeriodFilter');
    var dateFromInput = document.getElementById('debtDateFrom');
    var dateToInput = document.getElementById('debtDateTo');

    var query = searchInput ? searchInput.value.trim() : '';
    var status = statusSelect ? statusSelect.value : 'all';
    var period = periodSelect ? periodSelect.value : '';
    var dateFrom = (period === 'custom' && dateFromInput) ? dateFromInput.value : '';
    var dateTo = (period === 'custom' && dateToInput) ? dateToInput.value : '';

    App.bridge.send('get_debts', {
      query: query,
      status: status,
      period: period,
      dateFrom: dateFrom,
      dateTo: dateTo
    });
  }

  // ──────────────────────────────────────────────
  // Init page events
  // ──────────────────────────────────────────────
  function initPage() {
    fetchDebts();
    App.bridge.send('get_customers', { query: '' });

    var searchInput = document.getElementById('debtSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function (e) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(function () {
          fetchDebts();
        }, 250);
      });
    }

    var statusSelect = document.getElementById('debtStatusFilter');
    if (statusSelect) {
      statusSelect.addEventListener('change', function () {
        fetchDebts();
      });
    }

    var periodSelect = document.getElementById('debtPeriodFilter');
    var customDatesDiv = document.getElementById('debtCustomDates');
    if (periodSelect) {
      periodSelect.addEventListener('change', function () {
        if (customDatesDiv) {
          customDatesDiv.style.display = (this.value === 'custom') ? 'inline-flex' : 'none';
        }
        fetchDebts();
      });
    }

    var dateFromInput = document.getElementById('debtDateFrom');
    if (dateFromInput) {
      dateFromInput.addEventListener('change', function () {
        fetchDebts();
      });
    }

    var dateToInput = document.getElementById('debtDateTo');
    if (dateToInput) {
      dateToInput.addEventListener('change', function () {
        fetchDebts();
      });
    }
  }

  // ──────────────────────────────────────────────
  // Render debts list from bridge response
  // ──────────────────────────────────────────────
  function onDebtsList(payload) {
    var tbody = document.getElementById('debtsTableBody');
    var countLabel = document.getElementById('debtCountLabel');
    if (!tbody) return;

    var debts = payload.debts || [];
    _debtsMap = {};
    debts.forEach(function (d) { _debtsMap[d.Id] = d; });

    if (countLabel) countLabel.textContent = debts.length;

    if (debts.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="10" class="table-empty">' +
          '<div class="empty-state-compact"><div class="empty-state-title">Aucune dette trouvée</div></div>' +
        '</td></tr>';
      return;
    }

    var rows = debts.map(function (d) {
      var isFullyPaid = (d.RemainingAmount <= 0);

      var payButton = isFullyPaid
        ? '<button type="button" class="btn-action btn-pay" disabled title="Dette entièrement payée">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>' +
          '</button>'
        : '<button type="button" class="btn-action btn-pay" onclick="Debts.openAddPayment(' + d.Id + ')" title="Enregistrer un versement">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>' +
          '</button>';

      var editButton = isFullyPaid
        ? ''
        : '<button type="button" class="btn-action btn-edit" onclick="Debts.openEditDebt(' + d.Id + ')" title="Modifier la dette">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>' +
          '</button>';

      var deleteButton = '<button type="button" class="btn-action btn-delete" onclick="Debts.openDeleteDebt(' + d.Id + ')" title="Supprimer la dette">' +
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>' +
        '</button>';

      return (
        '<tr>' +
          '<td><span class="text-muted" style="font-weight: 600;">#' + String(d.Id).padStart(3, '0') + '</span></td>' +
          '<td><strong>' + escHtml(d.CustomerName || '—') + '</strong></td>' +
          '<td>' + escHtml(d.CustomerPhone || '—') + '</td>' +
          '<td>' + escHtml(d.CustomerCIN || '—') + '</td>' +
          '<td>' + formatDate(d.DebtDate) + '</td>' +
          '<td><strong>' + formatDH(d.Amount) + '</strong></td>' +
          '<td>' + formatDH(d.PaidAmount) + '</td>' +
          '<td><strong style="color: ' + (isFullyPaid ? 'var(--color-success)' : 'var(--color-danger)') + ';">' + formatDH(d.RemainingAmount) + '</strong></td>' +
          '<td>' + statusBadge(d.Status) + '</td>' +
          '<td>' +
            '<div class="action-buttons">' +
              '<button type="button" class="btn-action btn-view" onclick="Debts.openViewDebt(' + d.Id + ')" title="Voir les détails">' +
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>' +
              '</button>' +
              payButton +
              deleteButton +
              '<button type="button" class="btn-action btn-print" onclick="Debts.printReceipt(' + d.Id + ')" title="Imprimer le reçu">' +
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>' +
              '</button>' +
            '</div>' +
          '</td>' +
        '</tr>'
      );
    });
    tbody.innerHTML = rows.join('');
  }

  // ──────────────────────────────────────────────
  // Customer debts panel (inside customer view modal)
  // ──────────────────────────────────────────────
  function loadCustomerDebts(customerId, customerName) {
    currentAddDebtCustomerId = customerId;
    currentAddDebtCustomerName = customerName;
    var section = document.getElementById('customerDebtsSection');
    if (section) {
      section.innerHTML = '<div class="empty-state-compact"><div class="empty-state-title">Chargement...</div></div>';
    }
    App.bridge.send('get_customer_debts', { CustomerId: customerId });
  }

  function onCustomerDebtsList(payload) {
    var section = document.getElementById('customerDebtsSection');
    if (!section) return;

    var debts = payload.debts || [];

    if (debts.length === 0) {
      section.innerHTML =
        '<div class="empty-state-compact">' +
          '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>' +
          '<p>Aucune dette enregistrée pour ce client.</p>' +
        '</div>';
      return;
    }

    var rows = debts.map(function (d, i) {
      var isFullyPaid = (d.RemainingAmount <= 0);
      var payBtn = isFullyPaid
        ? '<button type="button" class="btn-action btn-pay" disabled title="Dette entièrement payée">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>' +
          '</button>'
        : '<button type="button" class="btn-action btn-pay" onclick="Debts.openAddPayment(' + d.Id + ')" title="Enregistrer un versement">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>' +
          '</button>';

      return (
        '<tr>' +
          '<td>#' + (i + 1) + '</td>' +
          '<td>' + formatDate(d.DebtDate) + '</td>' +
          '<td><strong>' + formatDH(d.Amount) + '</strong></td>' +
          '<td>' + formatDH(d.PaidAmount) + '</td>' +
          '<td><strong style="color: ' + (isFullyPaid ? 'var(--color-success)' : 'var(--color-danger)') + ';">' + formatDH(d.RemainingAmount) + '</strong></td>' +
          '<td>' + statusBadge(d.Status) + '</td>' +
          '<td>' +
            '<div class="action-buttons">' +
              '<button type="button" class="btn-action btn-view" onclick="Debts.openViewDebt(' + d.Id + ')" title="Voir">' +
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>' +
              '</button>' +
              payBtn +
            '</div>' +
          '</td>' +
        '</tr>'
      );
    });

    section.innerHTML =
      '<table class="debts-mini-table">' +
        '<thead><tr>' +
          '<th>#</th><th>Date</th><th>Montant</th><th>Payé</th><th>Reste</th><th>Statut</th><th>Actions</th>' +
        '</tr></thead>' +
        '<tbody>' + rows.join('') + '</tbody>' +
      '</table>';
  }

  // ──────────────────────────────────────────────
  // Add Debt Modal
  // ──────────────────────────────────────────────
  var _pendingAddDebtMode = null;

  function findCustomerDebtInMap(customerId) {
    if (!customerId) return null;
    var unpaid = null;
    var latest = null;
    for (var id in _debtsMap) {
      var d = _debtsMap[id];
      if (d.CustomerId === customerId) {
        if (!latest || parseInt(d.Id) > parseInt(latest.Id)) latest = d;
        if (parseFloat(d.RemainingAmount) > 0 && (!unpaid || parseInt(d.Id) > parseInt(unpaid.Id))) {
          unpaid = d;
        }
      }
    }
    return unpaid || latest;
  }

  function updateAddDebtPreview() {
    var selectEl = document.getElementById('addDebtCustomerSelect');
    var custId = currentAddDebtCustomerId || (selectEl ? parseInt(selectEl.value) : 0);
    var infoBox = document.getElementById('addDebtExistingInfo');
    var currentAmtEl = document.getElementById('addDebtCurrentAmount');
    var calcPreview = document.getElementById('addDebtCalcPreview');
    var newTotalEl = document.getElementById('addDebtNewTotalAmount');
    var amountInput = document.getElementById('addDebtAmount');

    if (!infoBox || !currentAmtEl || !calcPreview || !newTotalEl) return;

    if (!custId || isNaN(custId)) {
      infoBox.style.display = 'none';
      calcPreview.style.display = 'none';
      return;
    }

    var existingDebt = findCustomerDebtInMap(custId);
    if (!existingDebt) {
      infoBox.style.display = 'none';
      calcPreview.style.display = 'none';
      return;
    }

    var currentAmount = parseFloat(existingDebt.Amount) || 0;
    var enteredAmount = amountInput ? parseFloat(amountInput.value) : 0;

    infoBox.style.display = 'block';
    currentAmtEl.textContent = formatDH(currentAmount);

    if (!isNaN(enteredAmount) && enteredAmount > 0) {
      var newTotal = currentAmount + enteredAmount;
      calcPreview.style.display = 'flex';
      newTotalEl.textContent = formatDH(newTotal) + ' (' + formatDH(currentAmount) + ' + ' + formatDH(enteredAmount) + ')';
    } else {
      calcPreview.style.display = 'none';
    }
  }

  // ──────────────────────────────────────────────
  // Add Debt Modal
  // ──────────────────────────────────────────────
  function openAddDebt(customerId, customerName) {
    currentAddDebtCustomerId = customerId || null;
    currentAddDebtCustomerName = customerName || null;
    _pendingAddDebtMode = null;

    var overlay = document.getElementById('addDebtModalOverlay');
    if (!overlay) return;

    var staticRow = document.getElementById('addDebtCustomerStaticRow');
    var selectRow = document.getElementById('addDebtCustomerSelectRow');
    var nameEl = document.getElementById('addDebtCustomerName');
    var selectEl = document.getElementById('addDebtCustomerSelect');

    var form = document.getElementById('addDebtForm');
    if (form) form.reset();
    clearDebtErrors('addDebtForm');

    // Ensure debts map is loaded for accumulation
    if (Object.keys(_debtsMap).length === 0) {
      fetchDebts();
    }

    if (customerId) {
      if (staticRow) staticRow.style.display = 'block';
      if (selectRow) selectRow.style.display = 'none';
      if (nameEl) nameEl.textContent = customerName || '—';
    } else {
      if (staticRow) staticRow.style.display = 'none';
      if (selectRow) selectRow.style.display = 'block';
      populateCustomerSelectForDebt();
    }

    updateAddDebtPreview();

    var amountInput = document.getElementById('addDebtAmount');
    if (amountInput) {
      amountInput.oninput = updateAddDebtPreview;
    }

    var dateInput = document.getElementById('addDebtDate');
    if (dateInput) {
      var today = new Date();
      var y = today.getFullYear();
      var m = String(today.getMonth() + 1).padStart(2, '0');
      var d = String(today.getDate()).padStart(2, '0');
      dateInput.value = y + '-' + m + '-' + d;
    }

    overlay.classList.add('active');
    setTimeout(function () {
      if (customerId) {
        if (amountInput) amountInput.focus();
      } else {
        if (selectEl) selectEl.focus();
      }
    }, 60);
  }

  function populateCustomerSelectForDebt() {
    var selectEl = document.getElementById('addDebtCustomerSelect');
    if (!selectEl) return;

    var previousVal = selectEl.value;
    selectEl.innerHTML = '<option value="">-- Choisir un client --</option>';

    var customersMap = window._customersMap || {};
    var ids = Object.keys(customersMap);

    if (ids.length === 0) {
      App.bridge.send('get_customers', { query: '' });
      return;
    }

    var list = [];
    ids.forEach(function (id) {
      if (customersMap[id]) list.push(customersMap[id]);
    });

    list.sort(function (a, b) {
      return (a.FullName || '').localeCompare(b.FullName || '');
    });

    list.forEach(function (c) {
      var opt = document.createElement('option');
      opt.value = c.Id;
      opt.textContent = c.FullName + (c.Phone ? ' (' + c.Phone + ')' : '');
      if (previousVal && String(c.Id) === String(previousVal)) {
        opt.selected = true;
      }
      selectEl.appendChild(opt);
    });

    selectEl.onchange = function () {
      var cid = parseInt(this.value);
      currentAddDebtCustomerId = cid || null;
      if (cid && window._customersMap && window._customersMap[cid]) {
        currentAddDebtCustomerName = window._customersMap[cid].FullName;
      }
      clearDebtErrors('addDebtForm');
      updateAddDebtPreview();
    };

    updateAddDebtPreview();
  }

  function submitAddDebt() {
    var selectEl = document.getElementById('addDebtCustomerSelect');
    var custId = currentAddDebtCustomerId || (selectEl ? parseInt(selectEl.value) : 0);

    var amountVal = (document.getElementById('addDebtAmount').value || '').trim();
    var dateVal = (document.getElementById('addDebtDate').value || '').trim();
    var notesVal = (document.getElementById('addDebtNotes').value || '').trim();

    clearDebtErrors('addDebtForm');

    if (!custId || isNaN(custId)) {
      showDebtError('addDebtCustomerSelectError', 'Veuillez sélectionner un client.');
      if (selectEl) selectEl.focus();
      return;
    }

    if (!amountVal) {
      showDebtError('addDebtAmountError', 'Veuillez saisir le montant de la dette.');
      var amtInput = document.getElementById('addDebtAmount');
      if (amtInput) amtInput.focus();
      return;
    }
    var amount = parseFloat(amountVal);
    if (isNaN(amount) || amount <= 0) {
      showDebtError('addDebtAmountError', 'Le montant doit être supérieur à 0 DH.');
      return;
    }
    if (!dateVal) {
      showDebtError('addDebtDateError', 'Veuillez sélectionner une date valide.');
      return;
    }

    var btn = document.getElementById('btnSubmitAddDebt');
    if (btn) { btn.disabled = true; btn.textContent = 'Enregistrement...'; }

    var existingDebt = findCustomerDebtInMap(custId);
    if (existingDebt) {
      var newTotalAmount = Number((parseFloat(existingDebt.Amount) + amount).toFixed(2));
      var combinedNotes = existingDebt.Notes ? (existingDebt.Notes + (notesVal ? ' | ' + notesVal : '')) : (notesVal || null);

      _pendingAddDebtMode = {
        isAccumulation: true,
        customerId: custId,
        addedAmount: amount,
        newTotal: newTotalAmount
      };

      App.bridge.send('update_debt', {
        Id: existingDebt.Id,
        Amount: newTotalAmount,
        DebtDate: dateVal,
        Notes: combinedNotes
      });
    } else {
      _pendingAddDebtMode = {
        isAccumulation: false,
        customerId: custId,
        addedAmount: amount,
        newTotal: amount
      };

      App.bridge.send('add_debt', {
        CustomerId: custId,
        Amount: amount,
        DebtDate: dateVal,
        Notes: notesVal || null
      });
    }
  }

  function onAddDebtResponse(payload) {
    var btn = document.getElementById('btnSubmitAddDebt');
    if (btn) { btn.disabled = false; btn.textContent = 'Ajouter la dette'; }

    if (payload.success) {
      var overlay = document.getElementById('addDebtModalOverlay');
      if (overlay) overlay.classList.remove('active');
      var form = document.getElementById('addDebtForm');
      if (form) form.reset();
      clearDebtErrors('addDebtForm');
      var infoBox = document.getElementById('addDebtExistingInfo');
      if (infoBox) infoBox.style.display = 'none';

      var payOverlay = document.getElementById('addPaymentModalOverlay');
      if (payOverlay) payOverlay.classList.remove('active');

      var payBtn = document.getElementById('btnSubmitAddPayment');
      if (payBtn) { payBtn.disabled = false; payBtn.textContent = 'Enregistrer'; }

      var msg = (_pendingAddDebtMode && _pendingAddDebtMode.isAccumulation)
        ? 'Montant ajouté avec succès (+ ' + formatDH(_pendingAddDebtMode.addedAmount) + '). Nouveau montant dans le tableau : ' + formatDH(_pendingAddDebtMode.newTotal)
        : 'Dette ajoutée avec succès.';
      App.toast(msg, 'success');
      _pendingAddDebtMode = null;

      // Refresh Debts table immediately
      fetchDebts();
      // Refresh Customers table immediately
      App.bridge.send('get_customers', { query: (document.getElementById('searchInput') || {}).value || '' });

      if (document.getElementById('customerDebtsSection') && currentAddDebtCustomerId) {
        loadCustomerDebts(currentAddDebtCustomerId, currentAddDebtCustomerName);
      }
    } else {
      _pendingAddDebtMode = null;
      App.toast(payload.message || 'Erreur lors de l\'ajout.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // Edit Debt Modal
  // ──────────────────────────────────────────────
  function openEditDebt(id) {
    currentEditDebtId = id;
    App.bridge.send('get_debt_by_id', { Id: id, Action: 'edit' });
  }

  function submitEditDebt() {
    var idVal = parseInt(document.getElementById('editDebtId').value);
    var amountVal = (document.getElementById('editDebtAmount').value || '').trim();
    var dateVal = (document.getElementById('editDebtDate').value || '').trim();
    var notesVal = (document.getElementById('editDebtNotes').value || '').trim();

    clearDebtErrors('editDebtForm');

    if (!amountVal) {
      showDebtError('editDebtAmountError', 'Veuillez saisir le montant de la dette.');
      return;
    }
    var amount = parseFloat(amountVal);
    if (isNaN(amount) || amount <= 0) {
      showDebtError('editDebtAmountError', 'Le montant doit être supérieur à 0 DH.');
      return;
    }
    if (!dateVal) {
      showDebtError('editDebtDateError', 'Veuillez sélectionner une date valide.');
      return;
    }

    var btn = document.getElementById('btnSubmitEditDebt');
    if (btn) { btn.disabled = true; btn.textContent = 'Enregistrement...'; }

    App.bridge.send('update_debt', {
      Id: idVal,
      Amount: amount,
      DebtDate: dateVal,
      Notes: notesVal || null
    });
  }

  function onUpdateDebtResponse(payload) {
    var btn = document.getElementById('btnSubmitEditDebt');
    if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer les modifications'; }
    var addBtn = document.getElementById('btnSubmitAddDebt');
    if (addBtn) { addBtn.disabled = false; addBtn.textContent = 'Ajouter la dette'; }

    if (payload.success) {
      var overlay = document.getElementById('editDebtModalOverlay');
      if (overlay) overlay.classList.remove('active');

      if (_pendingAddDebtMode) {
        var addOverlay = document.getElementById('addDebtModalOverlay');
        if (addOverlay) addOverlay.classList.remove('active');
        var form = document.getElementById('addDebtForm');
        if (form) form.reset();
        clearDebtErrors('addDebtForm');
        var infoBox = document.getElementById('addDebtExistingInfo');
        if (infoBox) infoBox.style.display = 'none';

        var msg = _pendingAddDebtMode.isAccumulation
          ? 'Montant ajouté avec succès (+ ' + formatDH(_pendingAddDebtMode.addedAmount) + '). Nouveau montant dans le tableau : ' + formatDH(_pendingAddDebtMode.newTotal)
          : 'Dette ajoutée avec succès.';
        App.toast(msg, 'success');
        _pendingAddDebtMode = null;
      } else {
        App.toast('Dette modifiée avec succès.', 'success');
      }

      if (document.getElementById('debtsTableBody')) {
        fetchDebts();
      }
      App.bridge.send('get_customers', { query: (document.getElementById('searchInput') || {}).value || '' });
      if (document.getElementById('customerDebtsSection') && currentAddDebtCustomerId) {
        loadCustomerDebts(currentAddDebtCustomerId, currentAddDebtCustomerName);
      }
    } else {
      _pendingAddDebtMode = null;
      App.toast(payload.message || 'Erreur lors de la modification.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // View Debt Modal & Payments History
  // ──────────────────────────────────────────────
  function openViewDebt(id) {
    App.bridge.send('get_debt_by_id', { Id: id, Action: 'view' });
  }

  function onDebtDetails(payload) {
    if (!payload.success || !payload.debt) {
      App.toast(payload.message || 'Dette introuvable.', 'error');
      return;
    }
    var d = payload.debt;
    _debtsMap[d.Id] = d;

    if (payload.actionRequested === 'edit') {
      var overlay = document.getElementById('editDebtModalOverlay');
      if (!overlay) return;
      document.getElementById('editDebtId').value = d.Id;
      document.getElementById('editDebtCustomerName').textContent = d.CustomerName || '—';
      document.getElementById('editDebtAmount').value = d.Amount;
      document.getElementById('editDebtDate').value = (d.DebtDate || '').substring(0, 10);
      document.getElementById('editDebtNotes').value = d.Notes || '';
      clearDebtErrors('editDebtForm');
      overlay.classList.add('active');
      setTimeout(function () {
        var input = document.getElementById('editDebtAmount');
        if (input) input.focus();
      }, 60);
    } else if (payload.actionRequested === 'view') {
      var vOverlay = document.getElementById('viewDebtModalOverlay');
      if (!vOverlay) return;
      document.getElementById('viewDebtId').textContent = '#' + String(d.Id).padStart(3, '0');
      document.getElementById('viewDebtCustomer').textContent = d.CustomerName || '—';
      document.getElementById('viewDebtPhone').textContent = d.CustomerPhone || '—';
      document.getElementById('viewDebtCIN').textContent = d.CustomerCIN || '—';
      document.getElementById('viewDebtDate').textContent = formatDate(d.DebtDate);
      document.getElementById('viewDebtAmount').textContent = formatDH(d.Amount);
      document.getElementById('viewDebtPaid').textContent = formatDH(d.PaidAmount);
      document.getElementById('viewDebtRemaining').textContent = formatDH(d.RemainingAmount);
      document.getElementById('viewDebtStatus').innerHTML = statusBadge(d.Status);
      document.getElementById('viewDebtNotes').textContent = d.Notes || '—';

      // Configure pay button from view modal
      var btnPayFromView = document.getElementById('btnPayFromViewDebt');
      if (btnPayFromView) {
        if (d.RemainingAmount <= 0) {
          btnPayFromView.disabled = true;
          btnPayFromView.textContent = '✓ Soldée';
          btnPayFromView.className = 'btn btn-secondary btn-sm';
        } else {
          btnPayFromView.disabled = false;
          btnPayFromView.textContent = '+ Verser un paiement';
          btnPayFromView.className = 'btn btn-primary btn-sm';
          btnPayFromView.onclick = function () {
            openAddPayment(d.Id);
          };
        }
      }

      // Render payments history in view modal
      var historySection = document.getElementById('debtPaymentsHistorySection');
      if (historySection) {
        var payments = d.Payments || [];
        if (payments.length === 0) {
          historySection.innerHTML =
            '<div class="empty-state-compact">' +
              '<p>Aucun versement enregistré pour cette dette.</p>' +
            '</div>';
        } else {
          var pRows = payments.map(function (p, i) {
            return (
              '<tr>' +
                '<td>#' + (i + 1) + '</td>' +
                '<td>' + formatDate(p.PaymentDate) + '</td>' +
                '<td><strong style="color: var(--color-success);">' + formatDH(p.Amount) + '</strong></td>' +
                '<td>' + escHtml(p.Notes || '—') + '</td>' +
              '</tr>'
            );
          });
          historySection.innerHTML =
            '<table class="debts-mini-table">' +
              '<thead><tr>' +
                '<th>#</th><th>Date</th><th>Montant versé</th><th>Remarque</th>' +
              '</tr></thead>' +
              '<tbody>' + pRows.join('') + '</tbody>' +
            '</table>';
        }
      }

      vOverlay.classList.add('active');
    }
  }

  // ──────────────────────────────────────────────
  // ──────────────────────────────────────────────
  // Add Payment Modal & Handler
  // ──────────────────────────────────────────────
  function openAddPayment(preselectedDebtId) {
    currentPaymentDebtId = preselectedDebtId || null;
    var overlay = document.getElementById('addPaymentModalOverlay');
    if (!overlay) return;

    var form = document.getElementById('addPaymentForm');
    if (form) form.reset();
    clearDebtErrors('addPaymentForm');

    var selectEl = document.getElementById('addPaymentCustomerSelect');
    var phoneInput = document.getElementById('addPaymentCustomerPhone');
    var debtDisplay = document.getElementById('addPaymentDebtDisplay');
    var debtIdHidden = document.getElementById('addPaymentDebtId');
    var pill = document.getElementById('addPaymentDebtRemainingPill');

    if (phoneInput) phoneInput.value = '';
    if (debtDisplay) debtDisplay.value = '';
    if (debtIdHidden) debtIdHidden.value = '';
    if (pill) pill.style.display = 'none';

    // Populate customers dropdown
    populatePaymentCustomerSelect(preselectedDebtId);

    var dateInput = document.getElementById('addPaymentDate');
    if (dateInput) {
      var today = new Date();
      var y = today.getFullYear();
      var m = String(today.getMonth() + 1).padStart(2, '0');
      var day = String(today.getDate()).padStart(2, '0');
      dateInput.value = y + '-' + m + '-' + day;
    }

    overlay.classList.add('active');
    setTimeout(function () {
      var amountInput = document.getElementById('addPaymentAmount');
      if (preselectedDebtId && amountInput) {
        amountInput.focus();
      } else if (selectEl) {
        selectEl.focus();
      }
    }, 60);
  }

  function populatePaymentCustomerSelect(preselectedDebtId) {
    var selectEl = document.getElementById('addPaymentCustomerSelect');
    if (!selectEl) return;

    selectEl.innerHTML = '<option value="">-- Sélectionner un client --</option>';

    var customersMap = window._customersMap || {};
    var custIds = Object.keys(customersMap);

    if (custIds.length === 0) {
      App.bridge.send('get_customers', { query: '' });
      App.bridge.send('get_debts', { query: '' });
      return;
    }

    var list = [];
    custIds.forEach(function (cid) {
      if (customersMap[cid]) list.push(customersMap[cid]);
    });

    list.sort(function (a, b) {
      return (a.FullName || '').localeCompare(b.FullName || '');
    });

    var selectedCustomerId = null;
    if (preselectedDebtId && _debtsMap[preselectedDebtId]) {
      selectedCustomerId = _debtsMap[preselectedDebtId].CustomerId;
    }

    list.forEach(function (c) {
      var opt = document.createElement('option');
      opt.value = c.Id;
      opt.textContent = c.FullName + (c.Phone ? ' (' + c.Phone + ')' : '');
      if (selectedCustomerId && c.Id === selectedCustomerId) {
        opt.selected = true;
      }
      selectEl.appendChild(opt);
    });

    selectEl.onchange = function () {
      onPaymentCustomerSelected(parseInt(this.value));
    };

    if (selectedCustomerId) {
      onPaymentCustomerSelected(selectedCustomerId, preselectedDebtId);
    }
  }

  function onPaymentCustomerSelected(customerId, forcedDebtId) {
    var debtIdHidden = document.getElementById('addPaymentDebtId');
    var pill = document.getElementById('addPaymentDebtRemainingPill');
    var pillAmount = document.getElementById('addPaymentDebtRemainingAmount');

    clearDebtErrors('addPaymentForm');

    if (!customerId || isNaN(customerId)) {
      if (debtIdHidden) debtIdHidden.value = '';
      if (pill) pill.style.display = 'none';
      return;
    }

    // Find the debt for this customer
    var targetDebt = null;
    if (forcedDebtId && _debtsMap[forcedDebtId]) {
      targetDebt = _debtsMap[forcedDebtId];
    } else {
      var debts = Object.keys(_debtsMap).map(function (k) { return _debtsMap[k]; });
      var customerDebts = debts.filter(function (d) { return d.CustomerId === customerId; });
      customerDebts.sort(function (a, b) { return b.Id - a.Id; });

      var active = customerDebts.filter(function (d) { return d.RemainingAmount > 0; });
      targetDebt = (active.length > 0) ? active[0] : (customerDebts.length > 0 ? customerDebts[0] : null);
    }

    if (targetDebt) {
      if (debtIdHidden) debtIdHidden.value = targetDebt.Id;
      if (pill && pillAmount) {
        pill.style.display = 'block';
        pillAmount.textContent = formatDH(targetDebt.RemainingAmount);
      }
    } else {
      if (debtIdHidden) debtIdHidden.value = '';
      if (pill) pill.style.display = 'none';
    }
  }

  function submitAddPayment() {
    clearDebtErrors('addPaymentForm');

    var selectEl = document.getElementById('addPaymentCustomerSelect');
    var customerId = selectEl ? parseInt(selectEl.value) : 0;
    var debtIdHidden = document.getElementById('addPaymentDebtId');
    var debtId = debtIdHidden ? parseInt(debtIdHidden.value) : 0;

    if (!customerId || isNaN(customerId)) {
      showDebtError('addPaymentCustomerSelectError', 'Veuillez sélectionner un client.');
      if (selectEl) selectEl.focus();
      return;
    }

    if (!debtId || isNaN(debtId)) {
      showDebtError('addPaymentCustomerSelectError', 'Ce client n\'a pas de dette enregistrée.');
      return;
    }

    var amountVal = (document.getElementById('addPaymentAmount').value || '').trim();
    var dateVal = (document.getElementById('addPaymentDate').value || '').trim();
    var notesVal = (document.getElementById('addPaymentNotes').value || '').trim();

    if (!amountVal) {
      showDebtError('addPaymentAmountError', 'Veuillez saisir le montant versé.');
      var amtInput = document.getElementById('addPaymentAmount');
      if (amtInput) amtInput.focus();
      return;
    }
    var amount = parseFloat(amountVal);
    if (isNaN(amount) || amount <= 0) {
      showDebtError('addPaymentAmountError', 'Le montant doit être supérieur à 0 DH.');
      return;
    }

    if (!dateVal) {
      showDebtError('addPaymentDateError', 'Veuillez sélectionner une date valide.');
      return;
    }

    var selDebt = _debtsMap[debtId];
    if (selDebt && selDebt.RemainingAmount > 0 && amount > selDebt.RemainingAmount) {
      showDebtError('addPaymentAmountError', 'Le montant dépasse le reste à payer (' + formatDH(selDebt.RemainingAmount) + ').');
      return;
    }

    var btn = document.getElementById('btnSubmitAddPayment');
    if (btn) { btn.disabled = true; btn.textContent = 'Enregistrement...'; }

    App.bridge.send('add_payment', {
      DebtId: debtId,
      Amount: amount,
      PaymentDate: dateVal,
      Notes: notesVal || null
    });
  }

  function onAddPaymentResponse(payload) {
    var btn = document.getElementById('btnSubmitAddPayment');
    if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer'; }

    if (payload.success) {
      var overlay = document.getElementById('addPaymentModalOverlay');
      if (overlay) overlay.classList.remove('active');

      App.toast(payload.message || 'Versement enregistré avec succès.', 'success');

      if (payload.debt) {
        _debtsMap[payload.debt.Id] = payload.debt;
      }

      // Refresh Debts table
      App.bridge.send('get_debts', { query: (document.getElementById('debtSearchInput') || {}).value || '' });
      // Refresh Payments table
      App.bridge.send('get_payments', { query: (document.getElementById('paymentSearchInput') || {}).value || '' });
      // Refresh Customers table
      App.bridge.send('get_customers', { query: (document.getElementById('searchInput') || {}).value || '' });

      if (currentAddDebtCustomerId) {
        loadCustomerDebts(currentAddDebtCustomerId, currentAddDebtCustomerName);
      }
      if (currentPaymentDebtId && document.getElementById('viewDebtModalOverlay')?.classList.contains('active')) {
        openViewDebt(currentPaymentDebtId);
      }
    } else {
      App.toast(payload.message || 'Erreur lors du versement.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // Receipt Printing
  // ──────────────────────────────────────────────
  function printReceipt(debtId) {
    var d = _debtsMap[debtId];
    if (!d) {
      App.toast('Dette introuvable pour impression.', 'error');
      return;
    }

    var printWindow = window.open('', '_blank', 'width=800,height=700');
    if (!printWindow) {
      window.print();
      return;
    }

    var html =
      '<!DOCTYPE html>' +
      '<html lang="fr">' +
      '<head>' +
        '<meta charset="UTF-8">' +
        '<title>Reçu de dette #' + String(d.Id).padStart(3, '0') + ' — Tahiri Lilatate</title>' +
        '<style>' +
          'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1E293B; background: #FFF; line-height: 1.5; }' +
          '.header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #512DA8; padding-bottom: 15px; }' +
          '.title { font-size: 24px; font-weight: 800; color: #512DA8; margin: 0; }' +
          '.subtitle { font-size: 13px; color: #64748B; margin-top: 4px; }' +
          '.receipt-badge { display: inline-block; background: #F1F5F9; border: 1px solid #CBD5E1; padding: 4px 14px; border-radius: 20px; font-size: 14px; font-weight: 700; color: #334155; margin-top: 10px; }' +
          '.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 18px; }' +
          '.info-block { display: flex; flex-direction: column; gap: 4px; font-size: 14px; }' +
          '.info-label { font-size: 12px; font-weight: 600; color: #64748B; text-transform: uppercase; }' +
          '.info-val { font-size: 15px; font-weight: 600; color: #0F172A; }' +
          'table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 14px; }' +
          'th { background: #512DA8; color: #FFF; text-align: left; padding: 10px 12px; font-weight: 600; }' +
          'td { padding: 10px 12px; border-bottom: 1px solid #E2E8F0; }' +
          '.total-row { font-weight: 700; font-size: 15px; background: #F8FAFC; }' +
          '.status { display: inline-block; padding: 3px 10px; border-radius: 4px; font-weight: 700; font-size: 12px; }' +
          '.status-success { background: #DCFCE7; color: #166534; }' +
          '.status-warning { background: #FEF3C7; color: #92400E; }' +
          '.status-danger { background: #FEE2E2; color: #991B1B; }' +
          '.footer { margin-top: 40px; display: flex; justify-content: space-between; font-size: 13px; color: #64748B; border-top: 1px solid #E2E8F0; padding-top: 15px; }' +
          '.stamp-box { border: 1px dashed #CBD5E1; border-radius: 6px; width: 160px; height: 75px; display: flex; align-items: center; justify-content: center; color: #94A3B8; font-size: 12px; margin-top: 8px; }' +
          '@media print { body { padding: 0; } }' +
        '</style>' +
      '</head>' +
      '<body>' +
        '<div class="header">' +
          '<h1 class="title">TAHIRI LILATATE</h1>' +
          '<div class="subtitle">Commerce et Gestion des dettes — Reçu officiel</div>' +
          '<div class="receipt-badge">Dette N° #' + String(d.Id).padStart(3, '0') + '</div>' +
        '</div>' +

        '<div class="info-grid">' +
          '<div class="info-block"><span class="info-label">Client</span><span class="info-val">' + escHtml(d.CustomerName || '—') + '</span></div>' +
          '<div class="info-block"><span class="info-label">Téléphone</span><span class="info-val">' + escHtml(d.CustomerPhone || '—') + '</span></div>' +
          '<div class="info-block"><span class="info-label">CIN</span><span class="info-val">' + escHtml(d.CustomerCIN || '—') + '</span></div>' +
          '<div class="info-block"><span class="info-label">Date d\'enregistrement</span><span class="info-val">' + formatDate(d.DebtDate) + '</span></div>' +
        '</div>' +

        '<table>' +
          '<thead>' +
            '<tr><th>Désignation</th><th style="text-align: right;">Montant</th></tr>' +
          '</thead>' +
          '<tbody>' +
            '<tr><td>Montant initial de la dette</td><td style="text-align: right;"><strong>' + formatDH(d.Amount) + '</strong></td></tr>' +
            '<tr><td>Total des versements effectués</td><td style="text-align: right; color: #166534;"><strong>' + formatDH(d.PaidAmount) + '</strong></td></tr>' +
            '<tr class="total-row"><td>Reste à payer</td><td style="text-align: right; color: ' + (d.RemainingAmount <= 0 ? '#166534' : '#991B1B') + ';"><strong>' + formatDH(d.RemainingAmount) + '</strong></td></tr>' +
            '<tr><td>Statut du paiement</td><td style="text-align: right;"><span class="status ' + (d.Status === 'Payé' ? 'status-success' : d.Status === 'Partiellement payé' ? 'status-warning' : 'status-danger') + '">' + d.Status + '</span></td></tr>' +
          '</tbody>' +
        '</table>' +

        (d.Notes ? '<p style="font-size: 13px; color: #64748B;"><strong>Notes :</strong> ' + escHtml(d.Notes) + '</p>' : '') +

        '<div class="footer">' +
          '<div>' +
            '<div>Date d\'impression : ' + new Date().toLocaleDateString('fr-MA') + ' à ' + new Date().toLocaleTimeString('fr-MA', { hour: '2-digit', minute: '2-digit' }) + '</div>' +
            '<div style="margin-top: 4px;">Merci pour votre confiance.</div>' +
          '</div>' +
          '<div style="text-align: center;">' +
            '<div>Signature / Cachet :</div>' +
            '<div class="stamp-box">Cachet magasin</div>' +
          '</div>' +
        '</div>' +

        '<script>' +
          'window.onload = function() { window.print(); };' +
        '<\/script>' +
      '</body>' +
      '</html>';

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  }

  // ──────────────────────────────────────────────
  // Delete Debt Modal & Handlers
  // ──────────────────────────────────────────────
  function openDeleteDebt(id) {
    var d = _debtsMap[id];
    var overlay = document.getElementById('deleteDebtModalOverlay');
    if (!overlay) return;

    var idInput = document.getElementById('deleteDebtId');
    if (idInput) idInput.value = id;

    var numEl = document.getElementById('deleteDebtTargetNum');
    if (numEl) numEl.textContent = '#' + String(id).padStart(3, '0');

    var clientEl = document.getElementById('deleteDebtTargetClient');
    if (clientEl) clientEl.textContent = (d && d.CustomerName) ? d.CustomerName : '—';

    var amountEl = document.getElementById('deleteDebtTargetAmount');
    if (amountEl) amountEl.textContent = d ? formatDH(d.Amount) : '—';

    overlay.classList.add('active');
  }

  function submitDeleteDebt() {
    var idInput = document.getElementById('deleteDebtId');
    var id = idInput ? parseInt(idInput.value) : 0;
    if (!id || isNaN(id)) return;

    var btn = document.getElementById('btnConfirmDeleteDebt');
    if (btn) { btn.disabled = true; btn.textContent = 'Suppression...'; }

    App.bridge.send('delete_debt', { Id: id });
  }

  function onDeleteDebtResponse(payload) {
    var btn = document.getElementById('btnConfirmDeleteDebt');
    if (btn) { btn.disabled = false; btn.textContent = 'Supprimer'; }

    var overlay = document.getElementById('deleteDebtModalOverlay');
    if (overlay) overlay.classList.remove('active');

    if (payload.success) {
      App.toast(payload.message || 'Dette supprimée avec succès.', 'success');
      fetchDebts();
      App.bridge.send('get_customers', { query: (document.getElementById('searchInput') || {}).value || '' });
      if (document.getElementById('customerDebtsSection') && currentAddDebtCustomerId) {
        loadCustomerDebts(currentAddDebtCustomerId, currentAddDebtCustomerName);
      }
    } else {
      App.toast(payload.message || 'Impossible de supprimer cette dette.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // Modal init (called on startup)
  // ──────────────────────────────────────────────
  var modalsInitialized = false;
  function initModals() {
    if (modalsInitialized) return;
    modalsInitialized = true;

    // Submit add debt
    var addForm = document.getElementById('addDebtForm');
    if (addForm) {
      addForm.onsubmit = function (e) {
        e.preventDefault();
        submitAddDebt();
      };
    }

    // Submit edit debt
    var editForm = document.getElementById('editDebtForm');
    if (editForm) {
      editForm.onsubmit = function (e) {
        e.preventDefault();
        submitEditDebt();
      };
    }

    // Submit add payment
    var paymentForm = document.getElementById('addPaymentForm');
    if (paymentForm) {
      paymentForm.onsubmit = function (e) {
        e.preventDefault();
        submitAddPayment();
      };
    }

    // Cancel & close add payment modal
    function closeAddPaymentModal() {
      var overlay = document.getElementById('addPaymentModalOverlay');
      if (overlay) overlay.classList.remove('active');
      var form = document.getElementById('addPaymentForm');
      if (form) form.reset();
      clearDebtErrors('addPaymentForm');
      var pill = document.getElementById('addPaymentDebtRemainingPill');
      if (pill) pill.style.display = 'none';
      var btn = document.getElementById('btnSubmitAddPayment');
      if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer'; }
    }
    var btnCancelPay = document.getElementById('btnCancelAddPayment');
    if (btnCancelPay) btnCancelPay.onclick = closeAddPaymentModal;
    var btnClosePay = document.getElementById('btnCloseAddPaymentModal');
    if (btnClosePay) btnClosePay.onclick = closeAddPaymentModal;

    // Cancel & close add debt modal
    function closeAddDebtModal() {
      var overlay = document.getElementById('addDebtModalOverlay');
      if (overlay) overlay.classList.remove('active');
      var form = document.getElementById('addDebtForm');
      if (form) form.reset();
      clearDebtErrors('addDebtForm');
      var infoBox = document.getElementById('addDebtExistingInfo');
      if (infoBox) infoBox.style.display = 'none';
      var calcPreview = document.getElementById('addDebtCalcPreview');
      if (calcPreview) calcPreview.style.display = 'none';
      var btn = document.getElementById('btnSubmitAddDebt');
      if (btn) { btn.disabled = false; btn.textContent = 'Ajouter la dette'; }
      _pendingAddDebtMode = null;
    }
    var btnCancelAddD = document.getElementById('btnCancelAddDebt');
    if (btnCancelAddD) btnCancelAddD.onclick = closeAddDebtModal;
    var btnCloseAddD = document.getElementById('btnCloseAddDebtModal');
    if (btnCloseAddD) btnCloseAddD.onclick = closeAddDebtModal;

    // Cancel & close edit debt modal
    function closeEditDebtModal() {
      var overlay = document.getElementById('editDebtModalOverlay');
      if (overlay) overlay.classList.remove('active');
      var form = document.getElementById('editDebtForm');
      if (form) form.reset();
      clearDebtErrors('editDebtForm');
      var btn = document.getElementById('btnSubmitEditDebt');
      if (btn) { btn.disabled = false; btn.textContent = 'Enregistrer les modifications'; }
    }
    var btnCancelEditD = document.getElementById('btnCancelEditDebt');
    if (btnCancelEditD) btnCancelEditD.onclick = closeEditDebtModal;
    var btnCloseEditD = document.getElementById('btnCloseEditDebtModal');
    if (btnCloseEditD) btnCloseEditD.onclick = closeEditDebtModal;

    // Close view debt modal
    function closeViewDebtModal() {
      var overlay = document.getElementById('viewDebtModalOverlay');
      if (overlay) overlay.classList.remove('active');
    }
    var btnCloseViewD = document.getElementById('btnCloseViewDebt');
    if (btnCloseViewD) btnCloseViewD.onclick = closeViewDebtModal;
    var btnCloseViewD2 = document.getElementById('btnCloseViewDebtModal');
    if (btnCloseViewD2) btnCloseViewD2.onclick = closeViewDebtModal;

    // Delete debt modal buttons
    var btnCancelDel = document.getElementById('btnCancelDeleteDebt');
    if (btnCancelDel) {
      btnCancelDel.onclick = function () {
        var overlay = document.getElementById('deleteDebtModalOverlay');
        if (overlay) overlay.classList.remove('active');
      };
    }
    var btnCloseDel = document.getElementById('btnCloseDeleteDebtModal');
    if (btnCloseDel) {
      btnCloseDel.onclick = function () {
        var overlay = document.getElementById('deleteDebtModalOverlay');
        if (overlay) overlay.classList.remove('active');
      };
    }
    var btnConfirmDel = document.getElementById('btnConfirmDeleteDebt');
    if (btnConfirmDel) {
      btnConfirmDel.onclick = function () {
        submitDeleteDebt();
      };
    }
  }

  // ──────────────────────────────────────────────
  // Helpers
  // ──────────────────────────────────────────────
  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatDH(amount) {
    if (amount === null || amount === undefined) return '— DH';
    var num = parseFloat(amount);
    if (isNaN(num)) return '— DH';
    return num.toLocaleString('fr-MA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' DH';
  }

  function formatDate(isoString) {
    if (!isoString) return '—';
    try {
      var d = new Date(isoString);
      return d.toLocaleDateString('fr-MA', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch (ex) { return isoString; }
  }

  function showDebtError(elementId, message) {
    var el = document.getElementById(elementId);
    if (el) { el.textContent = message; el.style.display = 'block'; }
  }

  function clearDebtErrors(formId) {
    var form = document.getElementById(formId);
    if (!form) return;
    form.querySelectorAll('.field-error').forEach(function (el) {
      el.style.display = 'none';
    });
  }

  // ──────────────────────────────────────────────
  // Public API
  // ──────────────────────────────────────────────
  return {
    renderPage: renderPage,
    initPage: initPage,
    initModals: initModals,
    fetchDebts: fetchDebts,
    onDebtsList: onDebtsList,
    onCustomerDebtsList: onCustomerDebtsList,
    onDebtDetails: onDebtDetails,
    onAddDebtResponse: onAddDebtResponse,
    onUpdateDebtResponse: onUpdateDebtResponse,
    onDeleteDebtResponse: onDeleteDebtResponse,
    onAddPaymentResponse: onAddPaymentResponse,
    loadCustomerDebts: loadCustomerDebts,
    openAddDebt: openAddDebt,
    populateCustomerSelectForDebt: populateCustomerSelectForDebt,
    updateAddDebtPreview: updateAddDebtPreview,
    openViewDebt: openViewDebt,
    openEditDebt: openEditDebt,
    openDeleteDebt: openDeleteDebt,
    submitDeleteDebt: submitDeleteDebt,
    openAddPayment: openAddPayment,
    printReceipt: printReceipt
  };

})();

window.Debts = Debts;
