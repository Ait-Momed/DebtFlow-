/**
 * archive.js — Tahiri Lilatate
 * Phase 7: Comprehensive Archive Management
 * Handles real-time search, multi-criteria filters, statistics cards,
 * pagination, details inspection, receipt printing, restoration, and permanent deletion.
 */

'use strict';

var Archive = (function () {

  // ──────────────────────────────────────────────
  // State
  // ──────────────────────────────────────────────
  var _rawCustomers = [];
  var _rawDebts = [];
  var _rawPayments = [];
  var _stats = { total: 0, customers: 0, debts: 0, payments: 0 };

  var _currentFilterType = 'all';      // 'all' | 'customers' | 'debts' | 'payments'
  var _currentPeriod = 'all';          // 'all' | 'today' | 'week' | 'month' | 'year' | 'custom'
  var _currentStatus = 'all';          // 'all' | 'unpaid' | 'partial' | 'paid'
  var _searchQuery = '';
  var _customDateFrom = '';
  var _customDateTo = '';

  var _pageSize = 10;
  var _currentPage = 1;

  var _activeViewItem = null;
  var _searchTimeout = null;

  // ──────────────────────────────────────────────
  // Render Archive Page
  // ──────────────────────────────────────────────
  function renderPage() {
    return (
      '<div class="page-header">' +
        '<span class="page-header-title">' +
          'Archive ' +
          '<span class="customer-count" id="archiveTotalBadge">0</span>' +
        '</span>' +
        '<div class="page-header-actions">' +
          '<div class="search-bar" style="width: 280px;">' +
            '<svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>' +
            '<input type="text" class="form-control" id="archiveSearchInput" placeholder="Rechercher (Nom, Tél, CIN, N° dette, Date)…" />' +
          '</div>' +
        '</div>' +
      '</div>' +

      // ── Quick Stats Grid (4 Cards) ──
      '<div class="archive-stats-grid">' +
        '<div class="archive-stat-card">' +
          '<div class="stat-card-header">' +
            '<span class="stat-card-label">Total archivé</span>' +
            '<div class="stat-card-icon" style="color: var(--color-primary);">' +
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>' +
            '</div>' +
          '</div>' +
          '<div class="stat-card-value" id="statArchiveTotal">0</div>' +
          '<div class="stat-card-sub">Éléments dans l\'historique</div>' +
        '</div>' +

        '<div class="archive-stat-card">' +
          '<div class="stat-card-header">' +
            '<span class="stat-card-label">Clients archivés</span>' +
            '<div class="stat-card-icon" style="color: var(--color-info);">' +
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>' +
            '</div>' +
          '</div>' +
          '<div class="stat-card-value" id="statArchiveCustomers">0</div>' +
          '<div class="stat-card-sub">Comptes clients conservés</div>' +
        '</div>' +

        '<div class="archive-stat-card">' +
          '<div class="stat-card-header">' +
            '<span class="stat-card-label">Dettes archivées</span>' +
            '<div class="stat-card-icon" style="color: var(--color-warning);">' +
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>' +
            '</div>' +
          '</div>' +
          '<div class="stat-card-value" id="statArchiveDebts">0</div>' +
          '<div class="stat-card-sub">Dettes inactives associées</div>' +
        '</div>' +

        '<div class="archive-stat-card">' +
          '<div class="stat-card-header">' +
            '<span class="stat-card-label">Paiements archivés</span>' +
            '<div class="stat-card-icon" style="color: var(--color-success);">' +
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>' +
            '</div>' +
          '</div>' +
          '<div class="stat-card-value" id="statArchivePayments">0</div>' +
          '<div class="stat-card-sub">Historique des règlements</div>' +
        '</div>' +
      '</div>' +

      // ── Filter Toolbar ──
      '<div class="archive-filter-bar">' +
        '<div class="filter-pills">' +
          '<button type="button" class="filter-pill active" data-type="all">Tous</button>' +
          '<button type="button" class="filter-pill" data-type="customers">Clients</button>' +
          '<button type="button" class="filter-pill" data-type="debts">Dettes</button>' +
          '<button type="button" class="filter-pill" data-type="payments">Paiements</button>' +
        '</div>' +

        '<div class="filter-selects">' +
          '<div class="filter-group">' +
            '<label class="filter-label">Période :</label>' +
            '<select class="form-control form-control-sm" id="archivePeriodSelect">' +
              '<option value="all">Toutes les dates</option>' +
              '<option value="today">Aujourd\'hui</option>' +
              '<option value="week">Cette semaine</option>' +
              '<option value="month">Ce mois</option>' +
              '<option value="year">Cette année</option>' +
              '<option value="custom">Période personnalisée</option>' +
            '</select>' +
          '</div>' +

          '<div class="filter-group" id="archiveStatusGroup">' +
            '<label class="filter-label">Statut dette :</label>' +
            '<select class="form-control form-control-sm" id="archiveStatusSelect">' +
              '<option value="all">Tous les statuts</option>' +
              '<option value="unpaid">Non payé</option>' +
              '<option value="partial">Partiellement payé</option>' +
              '<option value="paid">Payé</option>' +
            '</select>' +
          '</div>' +

          '<div class="filter-group" id="customDateRangeGroup" style="display: none; align-items: center; gap: 6px;">' +
            '<input type="date" class="form-control form-control-sm" id="archiveDateFrom" style="width: 130px;" />' +
            '<span style="color: var(--color-text-muted);">à</span>' +
            '<input type="date" class="form-control form-control-sm" id="archiveDateTo" style="width: 130px;" />' +
          '</div>' +
        '</div>' +
      '</div>' +

      // ── Main Archive Table ──
      '<div class="table-wrapper">' +
        '<table>' +
          '<thead><tr>' +
            '<th>Type</th>' +
            '<th>Référence</th>' +
            '<th>Nom du client</th>' +
            '<th>Téléphone</th>' +
            '<th>Date de création</th>' +
            '<th>Montant</th>' +
            '<th>Montant payé</th>' +
            '<th>Montant restant</th>' +
            '<th>Statut</th>' +
            '<th>Date d\'archivage</th>' +
            '<th>Actions</th>' +
          '</tr></thead>' +
          '<tbody id="archiveTableBody">' +
            '<tr><td colspan="11" class="table-empty">' +
              '<div class="empty-state">' +
                '<div class="empty-state-icon">' +
                  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">' +
                    '<polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line>' +
                  '</svg>' +
                '</div>' +
                '<div class="empty-state-title">Chargement des archives...</div>' +
              '</div>' +
            '</td></tr>' +
          '</tbody>' +
        '</table>' +
      '</div>' +

      // ── Pagination Bar ──
      '<div class="archive-pagination-bar" id="archivePaginationBar">' +
        '<div class="pagination-info">' +
          'Affichage de <span id="paginationStart">0</span> à <span id="paginationEnd">0</span> sur <span id="paginationTotal">0</span> éléments' +
        '</div>' +
        '<div class="pagination-controls">' +
          '<div style="display: flex; align-items: center; gap: 8px; margin-right: 12px;">' +
            '<span style="font-size: 13px; color: var(--color-text-muted);">Lignes par page :</span>' +
            '<select class="form-control form-control-sm" id="archivePageSizeSelect" style="width: 70px;">' +
              '<option value="10">10</option>' +
              '<option value="25">25</option>' +
              '<option value="50">50</option>' +
              '<option value="100">100</option>' +
            '</select>' +
          '</div>' +
          '<button type="button" class="btn btn-secondary btn-sm" id="btnArchivePrevPage" disabled>Précédent</button>' +
          '<div id="archivePageNumbers" style="display: flex; gap: 4px;"></div>' +
          '<button type="button" class="btn btn-secondary btn-sm" id="btnArchiveNextPage" disabled>Suivant</button>' +
        '</div>' +
      '</div>'
    );
  }

  // ──────────────────────────────────────────────
  // Init page events
  // ──────────────────────────────────────────────
  function initPage() {
    App.bridge.send('get_archive', {});

    // Search input with debounce
    var searchInput = document.getElementById('archiveSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function (e) {
        clearTimeout(_searchTimeout);
        _searchTimeout = setTimeout(function () {
          _searchQuery = e.target.value.trim().toLowerCase();
          _currentPage = 1;
          renderFilteredTable();
        }, 200);
      });
    }

    // Type filter pills
    document.querySelectorAll('.filter-pill').forEach(function (pill) {
      pill.onclick = function () {
        document.querySelectorAll('.filter-pill').forEach(function (p) { p.classList.remove('active'); });
        pill.classList.add('active');
        _currentFilterType = pill.dataset.type;
        _currentPage = 1;

        // Toggle visibility of status select when debts are relevant
        var statusGroup = document.getElementById('archiveStatusGroup');
        if (statusGroup) {
          statusGroup.style.display = (_currentFilterType === 'customers' || _currentFilterType === 'payments') ? 'none' : 'flex';
        }

        renderFilteredTable();
      };
    });

    // Period select
    var periodSelect = document.getElementById('archivePeriodSelect');
    if (periodSelect) {
      periodSelect.onchange = function () {
        _currentPeriod = this.value;
        var customRange = document.getElementById('customDateRangeGroup');
        if (customRange) {
          customRange.style.display = (_currentPeriod === 'custom') ? 'flex' : 'none';
        }
        _currentPage = 1;
        renderFilteredTable();
      };
    }

    // Custom date range inputs
    var dateFromInput = document.getElementById('archiveDateFrom');
    var dateToInput = document.getElementById('archiveDateTo');
    if (dateFromInput) {
      dateFromInput.onchange = function () {
        _customDateFrom = this.value;
        _currentPage = 1;
        renderFilteredTable();
      };
    }
    if (dateToInput) {
      dateToInput.onchange = function () {
        _customDateTo = this.value;
        _currentPage = 1;
        renderFilteredTable();
      };
    }

    // Status select
    var statusSelect = document.getElementById('archiveStatusSelect');
    if (statusSelect) {
      statusSelect.onchange = function () {
        _currentStatus = this.value;
        _currentPage = 1;
        renderFilteredTable();
      };
    }

    // Page size select
    var pageSizeSelect = document.getElementById('archivePageSizeSelect');
    if (pageSizeSelect) {
      pageSizeSelect.value = String(_pageSize);
      pageSizeSelect.onchange = function () {
        _pageSize = parseInt(this.value);
        _currentPage = 1;
        renderFilteredTable();
      };
    }

    // Pagination buttons
    var btnPrev = document.getElementById('btnArchivePrevPage');
    if (btnPrev) {
      btnPrev.onclick = function () {
        if (_currentPage > 1) {
          _currentPage--;
          renderFilteredTable();
        }
      };
    }
    var btnNext = document.getElementById('btnArchiveNextPage');
    if (btnNext) {
      btnNext.onclick = function () {
        _currentPage++;
        renderFilteredTable();
      };
    }

    // Confirmation Modals Event Handlers
    initModalEvents();
  }

  function initModalEvents() {
    // Restore confirm
    var btnConfirmRestore = document.getElementById('btnConfirmRestore');
    if (btnConfirmRestore) {
      btnConfirmRestore.onclick = function () {
        var id = parseInt(document.getElementById('restoreTargetId').value);
        btnConfirmRestore.disabled = true;
        btnConfirmRestore.textContent = 'Restauration...';
        App.bridge.send('restore_customer', { Id: id });
      };
    }

    var btnCancelRestore = document.getElementById('btnCancelRestore');
    if (btnCancelRestore) {
      btnCancelRestore.onclick = function () {
        var overlay = document.getElementById('restoreConfirmModalOverlay');
        if (overlay) overlay.classList.remove('active');
      };
    }

    // Permanent delete confirm
    var btnConfirmDeletePerm = document.getElementById('btnConfirmDeletePerm');
    if (btnConfirmDeletePerm) {
      btnConfirmDeletePerm.onclick = function () {
        var id = parseInt(document.getElementById('deletePermTargetId').value);
        btnConfirmDeletePerm.disabled = true;
        btnConfirmDeletePerm.textContent = 'Suppression en cours...';
        App.bridge.send('delete_customer_permanent', { Id: id });
      };
    }

    var btnCancelDeletePerm = document.getElementById('btnCancelDeletePerm');
    if (btnCancelDeletePerm) {
      btnCancelDeletePerm.onclick = function () {
        var overlay = document.getElementById('deletePermanentModalOverlay');
        if (overlay) overlay.classList.remove('active');
      };
    }

    // Print archived modal button
    var btnPrintArchived = document.getElementById('btnPrintArchived');
    if (btnPrintArchived) {
      btnPrintArchived.onclick = function () {
        if (_activeViewItem) {
          printArchivedItem(_activeViewItem);
        }
      };
    }

    // Close view archived modal
    var btnCloseView = document.getElementById('btnCloseViewArchived');
    if (btnCloseView) {
      btnCloseView.onclick = function () {
        var overlay = document.getElementById('viewArchivedModalOverlay');
        if (overlay) overlay.classList.remove('active');
      };
    }
  }

  // ──────────────────────────────────────────────
  // Bridge Response: archive_list
  // ──────────────────────────────────────────────
  function onArchiveList(payload) {
    if (!payload || !payload.success) {
      App.toast('Erreur lors du chargement des données archivées.', 'error');
      return;
    }

    _rawCustomers = payload.customers || [];
    _rawDebts = payload.debts || [];
    _rawPayments = payload.payments || [];
    _stats = payload.stats || {
      total: _rawCustomers.length + _rawDebts.length + _rawPayments.length,
      customers: _rawCustomers.length,
      debts: _rawDebts.length,
      payments: _rawPayments.length
    };

    updateStatsDisplay();
    renderFilteredTable();
  }

  function updateStatsDisplay() {
    var statTotal = document.getElementById('statArchiveTotal');
    var statCust = document.getElementById('statArchiveCustomers');
    var statDebts = document.getElementById('statArchiveDebts');
    var statPay = document.getElementById('statArchivePayments');
    var totalBadge = document.getElementById('archiveTotalBadge');

    if (statTotal) statTotal.textContent = _stats.total;
    if (statCust) statCust.textContent = _stats.customers;
    if (statDebts) statDebts.textContent = _stats.debts;
    if (statPay) statPay.textContent = _stats.payments;
    if (totalBadge) totalBadge.textContent = _stats.total;
  }

  // ──────────────────────────────────────────────
  // Data Filtering & Preparation
  // ──────────────────────────────────────────────
  function getPreparedArchiveItems() {
    var items = [];

    // 1. Customers
    if (_currentFilterType === 'all' || _currentFilterType === 'customers') {
      _rawCustomers.forEach(function (c) {
        items.push({
          itemType: 'customer',
          id: c.Id,
          ref: '#C-' + String(c.Id).padStart(3, '0'),
          customerName: c.FullName || '—',
          phone: c.Phone || '—',
          cin: c.CIN || '—',
          address: c.Address || '—',
          notes: c.Notes || '—',
          createdDate: c.RegistrationDate,
          amount: c.TotalRemaining, // Total owed
          paidAmount: null,
          remainingAmount: c.TotalRemaining,
          status: 'Archivé',
          archivedAt: c.ArchivedAt,
          raw: c
        });
      });
    }

    // 2. Debts
    if (_currentFilterType === 'all' || _currentFilterType === 'debts') {
      _rawDebts.forEach(function (d) {
        // Status filter
        if (_currentStatus === 'unpaid' && d.Status !== 'Non payé') return;
        if (_currentStatus === 'partial' && d.Status !== 'Partiellement payé') return;
        if (_currentStatus === 'paid' && d.Status !== 'Payé') return;

        items.push({
          itemType: 'debt',
          id: d.Id,
          customerId: d.CustomerId,
          ref: '#D-' + String(d.Id).padStart(3, '0'),
          customerName: d.CustomerName || '—',
          phone: d.CustomerPhone || '—',
          cin: d.CustomerCIN || '—',
          createdDate: d.DebtDate,
          amount: d.Amount,
          paidAmount: d.PaidAmount,
          remainingAmount: d.RemainingAmount,
          status: d.Status,
          notes: d.Notes || '—',
          archivedAt: d.ArchivedAt,
          raw: d
        });
      });
    }

    // 3. Payments
    if (_currentFilterType === 'all' || _currentFilterType === 'payments') {
      _rawPayments.forEach(function (p) {
        items.push({
          itemType: 'payment',
          id: p.Id,
          debtId: p.DebtId,
          ref: '#P-' + String(p.Id).padStart(3, '0'),
          customerName: p.CustomerName || '—',
          phone: p.CustomerPhone || '—',
          cin: p.CustomerCIN || '—',
          createdDate: p.PaymentDate,
          amount: p.Amount,
          paidAmount: p.Amount,
          remainingAmount: 0,
          status: 'Versé',
          notes: p.Notes || '—',
          archivedAt: p.ArchivedAt,
          raw: p
        });
      });
    }

    // 4. Apply Date Period Filter
    if (_currentPeriod !== 'all') {
      items = items.filter(function (item) {
        return matchesPeriod(item.archivedAt || item.createdDate);
      });
    }

    // 5. Apply Search Query Filter
    if (_searchQuery) {
      items = items.filter(function (item) {
        var term = _searchQuery;
        var name = (item.customerName || '').toLowerCase();
        var phone = (item.phone || '').toLowerCase();
        var cin = (item.cin || '').toLowerCase();
        var ref = (item.ref || '').toLowerCase();
        var date = (item.createdDate || '').toLowerCase();
        var archDate = (item.archivedAt || '').toLowerCase();

        return name.indexOf(term) !== -1 ||
               phone.indexOf(term) !== -1 ||
               cin.indexOf(term) !== -1 ||
               ref.indexOf(term) !== -1 ||
               date.indexOf(term) !== -1 ||
               archDate.indexOf(term) !== -1;
      });
    }

    return items;
  }

  function matchesPeriod(dateString) {
    if (!dateString) return false;
    var d = new Date(dateString);
    if (isNaN(d.getTime())) return false;

    var now = new Date();
    var todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    if (_currentPeriod === 'today') {
      return d >= todayStart;
    }

    if (_currentPeriod === 'week') {
      var day = now.getDay();
      var diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday start
      var weekStart = new Date(now.setDate(diff));
      weekStart.setHours(0, 0, 0, 0);
      return d >= weekStart;
    }

    if (_currentPeriod === 'month') {
      var monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      return d >= monthStart;
    }

    if (_currentPeriod === 'year') {
      var yearStart = new Date(now.getFullYear(), 0, 1);
      return d >= yearStart;
    }

    if (_currentPeriod === 'custom') {
      if (_customDateFrom) {
        var from = new Date(_customDateFrom);
        if (d < from) return false;
      }
      if (_customDateTo) {
        var to = new Date(_customDateTo);
        to.setHours(23, 59, 59, 999);
        if (d > to) return false;
      }
      return true;
    }

    return true;
  }

  // ──────────────────────────────────────────────
  // Render Filtered Table & Pagination
  // ──────────────────────────────────────────────
  function renderFilteredTable() {
    var tbody = document.getElementById('archiveTableBody');
    if (!tbody) return;

    var allItems = getPreparedArchiveItems();
    var totalCount = allItems.length;

    // Pagination calculations
    var totalPages = Math.ceil(totalCount / _pageSize) || 1;
    if (_currentPage > totalPages) _currentPage = totalPages;
    if (_currentPage < 1) _currentPage = 1;

    var startIndex = (_currentPage - 1) * _pageSize;
    var endIndex = Math.min(startIndex + _pageSize, totalCount);
    var pageItems = allItems.slice(startIndex, endIndex);

    updatePaginationUI(totalCount, startIndex, endIndex, totalPages);

    // Empty state check
    if (totalCount === 0) {
      tbody.innerHTML =
        '<tr><td colspan="11" class="table-empty">' +
          '<div class="empty-state">' +
            '<div class="empty-state-icon">' +
              '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">' +
                '<polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line>' +
              '</svg>' +
            '</div>' +
            '<div class="empty-state-title">Aucune donnée archivée</div>' +
            '<div class="empty-state-text">Les clients et les dettes archivés apparaîtront ici.</div>' +
          '</div>' +
        '</td></tr>';
      return;
    }

    var rows = pageItems.map(function (item) {
      var typeBadge = '';
      if (item.itemType === 'customer') typeBadge = '<span class="badge badge-info">Client</span>';
      else if (item.itemType === 'debt') typeBadge = '<span class="badge badge-warning">Dette</span>';
      else typeBadge = '<span class="badge badge-success">Paiement</span>';

      var statusBadgeHtml = '';
      if (item.status === 'Payé' || item.status === 'Versé') statusBadgeHtml = '<span class="badge badge-success">✓ ' + item.status + '</span>';
      else if (item.status === 'Partiellement payé') statusBadgeHtml = '<span class="badge badge-warning">◑ Partiel</span>';
      else if (item.status === 'Non payé') statusBadgeHtml = '<span class="badge badge-danger">✕ Non payé</span>';
      else statusBadgeHtml = '<span class="badge" style="background: rgba(100,116,139,0.12); color: #64748B;">Archivé</span>';

      var amountFormatted = (item.amount !== null && item.amount !== undefined) ? formatDH(item.amount) : '—';
      var paidFormatted = (item.paidAmount !== null && item.paidAmount !== undefined) ? formatDH(item.paidAmount) : '—';
      var remainingFormatted = (item.remainingAmount !== null && item.remainingAmount !== undefined) ? formatDH(item.remainingAmount) : '—';

      // Action buttons
      var actionsHtml = '<div class="action-buttons">';
      
      // Voir détails
      actionsHtml +=
        '<button type="button" class="btn-action btn-view" onclick="Archive.openViewDetails(\'' + item.itemType + '\', ' + item.id + ')" title="Voir les détails">' +
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>' +
        '</button>';

      // Restaurer (Restoring an archived item restores its customer and all associated data)
      var targetRestoreId = (item.itemType === 'customer') ? item.id : (item.customerId || item.raw.CustomerId || item.id);
      actionsHtml +=
        '<button type="button" class="btn-action btn-restore" onclick="Archive.openRestoreConfirm(' + targetRestoreId + ', \'' + escHtml(item.customerName) + '\')" title="Restaurer">' +
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>' +
        '</button>';

      // Imprimer
      actionsHtml +=
        '<button type="button" class="btn-action btn-print" onclick="Archive.printItemDirect(\'' + item.itemType + '\', ' + item.id + ')" title="Imprimer">' +
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>' +
        '</button>';

      // Supprimer définitivement (only shown on customer items to enforce cascaded safety)
      if (item.itemType === 'customer') {
        actionsHtml +=
          '<button type="button" class="btn-action btn-delete" onclick="Archive.openDeleteConfirm(' + item.id + ', \'' + escHtml(item.customerName) + '\')" title="Supprimer définitivement">' +
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>' +
          '</button>';
      }

      actionsHtml += '</div>';

      return (
        '<tr>' +
          '<td>' + typeBadge + '</td>' +
          '<td><span class="text-muted" style="font-weight: 600;">' + item.ref + '</span></td>' +
          '<td><strong>' + escHtml(item.customerName) + '</strong></td>' +
          '<td>' + escHtml(item.phone) + '</td>' +
          '<td>' + formatDate(item.createdDate) + '</td>' +
          '<td><strong>' + amountFormatted + '</strong></td>' +
          '<td>' + paidFormatted + '</td>' +
          '<td><strong style="color: ' + (item.remainingAmount <= 0 ? 'var(--color-success)' : 'var(--color-danger)') + ';">' + remainingFormatted + '</strong></td>' +
          '<td>' + statusBadgeHtml + '</td>' +
          '<td><span class="text-muted">' + formatDate(item.archivedAt) + '</span></td>' +
          '<td>' + actionsHtml + '</td>' +
        '</tr>'
      );
    });

    tbody.innerHTML = rows.join('');
  }

  function updatePaginationUI(totalCount, startIndex, endIndex, totalPages) {
    var pStart = document.getElementById('paginationStart');
    var pEnd = document.getElementById('paginationEnd');
    var pTotal = document.getElementById('paginationTotal');
    var btnPrev = document.getElementById('btnArchivePrevPage');
    var btnNext = document.getElementById('btnArchiveNextPage');
    var numContainer = document.getElementById('archivePageNumbers');

    if (pStart) pStart.textContent = totalCount > 0 ? (startIndex + 1) : 0;
    if (pEnd) pEnd.textContent = endIndex;
    if (pTotal) pTotal.textContent = totalCount;

    if (btnPrev) btnPrev.disabled = (_currentPage <= 1);
    if (btnNext) btnNext.disabled = (_currentPage >= totalPages);

    if (numContainer) {
      numContainer.innerHTML = '';
      for (var i = 1; i <= totalPages; i++) {
        var pageBtn = document.createElement('button');
        pageBtn.type = 'button';
        pageBtn.className = 'btn btn-sm ' + (i === _currentPage ? 'btn-primary' : 'btn-secondary');
        pageBtn.style.minWidth = '32px';
        pageBtn.textContent = i;
        (function (pageIndex) {
          pageBtn.onclick = function () {
            _currentPage = pageIndex;
            renderFilteredTable();
          };
        })(i);
        numContainer.appendChild(pageBtn);
      }
    }
  }

  // ──────────────────────────────────────────────
  // View Item Details Modal (Read-Only)
  // ──────────────────────────────────────────────
  function openViewDetails(itemType, id) {
    var modalBody = document.getElementById('viewArchivedModalBody');
    var overlay = document.getElementById('viewArchivedModalOverlay');
    if (!modalBody || !overlay) return;

    var allItems = getPreparedArchiveItems();
    var item = allItems.find(function (it) { return it.itemType === itemType && it.id === id; });
    if (!item) {
      App.toast('Élément introuvable.', 'error');
      return;
    }

    _activeViewItem = item;

    var html = '';

    if (itemType === 'customer') {
      var c = item.raw;
      var custDebts = _rawDebts.filter(function (d) { return d.CustomerId === c.Id; });

      html =
        '<div class="view-customer-grid">' +
          '<div class="view-item full-width" style="background: var(--color-bg-app); border-radius: 8px; padding: 10px 14px; margin-bottom: 0.5rem;">' +
            '<span class="view-label">Client Archivé</span>' +
            '<span class="view-value" style="font-size: 1.2rem; color: var(--color-primary); font-weight: 700;">' + escHtml(c.FullName) + '</span>' +
          '</div>' +
          '<div class="view-item"><span class="view-label">Téléphone</span><span class="view-value">' + escHtml(c.Phone || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">CIN</span><span class="view-value">' + escHtml(c.CIN || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date d\'inscription</span><span class="view-value">' + formatDate(c.RegistrationDate) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date d\'archivage</span><span class="view-value">' + formatDate(c.ArchivedAt) + '</span></div>' +
          '<div class="view-item full-width"><span class="view-label">Adresse</span><span class="view-value">' + escHtml(c.Address || '—') + '</span></div>' +
          '<div class="view-item full-width"><span class="view-label">Notes</span><span class="view-value">' + escHtml(c.Notes || '—') + '</span></div>' +
        '</div>' +
        '<div class="view-section-divider" style="margin: 1.25rem 0 0.75rem 0;"></div>' +
        '<div class="view-section-title" style="margin-bottom: 0.5rem;">Dettes archivées de ce client (' + custDebts.length + ')</div>';

      if (custDebts.length === 0) {
        html += '<p style="color: var(--color-text-muted); font-size: 13px;">Aucune dette pour ce client.</p>';
      } else {
        var dRows = custDebts.map(function (cd, idx) {
          return (
            '<tr>' +
              '<td>#' + String(cd.Id).padStart(3, '0') + '</td>' +
              '<td>' + formatDate(cd.DebtDate) + '</td>' +
              '<td><strong>' + formatDH(cd.Amount) + '</strong></td>' +
              '<td>' + formatDH(cd.PaidAmount) + '</td>' +
              '<td><strong style="color: ' + (cd.RemainingAmount <= 0 ? 'var(--color-success)' : 'var(--color-danger)') + ';">' + formatDH(cd.RemainingAmount) + '</strong></td>' +
              '<td>' + cd.Status + '</td>' +
            '</tr>'
          );
        });
        html +=
          '<table class="debts-mini-table">' +
            '<thead><tr><th>N°</th><th>Date</th><th>Montant</th><th>Payé</th><th>Reste</th><th>Statut</th></tr></thead>' +
            '<tbody>' + dRows.join('') + '</tbody>' +
          '</table>';
      }
    } else if (itemType === 'debt') {
      var d = item.raw;
      var debtPayments = _rawPayments.filter(function (p) { return p.DebtId === d.Id; });

      html =
        '<div class="view-customer-grid">' +
          '<div class="view-item full-width" style="background: var(--color-bg-app); border-radius: 8px; padding: 10px 14px; margin-bottom: 0.5rem;">' +
            '<span class="view-label">Dette Archivée</span>' +
            '<span class="view-value" style="font-size: 1.2rem; color: var(--color-primary); font-weight: 700;">#' + String(d.Id).padStart(3, '0') + ' — ' + escHtml(d.CustomerName || '—') + '</span>' +
          '</div>' +
          '<div class="view-item"><span class="view-label">Téléphone</span><span class="view-value">' + escHtml(d.CustomerPhone || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">CIN</span><span class="view-value">' + escHtml(d.CustomerCIN || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date création</span><span class="view-value">' + formatDate(d.DebtDate) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date archivage</span><span class="view-value">' + formatDate(d.ArchivedAt) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Montant initial</span><span class="view-value font-bold">' + formatDH(d.Amount) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Total versé</span><span class="view-value" style="color: var(--color-success); font-weight: 700;">' + formatDH(d.PaidAmount) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Reste dû</span><span class="view-value" style="color: var(--color-danger); font-weight: 700;">' + formatDH(d.RemainingAmount) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Statut</span><span class="view-value">' + d.Status + '</span></div>' +
          '<div class="view-item full-width"><span class="view-label">Note</span><span class="view-value">' + escHtml(d.Notes || '—') + '</span></div>' +
        '</div>' +
        '<div class="view-section-divider" style="margin: 1.25rem 0 0.75rem 0;"></div>' +
        '<div class="view-section-title" style="margin-bottom: 0.5rem;">Historique complet des paiements (' + debtPayments.length + ')</div>';

      if (debtPayments.length === 0) {
        html += '<p style="color: var(--color-text-muted); font-size: 13px;">Aucun paiement enregistré pour cette dette.</p>';
      } else {
        var pRows = debtPayments.map(function (dp, i) {
          return (
            '<tr>' +
              '<td>#' + (i + 1) + '</td>' +
              '<td>' + formatDate(dp.PaymentDate) + '</td>' +
              '<td><strong style="color: var(--color-success);">' + formatDH(dp.Amount) + '</strong></td>' +
              '<td>' + escHtml(dp.Notes || '—') + '</td>' +
            '</tr>'
          );
        });
        html +=
          '<table class="debts-mini-table">' +
            '<thead><tr><th>#</th><th>Date versement</th><th>Montant versé</th><th>Remarque</th></tr></thead>' +
            '<tbody>' + pRows.join('') + '</tbody>' +
          '</table>';
      }
    } else {
      // Payment
      var p = item.raw;
      html =
        '<div class="view-customer-grid">' +
          '<div class="view-item full-width" style="background: var(--color-bg-app); border-radius: 8px; padding: 10px 14px; margin-bottom: 0.5rem;">' +
            '<span class="view-label">Paiement Archivé</span>' +
            '<span class="view-value" style="font-size: 1.2rem; color: var(--color-success); font-weight: 700;">+' + formatDH(p.Amount) + '</span>' +
          '</div>' +
          '<div class="view-item"><span class="view-label">Client</span><span class="view-value font-bold">' + escHtml(p.CustomerName || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">Téléphone</span><span class="view-value">' + escHtml(p.CustomerPhone || '—') + '</span></div>' +
          '<div class="view-item"><span class="view-label">Dette N°</span><span class="view-value">#' + String(p.DebtId).padStart(3, '0') + '</span></div>' +
          '<div class="view-item"><span class="view-label">Montant dette</span><span class="view-value">' + formatDH(p.DebtAmount) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date du versement</span><span class="view-value">' + formatDate(p.PaymentDate) + '</span></div>' +
          '<div class="view-item"><span class="view-label">Date d\'archivage</span><span class="view-value">' + formatDate(p.ArchivedAt) + '</span></div>' +
          '<div class="view-item full-width"><span class="view-label">Remarque</span><span class="view-value">' + escHtml(p.Notes || '—') + '</span></div>' +
        '</div>';
    }

    modalBody.innerHTML = html;
    overlay.classList.add('active');
  }

  // ──────────────────────────────────────────────
  // Restoration Action
  // ──────────────────────────────────────────────
  function openRestoreConfirm(customerId, name) {
    var overlay = document.getElementById('restoreConfirmModalOverlay');
    var targetLabel = document.getElementById('restoreTargetLabel');
    var targetId = document.getElementById('restoreTargetId');
    var btn = document.getElementById('btnConfirmRestore');

    if (btn) { btn.disabled = false; btn.textContent = 'Restaurer'; }
    if (targetLabel) targetLabel.textContent = name || ('Client #' + customerId);
    if (targetId) targetId.value = customerId;

    if (overlay) overlay.classList.add('active');
  }

  function onRestoreResponse(payload) {
    var btn = document.getElementById('btnConfirmRestore');
    if (btn) { btn.disabled = false; btn.textContent = 'Restaurer'; }

    var overlay = document.getElementById('restoreConfirmModalOverlay');
    if (overlay) overlay.classList.remove('active');

    if (payload && payload.success) {
      App.toast(payload.message || 'Élément restauré avec succès.', 'success');
      // Refresh archive data from backend
      App.bridge.send('get_archive', {});
    } else {
      App.toast(payload ? payload.message : 'Erreur lors de la restauration.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // Permanent Deletion Action
  // ──────────────────────────────────────────────
  function openDeleteConfirm(customerId, name) {
    var overlay = document.getElementById('deletePermanentModalOverlay');
    var targetLabel = document.getElementById('deletePermTargetLabel');
    var targetId = document.getElementById('deletePermTargetId');
    var btn = document.getElementById('btnConfirmDeletePerm');

    if (btn) { btn.disabled = false; btn.textContent = 'Supprimer définitivement'; }
    if (targetLabel) targetLabel.textContent = name || ('Client #' + customerId);
    if (targetId) targetId.value = customerId;

    if (overlay) overlay.classList.add('active');
  }

  function onDeletePermanentResponse(payload) {
    var btn = document.getElementById('btnConfirmDeletePerm');
    if (btn) { btn.disabled = false; btn.textContent = 'Supprimer définitivement'; }

    var overlay = document.getElementById('deletePermanentModalOverlay');
    if (overlay) overlay.classList.remove('active');

    if (payload && payload.success) {
      App.toast(payload.message || 'Suppression définitive effectuée.', 'success');
      App.bridge.send('get_archive', {});
    } else {
      App.toast(payload ? payload.message : 'Erreur lors de la suppression définitive.', 'error');
    }
  }

  // ──────────────────────────────────────────────
  // Print & PDF Export
  // ──────────────────────────────────────────────
  function printItemDirect(itemType, id) {
    var allItems = getPreparedArchiveItems();
    var item = allItems.find(function (it) { return it.itemType === itemType && it.id === id; });
    if (item) {
      printArchivedItem(item);
    }
  }

  function printArchivedItem(item) {
    var printWindow = window.open('', '_blank', 'width=800,height=700');
    if (!printWindow) {
      window.print();
      return;
    }

    var html =
      '<!DOCTYPE html>' +
      '<html lang="fr">' +
      '<head>' +
        '<meta charset="UTF-8">' +
        '<title>Document Archivé ' + item.ref + ' — Tahiri Lilatate</title>' +
        '<style>' +
          'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #1E293B; background: #FFF; line-height: 1.5; }' +
          '.header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #512DA8; padding-bottom: 15px; }' +
          '.title { font-size: 24px; font-weight: 800; color: #512DA8; margin: 0; }' +
          '.subtitle { font-size: 13px; color: #64748B; margin-top: 4px; }' +
          '.badge { display: inline-block; background: #F1F5F9; border: 1px solid #CBD5E1; padding: 4px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; color: #334155; margin-top: 8px; }' +
          '.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 18px; font-size: 14px; }' +
          '.info-label { font-size: 12px; font-weight: 600; color: #64748B; text-transform: uppercase; }' +
          '.info-val { font-size: 15px; font-weight: 600; color: #0F172A; }' +
          'table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 14px; }' +
          'th { background: #512DA8; color: #FFF; text-align: left; padding: 10px 12px; font-weight: 600; }' +
          'td { padding: 10px 12px; border-bottom: 1px solid #E2E8F0; }' +
          '.footer { margin-top: 40px; display: flex; justify-content: space-between; font-size: 13px; color: #64748B; border-top: 1px solid #E2E8F0; padding-top: 15px; }' +
          '@media print { body { padding: 0; } }' +
        '</style>' +
      '</head>' +
      '<body>' +
        '<div class="header">' +
          '<h1 class="title">TAHIRI LILATATE</h1>' +
          '<div class="subtitle">Gestion des dettes — Copie d\'archive officielle</div>' +
          '<div class="badge">Référence : ' + item.ref + ' (' + item.itemType.toUpperCase() + ')</div>' +
        '</div>' +
        '<div class="info-grid">' +
          '<div><div class="info-label">Client</div><div class="info-val">' + escHtml(item.customerName) + '</div></div>' +
          '<div><div class="info-label">Téléphone</div><div class="info-val">' + escHtml(item.phone) + '</div></div>' +
          '<div><div class="info-label">Date enregistrement</div><div class="info-val">' + formatDate(item.createdDate) + '</div></div>' +
          '<div><div class="info-label">Date archivage</div><div class="info-val">' + formatDate(item.archivedAt) + '</div></div>' +
        '</div>' +
        '<table>' +
          '<thead><tr><th>Désignation</th><th style="text-align: right;">Montant</th></tr></thead>' +
          '<tbody>' +
            '<tr><td>Montant total / initial</td><td style="text-align: right;"><strong>' + formatDH(item.amount) + '</strong></td></tr>' +
            '<tr><td>Total des versements</td><td style="text-align: right; color: #166534;">' + formatDH(item.paidAmount) + '</td></tr>' +
            '<tr><td>Reste à payer</td><td style="text-align: right; color: #991B1B;"><strong>' + formatDH(item.remainingAmount) + '</strong></td></tr>' +
            '<tr><td>Statut</td><td style="text-align: right;">' + item.status + '</td></tr>' +
          '</tbody>' +
        '</table>' +
        (item.notes && item.notes !== '—' ? '<p style="font-size: 13px; color: #64748B;"><strong>Remarque :</strong> ' + escHtml(item.notes) + '</p>' : '') +
        '<div class="footer">' +
          '<div>Document imprimé depuis les archives le ' + new Date().toLocaleDateString('fr-MA') + ' à ' + new Date().toLocaleTimeString('fr-MA', { hour: '2-digit', minute: '2-digit' }) + '</div>' +
          '<div>Cachet / Signature : ___________________</div>' +
        '</div>' +
        '<script>window.onload = function() { window.print(); };<\/script>' +
      '</body></html>';

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  }

  // ──────────────────────────────────────────────
  // Helpers
  // ──────────────────────────────────────────────
  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatDH(amount) {
    if (amount === null || amount === undefined) return '— DH';
    var num = parseFloat(amount);
    if (isNaN(num)) return '— DH';
    return num.toLocaleString('fr-MA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' DH';
  }

  function formatDate(isoString) {
    if (!isoString) return '—';
    try {
      var d = new Date(isoString);
      return d.toLocaleDateString('fr-MA', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch (ex) { return isoString; }
  }

  // ──────────────────────────────────────────────
  // Public API
  // ──────────────────────────────────────────────
  return {
    renderPage: renderPage,
    initPage: initPage,
    onArchiveList: onArchiveList,
    openViewDetails: openViewDetails,
    openRestoreConfirm: openRestoreConfirm,
    onRestoreResponse: onRestoreResponse,
    openDeleteConfirm: openDeleteConfirm,
    onDeletePermanentResponse: onDeletePermanentResponse,
    printItemDirect: printItemDirect
  };

})();

window.Archive = Archive;
