using System;

namespace tahiri_lilatate.Models
{
    /// <summary>
    /// Represents a customer in the shop.
    /// A customer can have multiple debts (see <see cref="Debt"/>).
    /// </summary>
    public class Customer
    {
        /// <summary>Auto-incremented primary key.</summary>
        public int Id { get; set; }

        /// <summary>Full name of the customer. Required.</summary>
        public string FullName { get; set; }

        /// <summary>Phone number. Optional.</summary>
        public string Phone { get; set; }

        /// <summary>
        /// National identity card number (CIN). Optional.
        /// NOTE: No UNIQUE constraint at the DB level to allow empty/null values.
        /// </summary>
        public string CIN { get; set; }

        /// <summary>Customer address. Optional.</summary>
        public string Address { get; set; }

        /// <summary>Free-text notes. Optional.</summary>
        public string Notes { get; set; }

        /// <summary>ISO 8601 date when the customer was registered. Required.</summary>
        public string RegistrationDate { get; set; }

        /// <summary>
        /// Soft-delete flag. 0 = active, 1 = archived.
        /// Archived customers are hidden from the main list.
        /// </summary>
        public bool IsArchived { get; set; }

        /// <summary>ISO 8601 timestamp when the customer was archived. Null if active.</summary>
        public string ArchivedAt { get; set; }

        // ──────────────────────────────────────────────
        // Computed / navigation properties (not stored in DB)
        // ──────────────────────────────────────────────

        /// <summary>
        /// Total remaining balance across all debts.
        /// Computed from Debts and Payments — never stored.
        /// </summary>
        public decimal TotalRemaining { get; set; }

        /// <summary>
        /// Initial debt when creating customer.
        /// </summary>
        public decimal InitialDebt { get; set; }

        /// <summary>Display label for IsArchived.</summary>
        public string StatusLabel
        {
            get { return IsArchived ? "Archivé" : "Actif"; }
        }
    }
}
