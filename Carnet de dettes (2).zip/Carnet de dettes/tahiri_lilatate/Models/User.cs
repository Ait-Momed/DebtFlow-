using System;

namespace tahiri_lilatate.Models
{
    /// <summary>
    /// Represents an application user (for Phase 3 authentication).
    /// Passwords are stored as bcrypt/SHA-256 hashes — never plain-text.
    /// </summary>
    public class User
    {
        /// <summary>Auto-incremented primary key.</summary>
        public int Id { get; set; }

        /// <summary>Unique login username.</summary>
        public string Username { get; set; }

        /// <summary>
        /// Hashed password. Never store plain-text here.
        /// Phase 3 will use a proper hashing strategy.
        /// </summary>
        public string PasswordHash { get; set; }

        /// <summary>User role: "admin" or future roles.</summary>
        public string Role { get; set; }

        /// <summary>ISO 8601 creation timestamp.</summary>
        public string CreatedAt { get; set; }
    }
}
