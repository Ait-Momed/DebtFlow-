using System;

namespace tahiri_lilatate.Models
{
    /// <summary>
    /// Represents a single payment made toward a debt.
    /// One debt can have multiple payments.
    /// 100% C# 5.0 compatible.
    /// </summary>
    public class Payment
    {
        /// <summary>Auto-incremented primary key.</summary>
        public int Id { get; set; }

        /// <summary>Foreign key to Debts.Id.</summary>
        public int DebtId { get; set; }

        /// <summary>
        /// Amount paid in Moroccan Dirhams.
        /// Stored as NUMERIC in SQLite, mapped to decimal in C#.
        /// Always positive.
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>ISO 8601 date when the payment was made.</summary>
        public string PaymentDate { get; set; }

        /// <summary>Free-text notes about this payment. Optional.</summary>
        public string Notes { get; set; }

        // ──────────────────────────────────────────────
        // Navigation properties (not stored in DB)
        // ──────────────────────────────────────────────

        /// <summary>Customer name associated with this payment. Not stored.</summary>
        public string CustomerFullName { get; set; }

        /// <summary>Customer phone number. Not stored.</summary>
        public string CustomerPhone { get; set; }

        /// <summary>Customer CIN. Not stored.</summary>
        public string CustomerCIN { get; set; }

        /// <summary>Original debt amount for this payment's debt. Not stored.</summary>
        public decimal DebtAmount { get; set; }

        /// <summary>Total amount paid so far on this debt. Not stored.</summary>
        public decimal DebtTotalPaid { get; set; }

        /// <summary>Remaining balance on this debt. Not stored.</summary>
        public decimal DebtRemaining { get; set; }

        /// <summary>Status of the debt after this payment. Not stored.</summary>
        public string DebtStatus { get; set; }

        /// <summary>Date when customer was archived. Not stored.</summary>
        public string ArchivedAt { get; set; }
    }
}
