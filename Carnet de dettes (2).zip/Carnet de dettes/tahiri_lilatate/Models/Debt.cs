using System;
using System.Collections.Generic;

namespace tahiri_lilatate.Models
{
    /// <summary>
    /// Represents a single debt belonging to a customer.
    /// One customer can have multiple debts.
    ///
    /// IMPORTANT: PaidAmount, RemainingAmount and Status are NOT stored in this table.
    /// They are always calculated from the Payments table:
    ///   TotalPaid     = SUM(Payments.Amount) WHERE DebtId = this.Id
    ///   Remaining     = this.Amount - TotalPaid
    ///   Status        = derived from Remaining
    /// </summary>
    public class Debt
    {
        public Debt()
        {
            Payments = new List<Payment>();
        }

        /// <summary>Auto-incremented primary key.</summary>
        public int Id { get; set; }

        /// <summary>Foreign key to Customers.Id.</summary>
        public int CustomerId { get; set; }

        /// <summary>
        /// Debt amount in Moroccan Dirhams.
        /// Stored as NUMERIC in SQLite, mapped to decimal in C#.
        /// Always positive.
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>ISO 8601 date when the debt was recorded.</summary>
        public string DebtDate { get; set; }

        /// <summary>Free-text notes about this debt. Optional.</summary>
        public string Notes { get; set; }

        // ──────────────────────────────────────────────
        // Computed / navigation properties (not stored in DB)
        // ──────────────────────────────────────────────

        /// <summary>Total amount paid toward this debt. Computed from Payments table.</summary>
        public decimal TotalPaid { get; set; }

        /// <summary>Remaining balance = Amount - TotalPaid. Computed.</summary>
        public decimal Remaining
        {
            get { return Amount - TotalPaid; }
        }

        /// <summary>
        /// Payment status derived from Remaining:
        ///   "Non payé"           → TotalPaid == 0
        ///   "Partiellement payé" → Remaining > 0 and TotalPaid > 0
        ///   "Payé"               → Remaining == 0
        /// </summary>
        public string Status
        {
            get
            {
                if (TotalPaid == 0)
                    return "Non payé";
                if (Remaining > 0)
                    return "Partiellement payé";
                return "Payé";
            }
        }

        /// <summary>Navigation: customer who owns this debt. Not stored.</summary>
        public string CustomerFullName { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerCIN { get; set; }
        public string ArchivedAt { get; set; }
        public string LastPaymentDate { get; set; }

        /// <summary>Navigation: payments made toward this debt. Not stored.</summary>
        public List<Payment> Payments { get; set; }
    }
}
